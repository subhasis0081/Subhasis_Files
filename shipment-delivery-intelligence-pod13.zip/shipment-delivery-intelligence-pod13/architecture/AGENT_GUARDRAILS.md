# Agent Guardrails — Shipment Delivery Intelligence — Pod 13

Catalog: `dbx_cohort1_wave1` | Schema: `sch_pod13`

---

## Principle

Agents are **read-only** by design. They use governed UC table-valued functions to access Gold data. Any action that changes operational state requires a human decision logged in `audit_human_reviews`. Agents never write to Bronze, Silver, or Gold tables directly.

---

## Agent Roles

### ShipmentInvestigationAgent
- **Capabilities:** Read current status, ordered events, SLA, exceptions, document evidence, data quality state
- **Tools:** `get_shipment_status`, `get_shipment_sla`, `get_document_details`, `get_open_exceptions`
- **Restrictions:** Read-only. Cannot recommend state changes or close exceptions.

### DocumentIntelligenceAgent
- **Capabilities:** Extract bounded fields from document content, assess confidence, explain extraction
- **Restrictions:**
  - Cannot approve its own extraction output
  - Cannot directly update `gold_delivery_document`
  - Low-confidence output must be routed to human review queue

### ExceptionAgent (Remediation)
- **Capabilities:** Investigate open exceptions, recommend retry/reprocessing/mapping change/quarantine
- **Restrictions:**
  - May only **execute** idempotent retries (retry of existing Bronze ingestion)
  - Cannot close exceptions
  - Cannot modify shipment status
  - Recommendations logged to `audit_agent_activity`; only idempotent actions auto-execute

### SupervisorAgent
- **Capabilities:** Route requests to specialised sub-agents, create pending human-review requests
- **Restrictions:**
  - Cannot act on state changes
  - Cannot approve human-review requests (creates them only)
  - Routes low-confidence, exception, SLA override, identifier mapping decisions to human queue

---

## Human Approval Required Before

These actions are **blocked** until a corresponding `APPROVED` record exists in `audit_human_reviews`:

| Action | review_type |
|--------|-------------|
| Modify shipment status | `STATUS_CHANGE` |
| Close a delivery exception | `EXCEPTION` |
| Accept extraction below 0.80 confidence | `LOW_CONFIDENCE` |
| Approve fuzzy identifier mapping | `IDENTIFIER_MAPPING` |
| Override an SLA result | `SLA_OVERRIDE` |

Enforcement pattern:

```python
def require_human_approval(shipment_id: str, action_type: str) -> bool:
    result = spark.sql(f"""
        SELECT COUNT(*) as cnt
        FROM {CATALOG}.{SCHEMA}.audit_human_reviews
        WHERE shipment_id = '{shipment_id}'
          AND review_type = '{action_type}'
          AND decision = 'APPROVED'
    """).collect()[0]["cnt"]
    return result > 0
```

---

## UC Functions (Read-Only Tools)

All four functions are defined in `dbx_cohort1_wave1.sch_pod13`.

### `get_shipment_status(p_shipment_id STRING)`
Returns: `shipment_id`, `latest_status`, `delivery_state`, `data_quality_state`, `has_open_exception`, `gold_updated_at`  
Source: `gold_shipment_tracking`

### `get_shipment_sla(p_shipment_id STRING)`
Returns: `shipment_id`, `promised_delivery_date`, `actual_delivery_timestamp_utc`, `variance_hours`, `sla_result`, `rule_version`  
Source: `gold_shipment_sla`

### `get_document_details(p_shipment_id STRING)`
Returns: `delivery_document_id`, `delivery_result`, `exception_reason`, `damage_note`, `confidence_score`, `review_status`, `content_hash`  
Source: `gold_delivery_document`

### `get_open_exceptions(p_shipment_id STRING)`
Returns: `exception_id`, `exception_type`, `exception_detail`, `evidence_source`, `exception_status`, `created_at`  
Source: `gold_delivery_exception` where `exception_status = 'OPEN'`  
Pass `NULL` to return all open exceptions across all shipments.

---

## Evidence Requirements in Every Agent Answer

Every agent response must include:
- `shipment_id` — the shipment being investigated
- `source_table` — which Gold table or UC function provided the data
- `event_id` or `document_id` — relevant record identifier
- `timestamps` — event_timestamp_utc or extraction timestamp
- `extraction_confidence` — if document involved
- `reviewer_state` — current human review status
- `data_quality_limitations` — any quality flags on the data

---

## Agent Audit Logging

Every agent action logs to `audit_agent_activity`:

```python
import uuid
from datetime import datetime, timezone

def log_agent_action(agent_name, action_type, shipment_id, tool_used,
                     input_summary, output_summary, requires_human):
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_agent_activity VALUES (
        '{str(uuid.uuid4())}', '{EXECUTION_ID}', '{agent_name}', '{action_type}',
        '{shipment_id}', '{tool_used}',
        '{input_summary}', '{output_summary}',
        {requires_human}, current_timestamp()
    )
    """)
```

---

## What Agents NEVER Do

- Write or UPDATE any Bronze, Silver, or Gold table
- Read raw Bronze or Silver tables directly (Gold functions only)
- Approve their own output
- Execute non-idempotent operations without human approval
- Skip logging to `audit_agent_activity`
- Return an answer without evidence fields listed above
