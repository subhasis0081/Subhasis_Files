# Architecture — Shipment Delivery Intelligence — Pod 13

## Project Identity

| Item | Value |
|------|-------|
| Catalog | `dbx_cohort1_wave1` |
| Schema | `sch_pod13` |
| Volume | `vol_pod13` |
| Volume path | `/Volumes/dbx_cohort1_wave1/sch_pod13/vol_pod13` |
| Pod | 13 |

---

## Business Problem

A logistics provider receives:
- Shipment manifests and warehouse dispatch records as **CSV**
- Carrier tracking updates as **nested JSON APIs**
- Proof-of-delivery documents, scanned delivery notes, driver comments as **PDFs or text**

Reporting is delayed by inconsistent tracking identifiers, late carrier updates, duplicate status events, malformed APIs, and manual document review.

---

## Solution Flow

```
Landing → Bronze → Silver → Gold → Governed UC Functions → Agents → Human Decision
```

---

## Layer Responsibilities

### Landing
Raw source files dropped into Volume folders before any processing:
- `landing/` — CSV manifests, JSON payloads, POD .txt files

### Bronze (Immutable Evidence)
- Values kept exactly as received — no business corrections
- Malformed records preserved
- Every row tagged: `source_file`, `source_record_id`, `batch_id`, `ingested_ts_utc`
- `_rescued_data` for unexpected columns
- Idempotent and restartable ingestion

### Silver (Deterministic Controls)
- Normalise case, spaces, punctuation; keep original AND canonical values
- `event_hash` = SHA-256 of (shipment_id ∥ tracking_number ∥ event_status ∥ event_timestamp)
- Exact-duplicate removal via window ranking on event_hash
- `event_sequence` from timestamp + stable ID
- Late-arrival flag: `arrival_lag_sec > 3600`
- UTC conversion; original timezone retained
- Schema drift: unexpected fields → `_rescued_data`; missing mandatory keys → quarantine
- Document extraction: structured JSON + model_version + prompt_version + content_hash + confidence
- Confidence < 0.80 → route to human review

### Gold (Business-Ready Facts)
- `gold_shipment_tracking` — 1 row per shipment, latest trusted event
- `gold_shipment_event` — 1 row per deduplicated canonical event
- `gold_delivery_document` — approved or high-confidence extractions only
- `gold_delivery_exception` — damage, partial, missing POD, identifier mismatch, low confidence, malformed feed, SLA breach
- `gold_shipment_sla` — variance_hours = actual − promised; no override without approval evidence

### Governed UC Functions
Four read-only table-valued functions expose Gold data to agents:
- `get_shipment_status(p_shipment_id)`
- `get_shipment_sla(p_shipment_id)`
- `get_document_details(p_shipment_id)`
- `get_open_exceptions(p_shipment_id)`

### Agents
- ShipmentInvestigationAgent — read-only
- DocumentIntelligenceAgent — extract, cannot approve own output or update Gold
- ExceptionAgent (Remediation) — recommend; idempotent retries only
- SupervisorAgent — route + create human-review requests; cannot act on state changes

### Human Decisions
Required before:
- Modifying shipment status
- Closing a delivery exception
- Accepting low-confidence extraction (< 0.80)
- Approving fuzzy identifier mapping
- Overriding SLA result

---

## Components

| Component | Technology |
|-----------|-----------|
| Storage | Unity Catalog — Delta tables, Managed Volume |
| Ingestion | Auto Loader / batch read |
| Orchestration | Lakeflow pipeline / notebook jobs |
| Document AI | Regex extraction (regex-v1.0), confidence scoring |
| Review Queue | `silver_human_review` table |
| Agent Tools | UC table-valued functions in `sch_pod13` |
| Monitoring | 8 audit tables across all layers |
| Quarantine | `quarantine_carrier_events`, `quarantine_documents` |

---

## Design Rationale

Bronze is immutable evidence. Silver applies deterministic, reproducible controls and produces conformed records. Gold contains business-ready facts computed from approved Silver data. Agents use governed Gold tools rather than unrestricted raw-table access — this ensures every agent action is auditable and bounded.

---

## Volume Folder Layout

| Folder | Purpose |
|--------|---------|
| `landing/` | Raw source data before ingestion |
| `logs/` | Pipeline and agent execution logs |
| `checkpoints/` | Structured Streaming and Auto Loader checkpoints |
| `quarantine/` | Records that failed validation |
| `archive/` | Processed and archived source files |
