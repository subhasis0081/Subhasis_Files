# Bronze Rules — Shipment Delivery Intelligence — Pod 13

Catalog: `dbx_cohort1_wave1` | Schema: `sch_pod13`

---

## Principle

Bronze is **immutable evidence**. Every record received is preserved exactly as it arrived. No business corrections. No transformations. No discarding of malformed records.

---

## Rules (Mandatory — Enforce in Every Bronze Notebook)

### Rule 1 — Never Correct Business Values
- Store carrier names, tracking numbers, timestamps, and statuses exactly as received
- Do NOT normalise, trim, uppercase, or fix typos at this layer
- Corrections belong in Silver

### Rule 2 — Preserve Malformed Records
- Rows with missing mandatory fields, incorrect types, or unparseable values must be ingested
- Use `_rescued_data` to capture unexpected or overflowing columns as a JSON string
- Do NOT drop, skip, or quarantine at Bronze ingestion

### Rule 3 — Mandatory Metadata on Every Row

```python
# These four columns are REQUIRED on every Bronze table row
source_file       STRING   -- full path to the source file
source_record_id  STRING   -- row index or record identifier within source
batch_id          STRING   -- UUID of the ingestion batch (EXECUTION_ID)
ingested_ts_utc   TIMESTAMP -- datetime.now(timezone.utc) at ingestion time
```

Notebook pattern:
```python
from pyspark.sql import functions as F
df = df.withColumn("source_file", F.lit(source_file_path)) \
       .withColumn("source_record_id", F.monotonically_increasing_id().cast("string")) \
       .withColumn("batch_id", F.lit(EXECUTION_ID)) \
       .withColumn("ingested_ts_utc", F.lit(STARTED_AT.isoformat()).cast("timestamp"))
```

### Rule 4 — Raw Payload Preservation
- For JSON carrier feeds: store the complete original JSON string in `raw_payload`
- For documents: store full text in `content_text` and SHA-256 hash in `content_hash`
- Never parse or transform the payload at Bronze write time

### Rule 5 — Rescued Data Column
- All Bronze tables must include `_rescued_data STRING`
- Spark / Auto Loader rescued data option must be enabled:
  ```python
  .option("rescuedDataColumn", "_rescued_data")
  ```

### Rule 6 — Idempotent and Restartable Ingestion
- Bronze writes use `mode("overwrite")` with `overwriteSchema = true` for full reload, OR
- Use `MERGE INTO` on `(source_file, source_record_id)` for incremental loads
- Re-running Bronze must produce the same result — no duplicates added

---

## Write Pattern

```python
(df.write
   .format("delta")
   .mode("overwrite")
   .option("overwriteSchema", "true")
   .saveAsTable(f"{CATALOG}.{SCHEMA}.{table_name}"))
```

---

## Post-Write Pattern

Always add table and column comments after creating a Bronze table:

```python
spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.{table_name} IS 'Bronze — raw ingested records from {source_description}'")
spark.sql(f"ALTER TABLE {CATALOG}.{SCHEMA}.{table_name} ALTER COLUMN source_file COMMENT 'Path to the source file that produced this row'")
spark.sql(f"ALTER TABLE {CATALOG}.{SCHEMA}.{table_name} ALTER COLUMN batch_id COMMENT 'UUID of the ingestion batch'")
spark.sql(f"ALTER TABLE {CATALOG}.{SCHEMA}.{table_name} ALTER COLUMN ingested_ts_utc COMMENT 'UTC timestamp when this row was ingested'")
```

---

## Audit Logging

Every Bronze notebook logs to `audit_pipeline_execution` at start and end:

```python
spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '02_Bronze_Ingestion', 'bronze',
 '{STARTED_AT}', current_timestamp(), 'SUCCESS', {records_written}, NULL, current_timestamp())
""")
```

And to `audit_reconciliation` after each table write:

```python
# source_count = rows read from file
# target_count = spark.table(f"{CATALOG}.{SCHEMA}.{table_name}").count()
```

---

## Bronze Tables Checklist

| Table | Source |
|-------|--------|
| `bronze_shipment_manifest` | `shipment_manifest.csv` |
| `bronze_dispatch` | `warehouse_dispatch.csv` |
| `bronze_tracking_map` | `shipment_tracking_map.csv` |
| `bronze_carrier_events` | `carrier_tracking_events.csv` |
| `bronze_carrier_tracking_raw` | JSON files in `landing/carrier_tracking_raw/` |
| `bronze_delivery_documents` | TXT files in `landing/pod_documents/` |
