# Data Model — Shipment Delivery Intelligence — Pod 13

Catalog: `dbx_cohort1_wave1` | Schema: `sch_pod13`

---

## Source Files (Landing)

| File | Format | Description |
|------|--------|-------------|
| `shipment_manifest.csv` | CSV | Primary shipment record with carrier and tracking number |
| `warehouse_dispatch.csv` | CSV | Warehouse dispatch confirmation linked to shipment |
| `shipment_tracking_map.csv` | CSV | Raw-to-canonical tracking number mapping |
| `carrier_tracking_events.csv` | CSV | Flattened carrier event records |
| `carrier_tracking_raw/` | JSON | One JSON file per carrier feed; nested payloads |
| `pod_documents/` | TXT | Proof-of-delivery text files; one per shipment |

---

## Bronze Tables

All Bronze tables carry these metadata columns on every row:

| Column | Type | Purpose |
|--------|------|---------|
| `source_file` | STRING | Path of the source file that produced this row |
| `source_record_id` | STRING | Row identifier within source file |
| `batch_id` | STRING | UUID of the ingestion batch |
| `ingested_ts_utc` | TIMESTAMP | UTC timestamp when the row was ingested |
| `_rescued_data` | STRING | Unexpected columns captured as JSON |

### `bronze_shipment_manifest`
| Column | Type |
|--------|------|
| shipment_id | STRING |
| order_id | STRING |
| carrier | STRING |
| tracking_number | STRING |
| origin_warehouse | STRING |
| destination_city | STRING |
| destination_state | STRING |
| destination_zip | STRING |
| promised_delivery_date | STRING |
| weight_kg | DOUBLE |
| shipment_date | STRING |
| *(+ metadata columns)* | |

### `bronze_dispatch`
| Column | Type |
|--------|------|
| dispatch_id | STRING |
| shipment_id | STRING |
| warehouse_id | STRING |
| dispatch_timestamp | STRING |
| operator_id | STRING |
| dispatch_status | STRING |
| *(+ metadata columns)* | |

### `bronze_tracking_map`
| Column | Type |
|--------|------|
| map_id | STRING |
| shipment_id | STRING |
| raw_tracking_number | STRING |
| carrier_code | STRING |
| *(+ metadata columns)* | |

### `bronze_carrier_events`
| Column | Type |
|--------|------|
| event_id | STRING |
| shipment_id | STRING |
| tracking_number | STRING |
| carrier | STRING |
| event_status | STRING |
| event_timestamp | STRING |
| event_location | STRING |
| *(+ metadata columns)* | |

### `bronze_carrier_tracking_raw`
| Column | Type |
|--------|------|
| shipment_id | STRING |
| carrier | STRING |
| payload_version | STRING |
| raw_payload | STRING |
| *(+ metadata columns)* | |

### `bronze_delivery_documents`
| Column | Type |
|--------|------|
| document_id | STRING |
| shipment_id | STRING |
| document_path | STRING |
| content_text | STRING |
| content_hash | STRING |
| *(+ metadata columns)* | |

---

## Silver Tables

### `silver_shipment`
| Column | Type | Notes |
|--------|------|-------|
| shipment_id | STRING | PK |
| order_id | STRING | |
| carrier_raw | STRING | Original value |
| carrier_normalized | STRING | Uppercase, trimmed |
| tracking_number_raw | STRING | Original value |
| tracking_number_normalized | STRING | Uppercase, no spaces |
| origin_warehouse | STRING | |
| destination_city | STRING | |
| destination_state | STRING | |
| destination_zip | STRING | |
| promised_delivery_date | DATE | Parsed to DATE |
| weight_kg | DOUBLE | |
| shipment_date | DATE | |
| is_valid | BOOLEAN | False if mandatory keys missing |
| validation_flags | STRING | JSON array of failed checks |
| silver_processed_at | TIMESTAMP | |

### `silver_dispatch`
| Column | Type |
|--------|------|
| dispatch_id | STRING |
| shipment_id | STRING |
| warehouse_id | STRING |
| dispatch_timestamp_utc | TIMESTAMP |
| dispatch_status | STRING |
| shipment_exists | BOOLEAN |
| is_valid | BOOLEAN |

### `silver_tracking_map`
| Column | Type | Notes |
|--------|------|-------|
| map_id | STRING | |
| shipment_id | STRING | |
| raw_tracking_number | STRING | |
| canonical_tracking_number | STRING | |
| match_method | STRING | EXACT / FUZZY / MANUAL |
| match_confidence | DOUBLE | 0.0 – 1.0 |
| reconciled_with_manifest | BOOLEAN | |

### `silver_carrier_events`
| Column | Type | Notes |
|--------|------|-------|
| event_id | STRING | |
| event_hash | STRING | SHA-256 dedup key |
| shipment_id | STRING | |
| tracking_number | STRING | |
| carrier | STRING | |
| event_status_raw | STRING | |
| canonical_status | STRING | label_created / picked_up / in_transit / out_for_delivery / delivered |
| event_timestamp_utc | TIMESTAMP | |
| event_sequence | INT | |
| is_duplicate | BOOLEAN | |
| is_late_arrival | BOOLEAN | arrival_lag_sec > 3600 |
| arrival_lag_sec | BIGINT | |

### `silver_document_extraction`
| Column | Type |
|--------|------|
| extraction_id | STRING |
| shipment_id | STRING |
| document_path | STRING |
| content_hash | STRING |
| delivery_result | STRING |
| recipient_indicator | STRING |
| exception_reason | STRING |
| damage_note | STRING |
| confidence_score | DOUBLE |
| requires_review | BOOLEAN |
| model_version | STRING |
| prompt_version | STRING |
| extracted_at | TIMESTAMP |

### `silver_human_review`
| Column | Type |
|--------|------|
| review_id | STRING |
| shipment_id | STRING |
| review_type | STRING |
| review_status | STRING |
| reviewer_id | STRING |
| original_value | STRING |
| corrected_value | STRING |
| decision | STRING |
| reviewed_at | TIMESTAMP |

### Quarantine Tables
- `quarantine_carrier_events` — events with schema drift or missing mandatory keys
- `quarantine_documents` — documents where extraction entirely failed

---

## Gold Tables

### `gold_shipment_tracking`
Grain: 1 row per shipment

| Column | Type |
|--------|------|
| shipment_id | STRING |
| carrier | STRING |
| tracking_number | STRING |
| origin_warehouse | STRING |
| destination_city | STRING |
| destination_state | STRING |
| latest_status | STRING |
| latest_event_timestamp_utc | TIMESTAMP |
| delivery_state | STRING |
| data_quality_state | STRING |
| has_open_exception | BOOLEAN |
| gold_updated_at | TIMESTAMP |

### `gold_shipment_event`
Grain: 1 row per canonical deduplicated event

| Column | Type |
|--------|------|
| event_id | STRING |
| event_hash | STRING |
| shipment_id | STRING |
| carrier | STRING |
| canonical_status | STRING |
| event_timestamp_utc | TIMESTAMP |
| event_sequence | INT |
| event_location | STRING |
| source_table | STRING |

### `gold_delivery_document`
Grain: 1 row per trusted document

| Column | Type |
|--------|------|
| delivery_document_id | STRING |
| shipment_id | STRING |
| document_path | STRING |
| content_hash | STRING |
| delivery_result | STRING |
| exception_reason | STRING |
| damage_note | STRING |
| confidence_score | DOUBLE |
| review_status | STRING |
| gold_accepted_at | TIMESTAMP |

### `gold_delivery_exception`
Grain: 1 row per exception

| Column | Type |
|--------|------|
| exception_id | STRING |
| shipment_id | STRING |
| exception_type | STRING |
| exception_detail | STRING |
| evidence_source | STRING |
| exception_status | STRING |
| created_at | TIMESTAMP |
| closed_at | TIMESTAMP |
| closed_by | STRING |

### `gold_shipment_sla`
Grain: 1 row per shipment

| Column | Type |
|--------|------|
| sla_id | STRING |
| shipment_id | STRING |
| promised_delivery_date | DATE |
| actual_delivery_timestamp_utc | TIMESTAMP |
| variance_hours | DOUBLE |
| sla_result | STRING |
| rule_version | STRING |
| calculated_at | TIMESTAMP |

---

## Audit Tables (8)

| Table | Tracks |
|-------|--------|
| `audit_pipeline_execution` | Every notebook run: start, end, status, record count |
| `audit_reconciliation` | Source-to-target count reconciliation across layers |
| `audit_api_failures` | Carrier API failures: malformed JSON, timeouts, parse errors |
| `audit_schema_drift` | JSON payload schema drift events |
| `audit_document_processing` | POD extraction: result, confidence, model/prompt version |
| `audit_data_quality` | All quality checks across Bronze, Silver, Gold |
| `audit_human_reviews` | Human decisions: approval, rejection, modification |
| `audit_agent_activity` | Agent actions: investigate, extract, recommend, route |

---

## Key Thresholds

| Threshold | Value | Used In |
|-----------|-------|---------|
| Late arrival | 3600 seconds | `04_Silver_Carrier_Events` |
| Confidence review | 0.80 | `05_Document_AI`, `06_Human_Review`, agents |
| Expected payload version | v3.1 | `04_Silver_Carrier_Events` |
| SLA rule version | sla-v1.0 | `08_Gold_SLA` |
| Model version | regex-v1.0 | `05_Document_AI` |
| Prompt version | pod-parser-v1.0 | `05_Document_AI` |
