# Demo Plan — Shipment Delivery Intelligence — Pod 13

Catalog: `dbx_cohort1_wave1` | Schema: `sch_pod13`

---

## Demo Objective

Demonstrate the complete AI-driven logistics pipeline end-to-end, covering both normal flows and all specified failure/anomaly scenarios. Every scenario must be traced from Source → Bronze → Silver → Gold → Audit → Agent Output.

---

## Demo Scenarios (8)

### Scenario 1 — Normal Delivery
**Sample shipment:** SHP-100011  
**What to show:**
- Shipment manifest CSV ingested to Bronze
- Silver normalisation: carrier, tracking number, timestamp UTC conversion
- Gold tracking: latest_status = `delivered`, data_quality_state = `CLEAN`
- SLA result: `SLA_MET`
- Agent: `get_shipment_status('SHP-100011')` → clean output, no exceptions

---

### Scenario 2 — Duplicate Event
**Sample shipment:** SHP-102253  
**What to show:**
- Bronze: two carrier event rows with identical event content
- Silver: `event_hash` deduplication — second row flagged `is_duplicate = true`
- Gold: only one canonical event for this status
- Audit: `audit_data_quality` records duplicate detection pass
- Agent: `get_open_exceptions('SHP-102253')` → no DUPLICATE exception (correctly resolved)

---

### Scenario 3 — Late Arrival
**Sample shipment:** SHP-102706  
**What to show:**
- Bronze: carrier event row with large `arrival_lag_sec`
- Silver: `is_late_arrival = true`, `arrival_lag_sec > 3600`
- Gold: event preserved in `gold_shipment_event` with late-arrival provenance
- Audit: `audit_data_quality` late-arrival detection
- Agent: `get_shipment_status('SHP-102706')` → delivery state reflects late event

---

### Scenario 4 — Schema Drift
**Sample shipment:** SHP-100002  
**What to show:**
- Bronze: JSON payload with unexpected fields or missing mandatory keys
- `audit_schema_drift` row created with `drifted_fields`, `action_taken = QUARANTINE`
- Silver: event quarantined in `quarantine_carrier_events`
- Gold exception: `MALFORMED_FEED` exception created
- Agent: `get_open_exceptions('SHP-100002')` → MALFORMED_FEED open exception

---

### Scenario 5 — Damaged Shipment
**Sample shipment:** SHP-100012  
**What to show:**
- Bronze: POD document ingested with damage text
- Silver extraction: `delivery_result = DAMAGED`, `damage_note` populated, high confidence
- `audit_document_processing` row: confidence > 0.80, no review required
- Gold: `gold_delivery_exception` — type `DAMAGED_DELIVERY`, status `OPEN`
- Agent: `get_document_details('SHP-100012')` → damage evidence

---

### Scenario 6 — Missing POD
**Sample shipment:** SHP-100636  
**What to show:**
- Bronze: no POD document record for this shipment
- Silver: no extraction row
- Gold exception: `MISSING_DELIVERY_EVIDENCE`, status `OPEN`
- Audit: `audit_document_processing` — zero records for this shipment
- Agent: `get_document_details('SHP-100636')` → NULL / no document found

---

### Scenario 7 — Low Confidence Extraction
**Sample shipment:** SHP-100141  
**What to show:**
- Bronze: POD text with ambiguous content
- Silver extraction: `confidence_score < 0.80`, `requires_review = true`
- `audit_document_processing`: `requires_review = true`
- `silver_human_review`: review record created, status `PENDING`
- Gold exception: `LOW_CONFIDENCE`, status `OPEN`
- Agent: cannot self-approve → human approval required demonstrated

---

### Scenario 8 — Human Review
**Sample shipment:** SHP-100698  
**What to show:**
- `silver_human_review`: `review_status = APPROVED`, reviewer_id populated
- `audit_human_reviews`: decision recorded with corrected_value
- Gold document promoted post-approval
- Demonstrate: agent correctly routes to human; human approves; Gold updated
- Show the full governance trail from exception creation to closure

---

## Demo Execution Order

```
1. Run 12_Final_Demo notebook
2. Each scenario cell: show source → Bronze → Silver → Gold → Audit → Agent
3. End with summary: record counts per layer, audit totals, exception status board
```

---

## Expected Outputs at End of Demo

| Output | Expected Value |
|--------|---------------|
| Total shipments | 3000 |
| Bronze carrier events | ~14,838 |
| POD documents processed | ~2,880 |
| Missing POD | ~120 |
| Duplicate events quarantined | ~5% |
| Late arrivals flagged | ~4% |
| Schema drift quarantined | ~3% |
| Low-confidence → review | ~4% |
| Gold exceptions open | Sum of all anomaly types |
| SLA breaches | Shipments where actual > promised |
| Human reviews completed | All PENDING resolved |
| Audit rows across 8 tables | Non-zero for every table |

---

## Demonstration Checklist

- [ ] All 3000 shipments visible in `gold_shipment_tracking`
- [ ] All 8 audit tables populated
- [ ] At least one row in `quarantine_carrier_events`
- [ ] At least one row in `quarantine_documents`
- [ ] All 4 UC functions callable and returning non-empty results
- [ ] All 4 agent classes execute without error
- [ ] Human review queue: at least one APPROVED, one REJECTED record
- [ ] SLA table: both SLA_MET and SLA_BREACHED present
- [ ] Every demo scenario returns the expected agent output
