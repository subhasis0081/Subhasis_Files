# Gold Rules — Shipment Delivery Intelligence — Pod 13

Catalog: `dbx_cohort1_wave1` | Schema: `sch_pod13`

---

## Principle

Gold contains **business-ready facts**. Every Gold table is derived from approved Silver data. Gold rows are final, trusted, and the source of truth for agents and reporting. No row enters Gold without passing Silver quality controls.

---

## Rules (Mandatory — Enforce in Every Gold Notebook)

### Rule 1 — `gold_shipment_tracking`: One Row Per Shipment

```python
# Use window function to select the latest trusted event per shipment
from pyspark.sql.window import Window
from pyspark.sql import functions as F

w = Window.partitionBy("shipment_id").orderBy(F.desc("event_timestamp_utc"))

gold_tracking = (
    silver_events
    .filter(F.col("is_duplicate") == False)
    .withColumn("rn", F.row_number().over(w))
    .filter(F.col("rn") == 1)
    .drop("rn")
)
```

Required columns: `shipment_id`, `latest_status`, `delivery_state`, `data_quality_state`, `has_open_exception`, `gold_updated_at`.

---

### Rule 2 — `gold_shipment_event`: One Row Per Canonical Event

- Source: `silver_carrier_events` where `is_duplicate = false`
- Every row carries: `event_hash`, `event_sequence`, and provenance (`source_table`)
- Events are never modified once written to Gold

---

### Rule 3 — `gold_delivery_document`: Approved or High-Confidence Only

```python
gold_docs = silver_extractions.filter(
    (F.col("confidence_score") >= 0.80) |
    (F.col("review_status") == "APPROVED")
)
```

- Low-confidence documents must have a corresponding `APPROVED` human review record before entering Gold
- Document provenance is carried: `content_hash`, `model_version`, `prompt_version`

---

### Rule 4 — `gold_delivery_exception`: Create for All Anomaly Types

Exception types and their triggers:

| Exception Type | Trigger Condition |
|----------------|-------------------|
| `DAMAGED_DELIVERY` | `delivery_result = 'DAMAGED'` in silver extraction |
| `PARTIAL_DELIVERY` | `delivery_result = 'PARTIAL'` in silver extraction |
| `MISSING_DELIVERY_EVIDENCE` | No POD document AND no `delivered` event |
| `LOW_CONFIDENCE` | `confidence_score < 0.80` and no approved review |
| `MALFORMED_FEED` | Shipment has rows in `quarantine_carrier_events` |
| `SLA_BREACH` | `variance_hours > 0` in `gold_shipment_sla` |
| `IDENTIFIER_MISMATCH` | `match_method = 'FUZZY'` and `match_confidence < 0.90` |

All new exceptions created with `exception_status = 'OPEN'`.  
Closing an exception requires an `APPROVED` record in `audit_human_reviews`.

---

### Rule 5 — `gold_shipment_sla`: Deterministic Variance Calculation

```python
SLA_RULE_VERSION = "sla-v1.0"

gold_sla = gold_tracking.join(silver_shipment, "shipment_id") \
    .withColumn("variance_hours",
        (F.unix_timestamp("actual_delivery_timestamp_utc") -
         F.unix_timestamp(F.col("promised_delivery_date").cast("timestamp"))) / 3600.0
    ) \
    .withColumn("sla_result",
        F.when(F.col("variance_hours") <= 0, "SLA_MET").otherwise("SLA_BREACHED")
    ) \
    .withColumn("rule_version", F.lit(SLA_RULE_VERSION)) \
    .withColumn("calculated_at", F.current_timestamp())
```

- `actual <= promised` → `SLA_MET`
- `actual > promised` → `SLA_BREACHED`
- Never override a breach result without evidence of an approved human review in `audit_human_reviews`

---

## Fully Qualified Table Names

All cross-notebook references use fully qualified names:

```python
# Correct — always use fully qualified names
spark.table("dbx_cohort1_wave1.sch_pod13.silver_carrier_events")
spark.sql("SELECT * FROM dbx_cohort1_wave1.sch_pod13.gold_shipment_tracking")

# Incorrect — do NOT rely on USE SCHEMA being set by another notebook
spark.table("silver_carrier_events")
```

---

## Write Pattern

```python
(df.write
   .format("delta")
   .mode("overwrite")
   .option("overwriteSchema", "true")
   .saveAsTable(f"{CATALOG}.{SCHEMA}.{table_name}"))
```

Always follow with table and column comments via SQL COMMENT statements.

---

## Gold Audit Logging

Every Gold notebook logs to `audit_pipeline_execution` and `audit_reconciliation`.

For exceptions, log to `audit_data_quality`:

```python
spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_data_quality VALUES (
    '{qc_id}', '{EXECUTION_ID}', 'gold', 'gold_exception_count',
    'gold_delivery_exception',
    'exception_status = OPEN',
    {total}, {passed}, {failed}, {pass_rate}, '{status}', current_timestamp()
)
""")
```

---

## Gold Quality Checks

| Check | Expression |
|-------|-----------|
| One row per shipment in `gold_shipment_tracking` | `COUNT(*) = COUNT(DISTINCT shipment_id)` |
| No null shipment_id in any Gold table | `shipment_id IS NOT NULL` |
| SLA variance reproducible | Re-run produces same variance_hours |
| Gold docs have confidence >= 0.80 or APPROVED review | `confidence_score >= 0.80 OR review_status = 'APPROVED'` |
| All open exceptions have valid exception_type | `exception_type IN (valid_types)` |
