# Quality Tests — Shipment Delivery Intelligence — Pod 13

Catalog: `dbx_cohort1_wave1` | Schema: `sch_pod13`

---

## Test Structure

All test results are written to `audit_data_quality`. Tests are organised by layer. Each test logs: `check_layer`, `check_name`, `table_name`, `check_expression`, `total_records`, `passed_records`, `failed_records`, `pass_rate`, `status`.

Status thresholds: `PASS` = pass_rate >= 99%, `WARN` = pass_rate >= 95%, `FAIL` = pass_rate < 95%.

---

## Bronze Tests

### BRZ-01: Record Count Reconciliation
```python
# Input count from source file = Bronze table count
# Check: abs(source_count - bronze_count) == 0
check: "source_count = bronze_count"
tables: all 6 bronze tables
```

### BRZ-02: Mandatory Metadata Completeness
```python
# source_file, source_record_id, batch_id, ingested_ts_utc must not be null
check: "source_file IS NOT NULL AND source_record_id IS NOT NULL AND batch_id IS NOT NULL AND ingested_ts_utc IS NOT NULL"
tables: all 6 bronze tables
```

### BRZ-03: Batch ID Consistency
```python
# All rows in a given ingestion run share the same batch_id
check: "COUNT(DISTINCT batch_id) = 1 per run"
tables: all 6 bronze tables
```

### BRZ-04: Content Hash Presence (Documents)
```python
check: "content_hash IS NOT NULL AND LENGTH(content_hash) = 64"
table: bronze_delivery_documents
```

---

## Silver Tests

### SLV-01: No Duplicate event_hash in Non-Duplicate Events
```python
check: "COUNT(*) = COUNT(DISTINCT event_hash) WHERE is_duplicate = false"
table: silver_carrier_events
```

### SLV-02: Event Sequence Monotonic Per Shipment
```python
# For each shipment, event_sequence values must be 1, 2, 3... without gaps
check: "MIN(event_sequence) = 1 AND MAX(event_sequence) = COUNT(*)"
table: silver_carrier_events (grouped by shipment_id)
```

### SLV-03: All Dispatch Shipment IDs Exist in silver_shipment
```python
check: "shipment_id IN (SELECT shipment_id FROM silver_shipment)"
table: silver_dispatch
```

### SLV-04: Tracking Map Reconciled with Manifest
```python
check: "reconciled_with_manifest = true"
table: silver_tracking_map
# Warn if any unreconciled rows; fail if > 5%
```

### SLV-05: Late Arrival Detection — Positive Cases
```python
# At least some late arrivals present (data generation guarantee)
check: "COUNT(*) > 0 WHERE is_late_arrival = true"
table: silver_carrier_events
```

### SLV-06: Late Arrival Detection — Negative Cases
```python
# Non-late rows correctly flagged
check: "arrival_lag_sec <= 3600 WHERE is_late_arrival = false"
table: silver_carrier_events
```

### SLV-07: Schema Drift Quarantine
```python
# Drifted events are in quarantine, not in silver
check: "COUNT(*) > 0"
table: quarantine_carrier_events
```

### SLV-08: Confidence Score Range
```python
check: "confidence_score >= 0.0 AND confidence_score <= 1.0"
table: silver_document_extraction
```

### SLV-09: Low Confidence Routed to Review
```python
check: "requires_review = true WHERE confidence_score < 0.80"
table: silver_document_extraction
```

### SLV-10: Human Review Completeness
```python
# All expected review types present
check: "COUNT(DISTINCT review_type) >= 3"
# Expected: LOW_CONFIDENCE, EXCEPTION, STATUS_CHANGE at minimum
table: silver_human_review
```

---

## Gold Tests

### GLD-01: Uniqueness — gold_shipment_tracking
```python
check: "COUNT(*) = COUNT(DISTINCT shipment_id)"
table: gold_shipment_tracking
```

### GLD-02: Uniqueness — gold_shipment_sla
```python
check: "COUNT(*) = COUNT(DISTINCT shipment_id)"
table: gold_shipment_sla
```

### GLD-03: No Null shipment_id in Any Gold Table
```python
check: "shipment_id IS NOT NULL"
tables: all 5 gold tables
```

### GLD-04: Gold Document Confidence Threshold
```python
check: "confidence_score >= 0.80 OR review_status = 'APPROVED'"
table: gold_delivery_document
```

### GLD-05: SLA Arithmetic Correctness
```python
# variance_hours = (actual_delivery - promised_delivery) in hours
# sla_result = SLA_MET when variance_hours <= 0, SLA_BREACHED otherwise
check: "(variance_hours <= 0 AND sla_result = 'SLA_MET') OR (variance_hours > 0 AND sla_result = 'SLA_BREACHED')"
table: gold_shipment_sla
```

### GLD-06: SLA Both Outcomes Present
```python
check: "COUNT(DISTINCT sla_result) = 2"
# Both SLA_MET and SLA_BREACHED must exist in the dataset
table: gold_shipment_sla
```

### GLD-07: Exception Types Valid
```python
VALID_EXCEPTION_TYPES = ['DAMAGED_DELIVERY','PARTIAL_DELIVERY','MISSING_DELIVERY_EVIDENCE',
                          'LOW_CONFIDENCE','MALFORMED_FEED','SLA_BREACH','IDENTIFIER_MISMATCH']
check: "exception_type IN ('DAMAGED_DELIVERY','PARTIAL_DELIVERY','MISSING_DELIVERY_EVIDENCE','LOW_CONFIDENCE','MALFORMED_FEED','SLA_BREACH','IDENTIFIER_MISMATCH')"
table: gold_delivery_exception
```

### GLD-08: All Scenarios Traceable
```python
# 8 demo shipment IDs must exist in gold_shipment_tracking
DEMO_SHIPMENTS = ['SHP-100011','SHP-102253','SHP-102706','SHP-100002',
                  'SHP-100012','SHP-100636','SHP-100141','SHP-100698']
check: "COUNT(*) = 8 WHERE shipment_id IN (demo_shipments)"
table: gold_shipment_tracking
```

---

## Audit Tests

### AUD-01: All 8 Audit Tables Populated
```python
# Each audit table must have at least 1 row after the pipeline runs
tables: [audit_pipeline_execution, audit_reconciliation, audit_api_failures,
         audit_schema_drift, audit_document_processing, audit_data_quality,
         audit_human_reviews, audit_agent_activity]
check: "COUNT(*) > 0 for each table"
```

### AUD-02: Pipeline Execution — No FAILED Runs
```python
check: "COUNT(*) = 0 WHERE status = 'FAILED'"
table: audit_pipeline_execution
# Warn on FAILED; do not mark overall as PASS
```

### AUD-03: Human Review Decisions Complete
```python
check: "review_status IN ('APPROVED','REJECTED','MODIFIED') WHERE reviewed_at IS NOT NULL"
table: audit_human_reviews
```

---

## Quality Check Helper (Standard Pattern)

```python
import uuid
from datetime import datetime, timezone

def log_qc(check_layer, check_name, table_name, check_expr, df=None):
    if df is None:
        df = spark.table(f"{CATALOG}.{SCHEMA}.{table_name}")
    total   = df.count()
    passed  = df.filter(check_expr).count()
    failed  = total - passed
    rate    = round((passed / total * 100), 2) if total > 0 else 0.0
    status  = "PASS" if rate >= 99 else ("WARN" if rate >= 95 else "FAIL")
    qc_id   = str(uuid.uuid4())
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_data_quality VALUES
    ('{qc_id}', '{EXECUTION_ID}', '{check_layer}', '{check_name}',
     '{table_name}', "{check_expr}", {total}, {passed}, {failed},
     {rate}, '{status}', current_timestamp())
    """)
    print(f"  [{status}] {check_name}: {passed}/{total} ({rate}%)")
    return status
```
