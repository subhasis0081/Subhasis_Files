# Silver Rules — Shipment Delivery Intelligence — Pod 13

Catalog: `dbx_cohort1_wave1` | Schema: `sch_pod13`

---

## Principle

Silver applies **deterministic, reproducible controls**. Every transformation is auditable, reversible, and testable. Silver never discards — it routes anomalies to quarantine tables with full provenance.

---

## Rules (Mandatory — Enforce in Every Silver Notebook)

### Rule 1 — Normalise AND Preserve Originals

```python
# Always keep the original value alongside the normalised value
df = df.withColumn("carrier_raw", F.col("carrier")) \
       .withColumn("carrier_normalized", F.upper(F.trim(F.col("carrier"))))

df = df.withColumn("tracking_number_raw", F.col("tracking_number")) \
       .withColumn("tracking_number_normalized", F.upper(F.regexp_replace(F.col("tracking_number"), r"\s+", "")))
```

Normalise: uppercase, trim whitespace, remove special characters where applicable.

---

### Rule 2 — Event Hash (Deduplication Key)

```python
from pyspark.sql import functions as F

df = df.withColumn("event_hash",
    F.sha2(
        F.concat_ws("||",
            F.col("shipment_id"),
            F.col("tracking_number"),
            F.col("event_status"),
            F.col("event_timestamp")
        ), 256
    )
)
```

- `event_hash` = SHA-256 of (shipment_id ∥ tracking_number ∥ event_status ∥ event_timestamp)
- This is the deduplication key across all carrier event processing

---

### Rule 3 — Duplicate Removal via Window Ranking

```python
from pyspark.sql.window import Window

w = Window.partitionBy("event_hash").orderBy("event_id")
df = df.withColumn("dedup_rank", F.row_number().over(w)) \
       .withColumn("is_duplicate", F.col("dedup_rank") > 1)

silver_df = df.filter(F.col("dedup_rank") == 1)
```

Duplicate rows are flagged `is_duplicate = true` in Silver, NOT dropped entirely. Keep them for audit.

---

### Rule 4 — Event Sequencing

```python
w_seq = Window.partitionBy("shipment_id").orderBy("event_timestamp_utc", "event_id")
df = df.withColumn("event_sequence", F.row_number().over(w_seq))
```

---

### Rule 5 — Late Arrival Detection

```python
LATE_THRESHOLD_SEC = 3600  # 1 hour

df = df.withColumn("arrival_lag_sec",
    F.unix_timestamp(F.current_timestamp()) - F.unix_timestamp(F.col("event_timestamp_utc"))
).withColumn("is_late_arrival",
    F.col("arrival_lag_sec") > LATE_THRESHOLD_SEC
)
```

---

### Rule 6 — UTC Timestamp Conversion

```python
# Convert local timestamps to UTC
df = df.withColumn("event_timestamp_utc",
    F.to_utc_timestamp(F.col("event_timestamp_local"), F.col("timezone"))
)
# Always retain original timezone string in a separate column
```

---

### Rule 7 — Schema Drift Handling

```python
EXPECTED_FIELDS = {"shipment_id", "tracking_number", "event_status", "event_timestamp", "carrier", "payload_version"}
MANDATORY_FIELDS = {"shipment_id", "event_status"}

# 1. Unexpected fields → _rescued_data (handled by Spark schema enforcement)
# 2. Missing mandatory keys → quarantine
def check_mandatory(row_dict):
    missing = MANDATORY_FIELDS - set(row_dict.keys())
    return list(missing)

# 3. New payload versions → log to audit_schema_drift
# 4. QUARANTINE action for missing mandatory fields
```

When schema drift is detected:
- Log to `audit_schema_drift` with: `drift_id`, `execution_id`, `shipment_id`, `carrier`, `expected_version`, `actual_version`, `drifted_fields`, `missing_fields`, `action_taken`, `detected_at`
- Route to `quarantine_carrier_events` for missing mandatory fields

---

### Rule 8 — Document Extraction

```python
import re
import hashlib

MODEL_VERSION  = "regex-v1.0"
PROMPT_VERSION = "pod-parser-v1.0"
CONFIDENCE_THRESHOLD = 0.80

def extract_pod(content_text: str) -> dict:
    delivery_result    = extract_delivery_result(content_text)
    recipient          = extract_recipient(content_text)
    exception_reason   = extract_exception(content_text)
    damage_note        = extract_damage(content_text)
    confidence         = compute_confidence(delivery_result, recipient, exception_reason)
    requires_review    = confidence < CONFIDENCE_THRESHOLD
    return {
        "delivery_result": delivery_result,
        "recipient_indicator": recipient,
        "exception_reason": exception_reason,
        "damage_note": damage_note,
        "confidence_score": confidence,
        "requires_review": requires_review,
        "model_version": MODEL_VERSION,
        "prompt_version": PROMPT_VERSION,
        "content_hash": hashlib.sha256(content_text.encode()).hexdigest()
    }
```

---

### Rule 9 — Human Review Routing

```python
REVIEW_THRESHOLD = 0.80

# Route to silver_human_review when:
# 1. confidence_score < 0.80
# 2. identifier mapping used fuzzy match
# 3. exception closure requires human decision
```

Human review record must include: `review_id`, `shipment_id`, `review_type`, `review_status = 'PENDING'`, `original_value` (JSON).

---

## Canonical Status Values

Valid values for `canonical_status` in `silver_carrier_events`:

```
label_created
picked_up
in_transit
out_for_delivery
delivered
exception
returned
```

---

## Quarantine Rules

| Condition | Destination |
|-----------|-------------|
| Missing mandatory JSON keys | `quarantine_carrier_events` |
| Unresolvable payload version | `quarantine_carrier_events` |
| Document extraction total failure | `quarantine_documents` |

Quarantine tables carry full provenance: `shipment_id`, `batch_id`, `reason`, `raw_data`, `quarantined_at`.

---

## Quality Checks per Silver Table

| Table | Check |
|-------|-------|
| `silver_shipment` | No null shipment_id, no null carrier_normalized |
| `silver_dispatch` | All dispatch shipment_ids exist in silver_shipment |
| `silver_carrier_events` | No duplicate event_hash in non-duplicate rows |
| `silver_carrier_events` | event_sequence monotonically increasing per shipment |
| `silver_document_extraction` | confidence_score between 0.0 and 1.0 |
| `silver_document_extraction` | requires_review = true when confidence < 0.80 |
