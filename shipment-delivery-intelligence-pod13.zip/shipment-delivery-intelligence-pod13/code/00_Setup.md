# 00 — Infrastructure Setup: Catalog, Schema, Volume, Audit Tables
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Creates the foundational Unity Catalog infrastructure for the **Shipment Delivery Intelligence** project (Pod 13).

| Component | Name | Purpose |
|-----------|------|---------|
| Catalog | `dbx_cohort1_wave1` | Top-level UC container |
| Schema | `sch_pod13` | Bronze, Silver, Gold, Audit tables |
| Volume | `vol_pod13` | File storage for landing, logs, checkpoints, quarantine, archive |
| Audit Tables (×8) | `audit_*` | Full traceability across all pipeline layers |

---

```python
# ============================================================
# 00_Setup — Infrastructure: Catalog, Schema, Volume, Audit Tables
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
from datetime import datetime, timezone

CATALOG     = "dbx_cohort1_wave1"
SCHEMA      = "sch_pod13"
VOLUME      = "vol_pod13"
VOLUME_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"

EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)

print(f"Execution ID : {EXECUTION_ID}")
print(f"Started at   : {STARTED_AT.isoformat()}")
print(f"Target       : {CATALOG}.{SCHEMA}  (volume: {VOLUME})")
```

---

```python
# --------------------------------------------------
# Step 1: Create catalog, schema, and volume
# --------------------------------------------------
print("\n=== Step 1: Create Catalog, Schema, Volume ===")

spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")
spark.sql(f"COMMENT ON CATALOG {CATALOG} IS 'Shipment Delivery Intelligence — project catalog'")
print(f"  Catalog '{CATALOG}' ready.")

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA}")
spark.sql(f"COMMENT ON SCHEMA {CATALOG}.{SCHEMA} IS 'Shipment Delivery Intelligence — Pod 13 schema (Bronze, Silver, Gold, Audit)'")
print(f"  Schema '{CATALOG}.{SCHEMA}' ready.")

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.{VOLUME}")
print(f"  Volume '{CATALOG}.{SCHEMA}.{VOLUME}' ready.")
```

---

```python
# --------------------------------------------------
# Step 2: Create volume folders
# --------------------------------------------------
print("\n=== Step 2: Create Volume Folders ===")

folders = ["landing", "logs", "checkpoints", "quarantine", "archive"]
for folder in folders:
    path = f"{VOLUME_PATH}/{folder}"
    dbutils.fs.mkdirs(path)
    print(f"  Created: {path}")
```

---

```python
# --------------------------------------------------
# Step 3: Create audit tables
# --------------------------------------------------
print("\n=== Step 3: Create Audit Tables ===")

# 3.1 audit_pipeline_execution
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.audit_pipeline_execution (
    execution_id       STRING     COMMENT 'UUID identifying this pipeline/notebook run',
    notebook_name      STRING     COMMENT 'Name of the notebook that executed',
    layer              STRING     COMMENT 'Pipeline layer: infra, bronze, silver, gold, test, demo',
    started_at         TIMESTAMP  COMMENT 'Execution start time (UTC)',
    completed_at       TIMESTAMP  COMMENT 'Execution completion time (UTC)',
    status             STRING     COMMENT 'Execution status: RUNNING, SUCCESS, FAILED',
    records_processed  BIGINT     COMMENT 'Number of records processed in this run',
    error_message      STRING     COMMENT 'Error message if status = FAILED, otherwise NULL',
    created_at         TIMESTAMP  COMMENT 'Row creation timestamp (UTC)'
) USING DELTA
""")
spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.audit_pipeline_execution IS 'Tracks every notebook and pipeline execution with start/end time, status, and record count'")
print("  Created: audit_pipeline_execution")

# 3.2 audit_reconciliation
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.audit_reconciliation (
    reconciliation_id  STRING     COMMENT 'UUID for this reconciliation record',
    execution_id       STRING     COMMENT 'FK to audit_pipeline_execution',
    source_table       STRING     COMMENT 'Upstream source table name',
    target_table       STRING     COMMENT 'Downstream target table name',
    source_count       BIGINT     COMMENT 'Record count from source',
    target_count       BIGINT     COMMENT 'Record count in target',
    matched_count      BIGINT     COMMENT 'Records successfully matched',
    unmatched_count    BIGINT     COMMENT 'Records that could not be matched',
    status             STRING     COMMENT 'Reconciliation status: MATCHED, PARTIAL, FAILED',
    reconciled_at      TIMESTAMP  COMMENT 'When reconciliation was performed (UTC)'
) USING DELTA
""")
spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.audit_reconciliation IS 'Tracks reconciliation results between source and target tables across pipeline layers'")
print("  Created: audit_reconciliation")

# 3.3 audit_api_failures
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.audit_api_failures (
    failure_id         STRING     COMMENT 'UUID for this failure record',
    execution_id       STRING     COMMENT 'FK to audit_pipeline_execution',
    shipment_id        STRING     COMMENT 'Shipment affected by the API failure',
    carrier            STRING     COMMENT 'Carrier name (UPS, FEDEX, DHL, USPS, ONTRAC, LASERSHIP)',
    api_endpoint       STRING     COMMENT 'Carrier API endpoint that was called',
    error_type         STRING     COMMENT 'Type of failure: TIMEOUT, PARSE_ERROR, AUTH_ERROR, NOT_FOUND',
    error_message      STRING     COMMENT 'Detailed error message',
    raw_payload        STRING     COMMENT 'Raw API response payload for debugging',
    failed_at          TIMESTAMP  COMMENT 'When the failure occurred (UTC)'
) USING DELTA
""")
spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.audit_api_failures IS 'Logs carrier API failures: malformed JSON, timeouts, parse errors, and missing endpoints'")
print("  Created: audit_api_failures")

# 3.4 audit_schema_drift
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.audit_schema_drift (
    drift_id           STRING     COMMENT 'UUID for this schema drift record',
    execution_id       STRING     COMMENT 'FK to audit_pipeline_execution',
    shipment_id        STRING     COMMENT 'Shipment with the drifted payload',
    carrier            STRING     COMMENT 'Carrier name',
    expected_version   STRING     COMMENT 'Expected payload version',
    actual_version     STRING     COMMENT 'Actual payload version received',
    drifted_fields     STRING     COMMENT 'JSON array of unexpected or changed field names',
    missing_fields     STRING     COMMENT 'JSON array of mandatory fields that are missing',
    action_taken       STRING     COMMENT 'Action taken: QUARANTINE, RESCUE, MAPPING_UPDATE',
    detected_at        TIMESTAMP  COMMENT 'When schema drift was detected (UTC)'
) USING DELTA
""")
spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.audit_schema_drift IS 'Tracks JSON payload schema drift: unexpected fields, missing mandatory keys, and version mismatches'")
print("  Created: audit_schema_drift")

# 3.5 audit_document_processing
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.audit_document_processing (
    doc_process_id     STRING     COMMENT 'UUID for this document processing record',
    execution_id       STRING     COMMENT 'FK to audit_pipeline_execution',
    shipment_id        STRING     COMMENT 'Shipment associated with the document',
    document_path      STRING     COMMENT 'Path to the POD document file',
    content_hash       STRING     COMMENT 'SHA-256 hash of document content for provenance',
    extraction_result  STRING     COMMENT 'JSON result from extraction',
    confidence_score   DOUBLE     COMMENT 'Extraction confidence score (0.0 to 1.0)',
    requires_review    BOOLEAN    COMMENT 'True if confidence < 0.80',
    model_version      STRING     COMMENT 'Version of the extraction model/prompt used',
    prompt_version     STRING     COMMENT 'Version of the extraction prompt',
    processed_at       TIMESTAMP  COMMENT 'When the document was processed (UTC)'
) USING DELTA
""")
spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.audit_document_processing IS 'Tracks POD document extraction: result, confidence, model/prompt version, and review routing'")
print("  Created: audit_document_processing")

# 3.6 audit_data_quality
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.audit_data_quality (
    qc_id              STRING     COMMENT 'UUID for this quality check record',
    execution_id       STRING     COMMENT 'FK to audit_pipeline_execution',
    check_layer        STRING     COMMENT 'Layer being checked: bronze, silver, gold',
    check_name         STRING     COMMENT 'Name of the quality check',
    table_name         STRING     COMMENT 'Table that was checked',
    check_expression   STRING     COMMENT 'SQL expression used for the check',
    total_records      BIGINT     COMMENT 'Total records evaluated',
    passed_records     BIGINT     COMMENT 'Records that passed the check',
    failed_records     BIGINT     COMMENT 'Records that failed the check',
    pass_rate          DOUBLE     COMMENT 'Percentage of records that passed (0.0 to 100.0)',
    status             STRING     COMMENT 'Check status: PASS, WARN, FAIL',
    checked_at         TIMESTAMP  COMMENT 'When the quality check ran (UTC)'
) USING DELTA
""")
spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.audit_data_quality IS 'Stores results of all data quality checks across Bronze, Silver, and Gold layers'")
print("  Created: audit_data_quality")

# 3.7 audit_human_reviews
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.audit_human_reviews (
    review_id          STRING     COMMENT 'UUID for this human review record',
    execution_id       STRING     COMMENT 'FK to audit_pipeline_execution',
    shipment_id        STRING     COMMENT 'Shipment requiring human review',
    review_type        STRING     COMMENT 'Type: LOW_CONFIDENCE, EXCEPTION, IDENTIFIER_MAPPING, SLA_OVERRIDE, STATUS_CHANGE',
    review_status      STRING     COMMENT 'Status: PENDING, APPROVED, REJECTED, MODIFIED',
    reviewer_id        STRING     COMMENT 'Identifier of the human reviewer',
    original_value     STRING     COMMENT 'Original value before review (JSON)',
    corrected_value    STRING     COMMENT 'Corrected value after review (JSON)',
    decision           STRING     COMMENT 'Final decision: APPROVED, REJECTED, MODIFIED',
    reviewed_at        TIMESTAMP  COMMENT 'When the review was completed (UTC)'
) USING DELTA
""")
spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.audit_human_reviews IS 'Tracks all human review decisions: low-confidence extraction, exception closure, status changes, and SLA overrides'")
print("  Created: audit_human_reviews")

# 3.8 audit_agent_activity
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.audit_agent_activity (
    agent_activity_id        STRING     COMMENT 'UUID for this agent activity record',
    execution_id             STRING     COMMENT 'FK to audit_pipeline_execution',
    agent_name               STRING     COMMENT 'Agent name: ShipmentInvestigation, DocumentIntelligence, Exception, Supervisor',
    action_type              STRING     COMMENT 'Type of action: INVESTIGATE, EXTRACT, RECOMMEND, ROUTE, RETRY',
    shipment_id              STRING     COMMENT 'Shipment the agent acted on',
    tool_used                STRING     COMMENT 'UC function or tool the agent called',
    input_summary            STRING     COMMENT 'Summary of the agent input (JSON)',
    output_summary           STRING     COMMENT 'Summary of the agent output (JSON)',
    requires_human_approval  BOOLEAN    COMMENT 'Whether this activity requires human approval',
    activity_timestamp       TIMESTAMP  COMMENT 'When the agent activity occurred (UTC)'
) USING DELTA
""")
spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.audit_agent_activity IS 'Logs all agent actions: investigation, extraction, remediation recommendations, and routing decisions'")
print("  Created: audit_agent_activity")
```

---

```python
# --------------------------------------------------
# Step 4: Verify infrastructure
# --------------------------------------------------
print("\n=== Step 4: Verification ===")

cat_exists = spark.sql(f"SHOW CATALOGS LIKE '{CATALOG}'").count() > 0
print(f"  Catalog exists : {cat_exists}")

sch_exists = spark.sql(f"SHOW SCHEMAS IN {CATALOG} LIKE '{SCHEMA}'").count() > 0
print(f"  Schema exists  : {sch_exists}")

print("  Volume folders:")
for folder in folders:
    path = f"{VOLUME_PATH}/{folder}"
    try:
        items = dbutils.fs.ls(path)
        print(f"    {folder}/  ({len(items)} items)")
    except Exception as e:
        print(f"    {folder}/  ERROR: {e}")

audit_tables = spark.sql(f"SHOW TABLES IN {CATALOG}.{SCHEMA}")
print("\n  Audit tables created:")
audit_count = 0
for row in audit_tables.collect():
    print(f"    {row['tableName']}")
    audit_count += 1

print(f"\n  Total tables: {audit_count} (expected 8)")

COMPLETED_AT = datetime.now(timezone.utc)
print(f"\n=== Setup complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Execution ID : {EXECUTION_ID}")
print(f"  Duration     : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
```
