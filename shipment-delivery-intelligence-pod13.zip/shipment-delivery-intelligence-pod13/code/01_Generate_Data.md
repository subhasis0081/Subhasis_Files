# 01 — Generate Synthetic Data
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/DATA_MODEL.md` and `architecture/DEMO_PLAN.md` for schema and scenario definitions.

Generates 3000 synthetic shipments with realistic anomalies. Writes all source files to the Volume landing folder.

---

```python
# ============================================================
# 01_Generate_Data — Synthetic logistics source data
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
import csv
import json
import random
import hashlib
import os
from datetime import datetime, timezone, timedelta

CATALOG     = "dbx_cohort1_wave1"
SCHEMA      = "sch_pod13"
VOLUME      = "vol_pod13"
VOLUME_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"
LANDING     = f"{VOLUME_PATH}/landing"

EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)
random.seed(42)

print(f"Execution ID : {EXECUTION_ID}")
print(f"Started at   : {STARTED_AT.isoformat()}")
print(f"Landing path : {LANDING}")

# --------------------------------------------------
# Constants
# --------------------------------------------------
TOTAL_SHIPMENTS   = 3000
CARRIERS          = ["UPS", "FEDEX", "DHL", "USPS", "ONTRAC", "LASERSHIP"]
STATUS_LIFECYCLE  = ["label_created", "picked_up", "in_transit", "out_for_delivery", "delivered"]
WAREHOUSES        = ["WH-ATL-01", "WH-CHI-02", "WH-LAX-03", "WH-NYC-04", "WH-DAL-05"]
CITIES            = ["Atlanta", "Chicago", "Los Angeles", "New York", "Dallas",
                     "Seattle", "Miami", "Denver", "Boston", "Phoenix"]
STATES            = ["GA", "IL", "CA", "NY", "TX", "WA", "FL", "CO", "MA", "AZ"]

# Anomaly rates
DUPLICATE_RATE     = 0.05   # ~5%
LATE_ARRIVAL_RATE  = 0.04   # ~4%
SCHEMA_DRIFT_RATE  = 0.03   # ~3%
DAMAGED_RATE       = 0.03   # ~3%
PARTIAL_RATE       = 0.02   # ~2%
LOW_CONF_RATE      = 0.04   # ~4%
MISSING_POD_RATE   = 0.04   # ~4%

# Demo shipment IDs — must exist in generated data
DEMO_SHIPMENTS = {
    "SHP-100011": "normal",
    "SHP-102253": "duplicate",
    "SHP-102706": "late_arrival",
    "SHP-100002": "schema_drift",
    "SHP-100012": "damaged",
    "SHP-100636": "missing_pod",
    "SHP-100141": "low_confidence",
    "SHP-100698": "human_review",
}
```

---

```python
# --------------------------------------------------
# Helper functions
# --------------------------------------------------
def make_shipment_id(n):
    return f"SHP-{100000 + n}"

def make_tracking_number(carrier, n):
    prefix = {"UPS": "1Z", "FEDEX": "77", "DHL": "JD", "USPS": "94", "ONTRAC": "C1", "LASERSHIP": "L0"}
    return f"{prefix.get(carrier, 'XX')}{random.randint(100000000, 999999999):09d}{n:04d}"

def random_date(start_days_ago=90, end_days_ago=0):
    delta = random.randint(end_days_ago, start_days_ago)
    return (datetime.now(timezone.utc) - timedelta(days=delta)).replace(
        hour=random.randint(6, 20), minute=random.randint(0, 59), second=0, microsecond=0
    )

def format_ts(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")

def format_date(dt):
    return dt.strftime("%Y-%m-%d")

print("  Helper functions defined.")
```

---

```python
# --------------------------------------------------
# Step 1: Generate shipment_manifest.csv
# --------------------------------------------------
print("\n=== Step 1: Generate shipment_manifest.csv ===")

manifests = []
for n in range(TOTAL_SHIPMENTS):
    shipment_id = make_shipment_id(n)
    carrier     = random.choice(CARRIERS)
    tracking_no = make_tracking_number(carrier, n)
    idx         = n % len(CITIES)
    ship_date   = random_date(90, 5)
    promised    = ship_date + timedelta(days=random.randint(2, 7))

    manifests.append({
        "shipment_id":           shipment_id,
        "order_id":              f"ORD-{200000 + n}",
        "carrier":               carrier,
        "tracking_number":       tracking_no,
        "origin_warehouse":      random.choice(WAREHOUSES),
        "destination_city":      CITIES[idx],
        "destination_state":     STATES[idx],
        "destination_zip":       f"{10000 + (n * 7) % 89999:05d}",
        "promised_delivery_date": format_date(promised),
        "weight_kg":             round(random.uniform(0.5, 50.0), 2),
        "shipment_date":         format_date(ship_date),
    })

manifest_path = f"{LANDING}/shipment_manifest.csv"
manifest_fields = list(manifests[0].keys())

with open(manifest_path.replace("/Volumes", "/dbfs/mnt/Volumes", 1)
          if manifest_path.startswith("/Volumes") else manifest_path, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=manifest_fields)
    writer.writeheader()
    writer.writerows(manifests)

# Use dbutils to write to Volume path
dbutils.fs.put(manifest_path,
    "\n".join([",".join(manifest_fields)] + [",".join(str(r[k]) for k in manifest_fields) for r in manifests]),
    overwrite=True
)

print(f"  shipment_manifest.csv : {len(manifests)} rows")
print(f"  Sample: {manifests[0]}")
```

---

```python
# --------------------------------------------------
# Step 2: Generate warehouse_dispatch.csv
# --------------------------------------------------
print("\n=== Step 2: Generate warehouse_dispatch.csv ===")

dispatches = []
for m in manifests:
    ship_dt = datetime.strptime(m["shipment_date"], "%Y-%m-%d").replace(tzinfo=timezone.utc)
    dispatch_ts = ship_dt + timedelta(hours=random.randint(1, 8))
    dispatches.append({
        "dispatch_id":        f"DSP-{300000 + manifests.index(m)}",
        "shipment_id":        m["shipment_id"],
        "warehouse_id":       m["origin_warehouse"],
        "dispatch_timestamp": format_ts(dispatch_ts),
        "operator_id":        f"OPR-{random.randint(100, 999)}",
        "dispatch_status":    "DISPATCHED",
    })

dispatch_fields = list(dispatches[0].keys())
dbutils.fs.put(f"{LANDING}/warehouse_dispatch.csv",
    "\n".join([",".join(dispatch_fields)] + [",".join(str(r[k]) for k in dispatch_fields) for r in dispatches]),
    overwrite=True
)
print(f"  warehouse_dispatch.csv : {len(dispatches)} rows")
```

---

```python
# --------------------------------------------------
# Step 3: Generate shipment_tracking_map.csv
# --------------------------------------------------
print("\n=== Step 3: Generate shipment_tracking_map.csv ===")

tracking_maps = []
for i, m in enumerate(manifests):
    tracking_maps.append({
        "map_id":             f"MAP-{400000 + i}",
        "shipment_id":        m["shipment_id"],
        "raw_tracking_number": m["tracking_number"],
        "carrier_code":       m["carrier"][:2],
    })

map_fields = list(tracking_maps[0].keys())
dbutils.fs.put(f"{LANDING}/shipment_tracking_map.csv",
    "\n".join([",".join(map_fields)] + [",".join(str(r[k]) for k in map_fields) for r in tracking_maps]),
    overwrite=True
)
print(f"  shipment_tracking_map.csv : {len(tracking_maps)} rows")
```

---

```python
# --------------------------------------------------
# Step 4: Generate carrier_tracking_events.csv
# --------------------------------------------------
print("\n=== Step 4: Generate carrier_tracking_events.csv ===")

events = []
event_counter = 0

for m in manifests:
    ship_id    = m["shipment_id"]
    carrier    = m["carrier"]
    tracking   = m["tracking_number"]
    ship_date  = datetime.strptime(m["shipment_date"], "%Y-%m-%d").replace(tzinfo=timezone.utc)

    is_schema_drift = ship_id in DEMO_SHIPMENTS and DEMO_SHIPMENTS[ship_id] == "schema_drift"

    event_ts = ship_date
    for status in STATUS_LIFECYCLE:
        event_ts = event_ts + timedelta(hours=random.randint(4, 24))
        event_id = f"EVT-{500000 + event_counter}"

        events.append({
            "event_id":        event_id,
            "shipment_id":     ship_id,
            "tracking_number": tracking,
            "carrier":         carrier,
            "event_status":    status,
            "event_timestamp": format_ts(event_ts),
            "event_location":  random.choice(CITIES),
        })
        event_counter += 1

        # Duplicate events (~5%)
        if (ship_id in DEMO_SHIPMENTS and DEMO_SHIPMENTS[ship_id] == "duplicate") or \
           (ship_id not in DEMO_SHIPMENTS and random.random() < DUPLICATE_RATE):
            dup_id = f"EVT-DUP-{500000 + event_counter}"
            events.append({
                "event_id":        dup_id,
                "shipment_id":     ship_id,
                "tracking_number": tracking,
                "carrier":         carrier,
                "event_status":    status,
                "event_timestamp": format_ts(event_ts),  # exact same timestamp = duplicate
                "event_location":  random.choice(CITIES),
            })
            event_counter += 1

        # Late arrival events (~4%) — add an extra event with a delay
        if (ship_id in DEMO_SHIPMENTS and DEMO_SHIPMENTS[ship_id] == "late_arrival") or \
           (ship_id not in DEMO_SHIPMENTS and random.random() < LATE_ARRIVAL_RATE):
            late_ts = event_ts + timedelta(hours=random.randint(2, 48))
            late_id = f"EVT-LATE-{500000 + event_counter}"
            events.append({
                "event_id":        late_id,
                "shipment_id":     ship_id,
                "tracking_number": tracking,
                "carrier":         carrier,
                "event_status":    "in_transit",
                "event_timestamp": format_ts(late_ts),
                "event_location":  random.choice(CITIES),
            })
            event_counter += 1

event_fields = list(events[0].keys())
dbutils.fs.put(f"{LANDING}/carrier_tracking_events.csv",
    "\n".join([",".join(event_fields)] + [",".join(str(r[k]) for k in event_fields) for r in events]),
    overwrite=True
)
print(f"  carrier_tracking_events.csv : {len(events)} rows")
```

---

```python
# --------------------------------------------------
# Step 5: Generate carrier_tracking_raw JSON files
# --------------------------------------------------
print("\n=== Step 5: Generate carrier_tracking_raw JSON files ===")

dbutils.fs.mkdirs(f"{LANDING}/carrier_tracking_raw")
json_count = 0

for m in manifests:
    ship_id = m["shipment_id"]
    carrier = m["carrier"]
    is_drift = (ship_id in DEMO_SHIPMENTS and DEMO_SHIPMENTS[ship_id] == "schema_drift") or \
               (ship_id not in DEMO_SHIPMENTS and random.random() < SCHEMA_DRIFT_RATE)

    if is_drift:
        payload = {
            "shipment_ref":  ship_id,        # drifted: was shipment_id
            "carrier_code":  carrier,        # drifted: was carrier
            "version":       "v4.0",         # drifted: was v3.1
            "extra_field":   "unexpected",
            "events":        [{"ts": format_ts(datetime.now(timezone.utc)), "status": "IN_TRANSIT"}]
        }
    else:
        payload = {
            "shipment_id":    ship_id,
            "carrier":        carrier,
            "payload_version": "v3.1",
            "tracking_number": m["tracking_number"],
            "events": [
                {"event_status": s, "event_timestamp": format_ts(
                    datetime.strptime(m["shipment_date"], "%Y-%m-%d").replace(tzinfo=timezone.utc)
                    + timedelta(hours=i * 12)
                ), "location": random.choice(CITIES)}
                for i, s in enumerate(STATUS_LIFECYCLE)
            ]
        }

    json_path = f"{LANDING}/carrier_tracking_raw/{ship_id}.json"
    dbutils.fs.put(json_path, json.dumps(payload), overwrite=True)
    json_count += 1

print(f"  carrier_tracking_raw/ : {json_count} JSON files")
```

---

```python
# --------------------------------------------------
# Step 6: Generate POD document text files
# --------------------------------------------------
print("\n=== Step 6: Generate POD documents ===")

dbutils.fs.mkdirs(f"{LANDING}/pod_documents")
pod_count   = 0
missing_pod = 0

for m in manifests:
    ship_id = m["shipment_id"]

    # Missing POD (~4%)
    is_missing = (ship_id in DEMO_SHIPMENTS and DEMO_SHIPMENTS[ship_id] == "missing_pod") or \
                 (ship_id not in DEMO_SHIPMENTS and random.random() < MISSING_POD_RATE)
    if is_missing:
        missing_pod += 1
        continue

    # Determine delivery outcome
    if ship_id in DEMO_SHIPMENTS:
        scenario = DEMO_SHIPMENTS[ship_id]
        if scenario == "damaged":
            delivery_result = "DAMAGED"
            note = "Package arrived with visible damage to outer carton. Contents may be compromised."
        elif scenario == "low_confidence":
            delivery_result = "???"
            note = "Dlvr attmpt. Rcpt sgn. Pkge left at dr. Cnfrm req."  # ambiguous low-quality text
        elif scenario in ("normal", "human_review"):
            delivery_result = "DELIVERED"
            note = f"Package delivered successfully. Signed by: {m['destination_city']} resident."
        else:
            delivery_result = "DELIVERED"
            note = f"Delivered to {m['destination_city']}."
    else:
        if random.random() < DAMAGED_RATE:
            delivery_result = "DAMAGED"
            note = "Damage noted on delivery. Recipient refused. Exception logged."
        elif random.random() < PARTIAL_RATE:
            delivery_result = "PARTIAL"
            note = "Partial delivery. 2 of 3 items delivered. 1 item missing from shipment."
        elif random.random() < LOW_CONF_RATE:
            delivery_result = "???"
            note = "Delvry at addr. No sgn obtn. Pkg at dr."
        else:
            delivery_result = "DELIVERED"
            note = f"Delivered to {m['destination_city']}, {m['destination_state']}. Recipient present."

    doc_text = f"""PROOF OF DELIVERY DOCUMENT
==========================
Shipment ID    : {ship_id}
Tracking No    : {m['tracking_number']}
Carrier        : {m['carrier']}
Destination    : {m['destination_city']}, {m['destination_state']} {m['destination_zip']}
Delivery Result: {delivery_result}
Delivery Note  : {note}
Timestamp      : {format_ts(datetime.now(timezone.utc))}
Document ID    : POD-{ship_id}
"""

    pod_path = f"{LANDING}/pod_documents/{ship_id}.txt"
    dbutils.fs.put(pod_path, doc_text, overwrite=True)
    pod_count += 1

print(f"  pod_documents/ : {pod_count} files written")
print(f"  Missing POD    : {missing_pod} shipments have no document")
```

---

```python
# --------------------------------------------------
# Step 7: Verify all landing files
# --------------------------------------------------
print("\n=== Step 7: Verification ===")

files_to_check = [
    ("shipment_manifest.csv",      TOTAL_SHIPMENTS),
    ("warehouse_dispatch.csv",     TOTAL_SHIPMENTS),
    ("shipment_tracking_map.csv",  TOTAL_SHIPMENTS),
    ("carrier_tracking_events.csv", len(events)),
]

for fname, expected in files_to_check:
    try:
        info = dbutils.fs.ls(f"{LANDING}/{fname}")
        print(f"  {fname} : OK ({info[0].size} bytes, expected ~{expected} rows)")
    except Exception as e:
        print(f"  {fname} : ERROR — {e}")

try:
    json_files = dbutils.fs.ls(f"{LANDING}/carrier_tracking_raw/")
    print(f"  carrier_tracking_raw/ : {len(json_files)} JSON files")
except Exception as e:
    print(f"  carrier_tracking_raw/ : ERROR — {e}")

try:
    pod_files = dbutils.fs.ls(f"{LANDING}/pod_documents/")
    print(f"  pod_documents/ : {len(pod_files)} files (expected ~{TOTAL_SHIPMENTS - missing_pod})")
except Exception as e:
    print(f"  pod_documents/ : ERROR — {e}")

print("\n  Demo shipment IDs:")
for sid, scenario in DEMO_SHIPMENTS.items():
    print(f"    {sid} → {scenario}")

COMPLETED_AT = datetime.now(timezone.utc)
print(f"\n=== Data generation complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print(f"  Total shipments        : {TOTAL_SHIPMENTS}")
print(f"  Total carrier events   : {len(events)}")
print(f"  POD documents written  : {pod_count}")
print(f"  Missing POD            : {missing_pod}")
```
