# 02 — Bronze Ingestion
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/BRONZE_RULES.md` and `architecture/DATA_MODEL.md`.

Ingests all landing source files into 6 Bronze Delta tables. Values are kept exactly as received. All rows carry `source_file`, `source_record_id`, `batch_id`, `ingested_ts_utc`.

---

```python
# ============================================================
# 02_Bronze_Ingestion — Landing → 6 Bronze Delta Tables
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
from datetime import datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, LongType

CATALOG     = "dbx_cohort1_wave1"
SCHEMA      = "sch_pod13"
VOLUME      = "vol_pod13"
VOLUME_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"
LANDING     = f"{VOLUME_PATH}/landing"

EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Execution ID : {EXECUTION_ID}")
print(f"Started at   : {STARTED_AT.isoformat()}")
print(f"Landing      : {LANDING}")

def add_metadata(df, source_file_path):
    return (df
        .withColumn("source_file",      F.lit(source_file_path))
        .withColumn("source_record_id", F.monotonically_increasing_id().cast("string"))
        .withColumn("batch_id",         F.lit(EXECUTION_ID))
        .withColumn("ingested_ts_utc",  F.lit(STARTED_AT.isoformat()).cast("timestamp"))
    )
```

---

```python
# --------------------------------------------------
# Step 1: bronze_shipment_manifest
# --------------------------------------------------
print("\n=== Step 1: bronze_shipment_manifest ===")

src = f"{LANDING}/shipment_manifest.csv"

df_manifest = (spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .option("rescuedDataColumn", "_rescued_data")
    .csv(src)
)
df_manifest = add_metadata(df_manifest, src)

(df_manifest.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.bronze_shipment_manifest"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.bronze_shipment_manifest IS 'Bronze — raw shipment manifest records from shipment_manifest.csv'")
count = spark.table(f"{CATALOG}.{SCHEMA}.bronze_shipment_manifest").count()
print(f"  bronze_shipment_manifest : {count} rows")
```

---

```python
# --------------------------------------------------
# Step 2: bronze_dispatch
# --------------------------------------------------
print("\n=== Step 2: bronze_dispatch ===")

src = f"{LANDING}/warehouse_dispatch.csv"

df_dispatch = (spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .option("rescuedDataColumn", "_rescued_data")
    .csv(src)
)
df_dispatch = add_metadata(df_dispatch, src)

(df_dispatch.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.bronze_dispatch"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.bronze_dispatch IS 'Bronze — raw warehouse dispatch records from warehouse_dispatch.csv'")
count = spark.table(f"{CATALOG}.{SCHEMA}.bronze_dispatch").count()
print(f"  bronze_dispatch : {count} rows")
```

---

```python
# --------------------------------------------------
# Step 3: bronze_tracking_map
# --------------------------------------------------
print("\n=== Step 3: bronze_tracking_map ===")

src = f"{LANDING}/shipment_tracking_map.csv"

df_map = (spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .option("rescuedDataColumn", "_rescued_data")
    .csv(src)
)
df_map = add_metadata(df_map, src)

(df_map.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.bronze_tracking_map"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.bronze_tracking_map IS 'Bronze — raw tracking number mapping from shipment_tracking_map.csv'")
count = spark.table(f"{CATALOG}.{SCHEMA}.bronze_tracking_map").count()
print(f"  bronze_tracking_map : {count} rows")
```

---

```python
# --------------------------------------------------
# Step 4: bronze_carrier_events
# --------------------------------------------------
print("\n=== Step 4: bronze_carrier_events ===")

src = f"{LANDING}/carrier_tracking_events.csv"

df_events = (spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .option("rescuedDataColumn", "_rescued_data")
    .csv(src)
)
df_events = add_metadata(df_events, src)

(df_events.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.bronze_carrier_events"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.bronze_carrier_events IS 'Bronze — raw carrier tracking events from carrier_tracking_events.csv'")
count = spark.table(f"{CATALOG}.{SCHEMA}.bronze_carrier_events").count()
print(f"  bronze_carrier_events : {count} rows")
```

---

```python
# --------------------------------------------------
# Step 5: bronze_carrier_tracking_raw (JSON)
# --------------------------------------------------
print("\n=== Step 5: bronze_carrier_tracking_raw ===")

json_dir = f"{LANDING}/carrier_tracking_raw"

df_raw = (spark.read
    .option("multiLine", "true")
    .option("rescuedDataColumn", "_rescued_data")
    .json(json_dir)
)

# Add raw_payload as string representation and metadata
df_raw = (df_raw
    .withColumn("raw_payload", F.to_json(F.struct([F.col(c) for c in df_raw.columns])))
    .withColumn("source_file",      F.input_file_name())
    .withColumn("source_record_id", F.monotonically_increasing_id().cast("string"))
    .withColumn("batch_id",         F.lit(EXECUTION_ID))
    .withColumn("ingested_ts_utc",  F.lit(STARTED_AT.isoformat()).cast("timestamp"))
)

(df_raw.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.bronze_carrier_tracking_raw"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.bronze_carrier_tracking_raw IS 'Bronze — raw carrier JSON API payloads from carrier_tracking_raw/'")
count = spark.table(f"{CATALOG}.{SCHEMA}.bronze_carrier_tracking_raw").count()
print(f"  bronze_carrier_tracking_raw : {count} rows")
```

---

```python
# --------------------------------------------------
# Step 6: bronze_delivery_documents
# --------------------------------------------------
print("\n=== Step 6: bronze_delivery_documents ===")
import hashlib

pod_dir = f"{LANDING}/pod_documents"
pod_files = dbutils.fs.ls(pod_dir)

records = []
for f_info in pod_files:
    path = f_info.path
    fname = f_info.name
    shipment_id = fname.replace(".txt", "")
    content = dbutils.fs.head(path, 10000)
    content_hash = hashlib.sha256(content.encode()).hexdigest()
    records.append((
        f"DOC-{shipment_id}",
        shipment_id,
        path,
        content,
        content_hash,
        path,                        # source_file
        shipment_id,                 # source_record_id
        EXECUTION_ID,
        STARTED_AT.isoformat(),
        None                         # _rescued_data
    ))

schema_docs = StructType([
    StructField("document_id",       StringType()),
    StructField("shipment_id",       StringType()),
    StructField("document_path",     StringType()),
    StructField("content_text",      StringType()),
    StructField("content_hash",      StringType()),
    StructField("source_file",       StringType()),
    StructField("source_record_id",  StringType()),
    StructField("batch_id",          StringType()),
    StructField("ingested_ts_utc",   StringType()),
    StructField("_rescued_data",     StringType()),
])

df_docs = (spark.createDataFrame(records, schema_docs)
    .withColumn("ingested_ts_utc", F.col("ingested_ts_utc").cast("timestamp"))
)

(df_docs.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.bronze_delivery_documents"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.bronze_delivery_documents IS 'Bronze — raw proof-of-delivery document text from pod_documents/'")
count = spark.table(f"{CATALOG}.{SCHEMA}.bronze_delivery_documents").count()
print(f"  bronze_delivery_documents : {count} rows")
```

---

```python
# --------------------------------------------------
# Step 7: Audit logging
# --------------------------------------------------
print("\n=== Step 7: Audit Logging ===")

tables = [
    "bronze_shipment_manifest",
    "bronze_dispatch",
    "bronze_tracking_map",
    "bronze_carrier_events",
    "bronze_carrier_tracking_raw",
    "bronze_delivery_documents",
]
total_bronze = sum(spark.table(f"{CATALOG}.{SCHEMA}.{t}").count() for t in tables)
COMPLETED_AT = datetime.now(timezone.utc)

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '02_Bronze_Ingestion', 'bronze',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', {total_bronze}, NULL, current_timestamp())
""")

for t in tables:
    cnt = spark.table(f"{CATALOG}.{SCHEMA}.{t}").count()
    recon_id = str(uuid.uuid4())
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_reconciliation VALUES
    ('{recon_id}', '{EXECUTION_ID}', 'landing/{t.replace("bronze_", "")}', '{t}',
     {cnt}, {cnt}, {cnt}, 0, 'MATCHED', current_timestamp())
    """)

print(f"  audit_pipeline_execution : logged (status=SUCCESS, records={total_bronze})")
print(f"  audit_reconciliation     : {len(tables)} rows logged")

print(f"\n=== Bronze ingestion complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print(f"  Tables   : {len(tables)}")
print(f"  Total rows : {total_bronze}")
```
