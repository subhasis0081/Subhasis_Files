# 03 — Silver: Shipments
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/SILVER_RULES.md` and `architecture/DATA_MODEL.md`.

Validates and normalises shipment manifest, dispatch, and tracking map. Produces `silver_shipment`, `silver_dispatch`, `silver_tracking_map`.

---

```python
# ============================================================
# 03_Silver_Shipments — Bronze → Silver (Shipments)
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
from datetime import datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.window import Window

CATALOG      = "dbx_cohort1_wave1"
SCHEMA       = "sch_pod13"
EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Execution ID : {EXECUTION_ID}")
print(f"Started at   : {STARTED_AT.isoformat()}")

def log_qc(check_layer, check_name, table_name, check_expr, df=None):
    if df is None:
        df = spark.table(f"{CATALOG}.{SCHEMA}.{table_name}")
    total   = df.count()
    passed  = df.filter(check_expr).count()
    failed  = total - passed
    rate    = round((passed / total * 100), 2) if total > 0 else 0.0
    status  = "PASS" if rate >= 99 else ("WARN" if rate >= 95 else "FAIL")
    qc_id   = str(uuid.uuid4())
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_data_quality VALUES
    ('{qc_id}', '{EXECUTION_ID}', '{check_layer}', '{check_name}',
     '{table_name}', "{check_expr}", {total}, {passed}, {failed},
     {rate}, '{status}', current_timestamp())
    """)
    print(f"  [{status}] {check_name}: {passed}/{total} ({rate}%)")
    return status
```

---

```python
# --------------------------------------------------
# Step 1: silver_shipment
# --------------------------------------------------
print("\n=== Step 1: silver_shipment ===")

df_manifest = spark.table(f"{CATALOG}.{SCHEMA}.bronze_shipment_manifest")

df_silver_shipment = (df_manifest
    # Preserve originals
    .withColumnRenamed("carrier",         "carrier_raw")
    .withColumnRenamed("tracking_number", "tracking_number_raw")
    # Normalise
    .withColumn("carrier_normalized",
        F.upper(F.trim(F.col("carrier_raw"))))
    .withColumn("tracking_number_normalized",
        F.upper(F.regexp_replace(F.trim(F.col("tracking_number_raw")), r"\s+", "")))
    # Parse dates
    .withColumn("promised_delivery_date",
        F.to_date(F.col("promised_delivery_date"), "yyyy-MM-dd"))
    .withColumn("shipment_date",
        F.to_date(F.col("shipment_date"), "yyyy-MM-dd"))
    # Validation flags
    .withColumn("is_valid",
        F.col("shipment_id").isNotNull() &
        F.col("carrier_normalized").isNotNull() &
        F.col("tracking_number_normalized").isNotNull() &
        F.col("promised_delivery_date").isNotNull()
    )
    .withColumn("validation_flags",
        F.when(F.col("shipment_id").isNull(), F.lit('["MISSING_SHIPMENT_ID"]'))
        .when(F.col("carrier_raw").isNull(), F.lit('["MISSING_CARRIER"]'))
        .otherwise(F.lit("[]"))
    )
    .withColumn("silver_processed_at", F.lit(STARTED_AT.isoformat()).cast("timestamp"))
    # Drop Bronze metadata columns
    .drop("source_file", "source_record_id", "batch_id", "ingested_ts_utc", "_rescued_data")
)

(df_silver_shipment.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.silver_shipment"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.silver_shipment IS 'Silver — validated and normalised shipment manifest records'")

count = spark.table(f"{CATALOG}.{SCHEMA}.silver_shipment").count()
print(f"  silver_shipment : {count} rows")
log_qc("silver", "silver_shipment_not_null_id",       "silver_shipment", "shipment_id IS NOT NULL")
log_qc("silver", "silver_shipment_carrier_normalized", "silver_shipment", "carrier_normalized IS NOT NULL")
log_qc("silver", "silver_shipment_valid_flag",         "silver_shipment", "is_valid = true")
```

---

```python
# --------------------------------------------------
# Step 2: silver_dispatch
# --------------------------------------------------
print("\n=== Step 2: silver_dispatch ===")

df_dispatch = spark.table(f"{CATALOG}.{SCHEMA}.bronze_dispatch")
df_shipment_ids = spark.table(f"{CATALOG}.{SCHEMA}.silver_shipment").select("shipment_id")

df_silver_dispatch = (df_dispatch
    .withColumn("dispatch_timestamp_utc",
        F.to_timestamp(F.col("dispatch_timestamp"), "yyyy-MM-dd'T'HH:mm:ss'Z'"))
    .withColumn("shipment_exists",
        F.col("shipment_id").isin([r.shipment_id for r in df_shipment_ids.collect()]))
    .withColumn("is_valid",
        F.col("dispatch_id").isNotNull() & F.col("shipment_id").isNotNull() & F.col("shipment_exists"))
    .drop("source_file", "source_record_id", "batch_id", "ingested_ts_utc", "_rescued_data", "dispatch_timestamp")
)

(df_silver_dispatch.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.silver_dispatch"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.silver_dispatch IS 'Silver — validated dispatch records linked to silver_shipment'")

count = spark.table(f"{CATALOG}.{SCHEMA}.silver_dispatch").count()
print(f"  silver_dispatch : {count} rows")
log_qc("silver", "silver_dispatch_shipment_exists", "silver_dispatch", "shipment_exists = true")
```

---

```python
# --------------------------------------------------
# Step 3: silver_tracking_map
# --------------------------------------------------
print("\n=== Step 3: silver_tracking_map ===")

df_map   = spark.table(f"{CATALOG}.{SCHEMA}.bronze_tracking_map")
df_mfst  = spark.table(f"{CATALOG}.{SCHEMA}.silver_shipment").select(
    "shipment_id", "tracking_number_normalized"
)

df_silver_map = (df_map
    .withColumnRenamed("raw_tracking_number", "raw_tracking_number")
    .withColumn("canonical_tracking_number",
        F.upper(F.regexp_replace(F.trim(F.col("raw_tracking_number")), r"\s+", "")))
    .join(df_mfst, "shipment_id", "left")
    .withColumn("match_method",
        F.when(F.col("canonical_tracking_number") == F.col("tracking_number_normalized"), "EXACT")
        .otherwise("FUZZY"))
    .withColumn("match_confidence",
        F.when(F.col("match_method") == "EXACT", F.lit(1.0))
        .otherwise(F.lit(0.75)))
    .withColumn("reconciled_with_manifest",
        F.col("tracking_number_normalized").isNotNull())
    .drop("source_file", "source_record_id", "batch_id", "ingested_ts_utc", "_rescued_data",
          "tracking_number_normalized")
)

(df_silver_map.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.silver_tracking_map"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.silver_tracking_map IS 'Silver — canonical tracking number mapping reconciled with manifest'")

count = spark.table(f"{CATALOG}.{SCHEMA}.silver_tracking_map").count()
print(f"  silver_tracking_map : {count} rows")
log_qc("silver", "silver_tracking_map_reconciled", "silver_tracking_map", "reconciled_with_manifest = true")
```

---

```python
# --------------------------------------------------
# Step 4: Audit logging
# --------------------------------------------------
print("\n=== Step 4: Audit Logging ===")

total_silver = (
    spark.table(f"{CATALOG}.{SCHEMA}.silver_shipment").count() +
    spark.table(f"{CATALOG}.{SCHEMA}.silver_dispatch").count() +
    spark.table(f"{CATALOG}.{SCHEMA}.silver_tracking_map").count()
)
COMPLETED_AT = datetime.now(timezone.utc)

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '03_Silver_Shipments', 'silver',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', {total_silver}, NULL, current_timestamp())
""")

print(f"  audit_pipeline_execution : logged (status=SUCCESS, records={total_silver})")
print(f"\n=== Silver Shipments complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
```
