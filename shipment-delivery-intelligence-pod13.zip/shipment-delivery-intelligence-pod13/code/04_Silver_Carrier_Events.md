# 04 — Silver: Carrier Events
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/SILVER_RULES.md` and `architecture/DATA_MODEL.md`.

Applies event_hash deduplication, status normalisation, late arrival detection, schema drift detection, and quarantine routing. Produces `silver_carrier_events`, `quarantine_carrier_events`.

---

```python
# ============================================================
# 04_Silver_Carrier_Events — Bronze → Silver (Carrier Events)
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
import json
from datetime import datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType, BooleanType, LongType, TimestampType

CATALOG            = "dbx_cohort1_wave1"
SCHEMA             = "sch_pod13"
EXECUTION_ID       = str(uuid.uuid4())
STARTED_AT         = datetime.now(timezone.utc)
LATE_THRESHOLD_SEC = 3600
EXPECTED_VERSION   = "v3.1"
MANDATORY_FIELDS   = {"shipment_id", "event_status"}

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Execution ID        : {EXECUTION_ID}")
print(f"Late threshold (sec): {LATE_THRESHOLD_SEC}")
print(f"Expected version    : {EXPECTED_VERSION}")

def log_qc(check_layer, check_name, table_name, check_expr, df=None):
    if df is None:
        df = spark.table(f"{CATALOG}.{SCHEMA}.{table_name}")
    total   = df.count()
    passed  = df.filter(check_expr).count()
    failed  = total - passed
    rate    = round((passed / total * 100), 2) if total > 0 else 0.0
    status  = "PASS" if rate >= 99 else ("WARN" if rate >= 95 else "FAIL")
    qc_id   = str(uuid.uuid4())
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_data_quality VALUES
    ('{qc_id}', '{EXECUTION_ID}', '{check_layer}', '{check_name}',
     '{table_name}', "{check_expr}", {total}, {passed}, {failed},
     {rate}, '{status}', current_timestamp())
    """)
    print(f"  [{status}] {check_name}: {passed}/{total} ({rate}%)")
    return status
```

---

```python
# --------------------------------------------------
# Step 1: Load bronze carrier events
# --------------------------------------------------
print("\n=== Step 1: Load bronze_carrier_events ===")

df_events = spark.table(f"{CATALOG}.{SCHEMA}.bronze_carrier_events")
raw_count = df_events.count()
print(f"  Loaded: {raw_count} rows from bronze_carrier_events")
```

---

```python
# --------------------------------------------------
# Step 2: Normalise status values
# --------------------------------------------------
print("\n=== Step 2: Normalise Event Status ===")

CANONICAL_STATUS_MAP = {
    "label_created":    "label_created",
    "picked_up":        "picked_up",
    "in_transit":       "in_transit",
    "out_for_delivery": "out_for_delivery",
    "delivered":        "delivered",
    "exception":        "exception",
    "returned":         "returned",
}

status_mapping_expr = F.coalesce(
    *[F.when(F.lower(F.trim(F.col("event_status"))) == k, F.lit(v))
      for k, v in CANONICAL_STATUS_MAP.items()],
    F.lit("unknown")
)

df_events = (df_events
    .withColumn("event_status_raw", F.col("event_status"))
    .withColumn("canonical_status", status_mapping_expr)
    .withColumn("event_timestamp_utc",
        F.to_timestamp(F.col("event_timestamp"), "yyyy-MM-dd'T'HH:mm:ss'Z'"))
)
print("  Status normalisation applied.")
```

---

```python
# --------------------------------------------------
# Step 3: Compute event_hash
# --------------------------------------------------
print("\n=== Step 3: Compute event_hash ===")

df_events = df_events.withColumn("event_hash",
    F.sha2(
        F.concat_ws("||",
            F.col("shipment_id"),
            F.col("tracking_number"),
            F.col("event_status"),
            F.col("event_timestamp")
        ), 256
    )
)
print("  event_hash (SHA-256) computed.")
```

---

```python
# --------------------------------------------------
# Step 4: Deduplicate via window ranking
# --------------------------------------------------
print("\n=== Step 4: Deduplication ===")

w_dedup = Window.partitionBy("event_hash").orderBy("event_id")
df_events = (df_events
    .withColumn("dedup_rank", F.row_number().over(w_dedup))
    .withColumn("is_duplicate", F.col("dedup_rank") > 1)
)

dup_count = df_events.filter(F.col("is_duplicate") == True).count()
print(f"  Duplicate events flagged: {dup_count}")
```

---

```python
# --------------------------------------------------
# Step 5: Event sequencing per shipment
# --------------------------------------------------
print("\n=== Step 5: Event Sequencing ===")

w_seq = Window.partitionBy("shipment_id").orderBy("event_timestamp_utc", "event_id")
df_events = df_events.withColumn("event_sequence", F.row_number().over(w_seq))
print("  event_sequence computed per shipment.")
```

---

```python
# --------------------------------------------------
# Step 6: Late arrival detection
# --------------------------------------------------
print("\n=== Step 6: Late Arrival Detection ===")

df_events = (df_events
    .withColumn("arrival_lag_sec",
        F.unix_timestamp(F.current_timestamp()) - F.unix_timestamp(F.col("event_timestamp_utc")))
    .withColumn("is_late_arrival",
        F.col("arrival_lag_sec") > LATE_THRESHOLD_SEC)
)

late_count = df_events.filter(F.col("is_late_arrival") == True).count()
print(f"  Late arrivals detected: {late_count}")
```

---

```python
# --------------------------------------------------
# Step 7: Schema drift detection from JSON payloads
# --------------------------------------------------
print("\n=== Step 7: Schema Drift Detection ===")

df_raw = spark.table(f"{CATALOG}.{SCHEMA}.bronze_carrier_tracking_raw")

# Detect rows where payload_version != v3.1 or mandatory fields missing
drift_records = []
raw_rows = df_raw.select("shipment_id", "carrier", "payload_version", "raw_payload", "source_file").collect()

for row in raw_rows:
    try:
        payload = json.loads(row["raw_payload"]) if row["raw_payload"] else {}
    except Exception:
        payload = {}

    actual_version = payload.get("version", payload.get("payload_version", "unknown"))
    present_keys   = set(payload.keys())
    mandatory_keys = {"shipment_id", "carrier", "events"}
    missing        = mandatory_keys - present_keys
    drifted        = present_keys - {"shipment_id", "carrier", "payload_version", "tracking_number", "events"}

    is_drift = (actual_version != EXPECTED_VERSION and actual_version != "unknown") or len(missing) > 0

    if is_drift:
        drift_records.append({
            "drift_id":        str(uuid.uuid4()),
            "execution_id":    EXECUTION_ID,
            "shipment_id":     row["shipment_id"] or payload.get("shipment_ref", "UNKNOWN"),
            "carrier":         row["carrier"] or payload.get("carrier_code", "UNKNOWN"),
            "expected_version": EXPECTED_VERSION,
            "actual_version":  actual_version,
            "drifted_fields":  json.dumps(list(drifted)),
            "missing_fields":  json.dumps(list(missing)),
            "action_taken":    "QUARANTINE" if missing else "RESCUE",
            "detected_at":     STARTED_AT.isoformat(),
        })

print(f"  Schema drift records: {len(drift_records)}")

if drift_records:
    for dr in drift_records:
        spark.sql(f"""
        INSERT INTO {CATALOG}.{SCHEMA}.audit_schema_drift VALUES
        ('{dr["drift_id"]}', '{dr["execution_id"]}', '{dr["shipment_id"]}',
         '{dr["carrier"]}', '{dr["expected_version"]}', '{dr["actual_version"]}',
         '{dr["drifted_fields"]}', '{dr["missing_fields"]}',
         '{dr["action_taken"]}', current_timestamp())
        """)

drift_shipment_ids = {dr["shipment_id"] for dr in drift_records if dr["action_taken"] == "QUARANTINE"}
print(f"  Shipment IDs quarantined due to schema drift: {len(drift_shipment_ids)}")
```

---

```python
# --------------------------------------------------
# Step 8: Write quarantine_carrier_events
# --------------------------------------------------
print("\n=== Step 8: Write quarantine_carrier_events ===")

df_quarantine = df_events.filter(F.col("shipment_id").isin(list(drift_shipment_ids))) \
    .withColumn("quarantine_reason", F.lit("SCHEMA_DRIFT_MISSING_MANDATORY_FIELDS")) \
    .withColumn("quarantined_at",    F.lit(STARTED_AT.isoformat()).cast("timestamp"))

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.quarantine_carrier_events
USING DELTA AS
SELECT *, 'SCHEMA_DRIFT' as quarantine_reason, current_timestamp() as quarantined_at
FROM {CATALOG}.{SCHEMA}.bronze_carrier_events
WHERE 1=0
""")

if drift_shipment_ids:
    (df_quarantine.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(f"{CATALOG}.{SCHEMA}.quarantine_carrier_events"))

qcount = spark.table(f"{CATALOG}.{SCHEMA}.quarantine_carrier_events").count()
print(f"  quarantine_carrier_events : {qcount} rows")
```

---

```python
# --------------------------------------------------
# Step 9: Write silver_carrier_events (non-quarantined only)
# --------------------------------------------------
print("\n=== Step 9: Write silver_carrier_events ===")

df_silver_events = (df_events
    .filter(~F.col("shipment_id").isin(list(drift_shipment_ids)))
    .select(
        "event_id", "event_hash", "shipment_id", "tracking_number", "carrier",
        "event_status_raw", "canonical_status", "event_timestamp_utc",
        "event_sequence", "is_duplicate", "is_late_arrival", "arrival_lag_sec"
    )
)

(df_silver_events.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.silver_carrier_events"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.silver_carrier_events IS 'Silver — deduplicated, normalised, sequenced carrier tracking events'")

scount = spark.table(f"{CATALOG}.{SCHEMA}.silver_carrier_events").count()
print(f"  silver_carrier_events : {scount} rows")

log_qc("silver", "no_duplicate_event_hash",
       "silver_carrier_events", "is_duplicate = false")
log_qc("silver", "late_arrival_positive_cases",
       "silver_carrier_events", "is_late_arrival = true OR 1=1")  # just checks count > 0
```

---

```python
# --------------------------------------------------
# Step 10: Audit logging
# --------------------------------------------------
print("\n=== Step 10: Audit Logging ===")
COMPLETED_AT = datetime.now(timezone.utc)

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '04_Silver_Carrier_Events', 'silver',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', {scount}, NULL, current_timestamp())
""")

print(f"  audit_pipeline_execution : logged (status=SUCCESS, records={scount})")
print(f"  audit_schema_drift : {len(drift_records)} records logged")
print(f"\n=== Silver Carrier Events complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration           : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print(f"  Silver events      : {scount}")
print(f"  Duplicates flagged : {dup_count}")
print(f"  Late arrivals      : {late_count}")
print(f"  Schema drift       : {len(drift_records)}")
print(f"  Quarantined        : {qcount}")
```
