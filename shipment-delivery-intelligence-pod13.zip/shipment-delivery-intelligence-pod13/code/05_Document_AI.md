# 05 — Silver: Document AI
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/SILVER_RULES.md`, `architecture/DATA_MODEL.md`, `architecture/AGENT_GUARDRAILS.md`.

Applies regex-based extraction to POD documents. Scores confidence. Routes low-confidence extractions to human review. Produces `silver_document_extraction`, `quarantine_documents`, updates `audit_document_processing`.

---

```python
# ============================================================
# 05_Document_AI — POD Document Extraction
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
import re
import hashlib
import json
from datetime import datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.types import (StructType, StructField, StringType,
                                DoubleType, BooleanType, TimestampType)

CATALOG            = "dbx_cohort1_wave1"
SCHEMA             = "sch_pod13"
EXECUTION_ID       = str(uuid.uuid4())
STARTED_AT         = datetime.now(timezone.utc)
CONFIDENCE_THRESHOLD = 0.80
MODEL_VERSION      = "regex-v1.0"
PROMPT_VERSION     = "pod-parser-v1.0"

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Execution ID         : {EXECUTION_ID}")
print(f"Confidence threshold : {CONFIDENCE_THRESHOLD}")
print(f"Model version        : {MODEL_VERSION}")
print(f"Prompt version       : {PROMPT_VERSION}")

def log_qc(check_layer, check_name, table_name, check_expr, df=None):
    if df is None:
        df = spark.table(f"{CATALOG}.{SCHEMA}.{table_name}")
    total   = df.count()
    passed  = df.filter(check_expr).count()
    failed  = total - passed
    rate    = round((passed / total * 100), 2) if total > 0 else 0.0
    status  = "PASS" if rate >= 99 else ("WARN" if rate >= 95 else "FAIL")
    qc_id   = str(uuid.uuid4())
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_data_quality VALUES
    ('{qc_id}', '{EXECUTION_ID}', '{check_layer}', '{check_name}',
     '{table_name}', "{check_expr}", {total}, {passed}, {failed},
     {rate}, '{status}', current_timestamp())
    """)
    print(f"  [{status}] {check_name}: {passed}/{total} ({rate}%)")
    return status
```

---

```python
# --------------------------------------------------
# Step 1: Extraction functions
# --------------------------------------------------
print("\n=== Step 1: Define Extraction Functions ===")

def extract_delivery_result(text: str) -> str:
    text_upper = text.upper()
    if re.search(r"DAMAGED|DAMAGE NOTED|VISIBLE DAMAGE|REFUSED|CARTON DAMAGE", text_upper):
        return "DAMAGED"
    if re.search(r"PARTIAL|INCOMPLETE|MISSING ITEM|NOT ALL ITEMS", text_upper):
        return "PARTIAL"
    if re.search(r"\bDELIVER(ED|Y)\b", text_upper):
        return "DELIVERED"
    if re.search(r"\?\?\?|DLVR ATTMPT|UNKNWN|CNFRM REQ|DELVRY AT ADDR", text_upper):
        return "UNKNOWN"
    return "UNKNOWN"

def extract_recipient(text: str) -> str:
    match = re.search(r"(?:SIGNED BY|RECIPIENT|RCPT|RECIPIENT:)\s*[:\-]?\s*(.+?)(?:\n|$)", text, re.IGNORECASE)
    if match:
        return match.group(1).strip()[:100]
    match = re.search(r"DELIVERED TO\s+(.+?)(?:,|\n|$)", text, re.IGNORECASE)
    if match:
        return match.group(1).strip()[:100]
    return None

def extract_exception(text: str) -> str:
    text_upper = text.upper()
    if re.search(r"EXCEPTION|REFUSED|UNABLE TO DELIVER|ACCESS DENIED", text_upper):
        return re.search(r"(EXCEPTION[^\n]*|REFUSED[^\n]*|UNABLE TO DELIVER[^\n]*)", text_upper).group(1)[:200]
    return None

def extract_damage(text: str) -> str:
    match = re.search(r"(DAMAGE[^\n]*|CARTON DAMAGE[^\n]*|VISIBLE DAMAGE[^\n]*)", text, re.IGNORECASE)
    if match:
        return match.group(1).strip()[:200]
    return None

def compute_confidence(delivery_result, recipient, content_text):
    score = 0.0
    # Delivery result clarity
    if delivery_result in ("DELIVERED", "DAMAGED", "PARTIAL"):
        score += 0.50
    elif delivery_result == "UNKNOWN":
        score += 0.10
    # Recipient present
    if recipient:
        score += 0.25
    # Shipment ID present in document
    if re.search(r"SHP-\d+", content_text):
        score += 0.15
    # Tracking number present
    if re.search(r"[A-Z0-9]{15,}", content_text):
        score += 0.10
    return min(round(score, 2), 1.0)

print("  Extraction functions defined.")
```

---

```python
# --------------------------------------------------
# Step 2: Extract from all bronze documents
# --------------------------------------------------
print("\n=== Step 2: Process POD Documents ===")

df_docs = spark.table(f"{CATALOG}.{SCHEMA}.bronze_delivery_documents")
doc_rows = df_docs.select("document_id", "shipment_id", "document_path", "content_text", "content_hash").collect()

extraction_records = []
quarantine_docs    = []

for row in doc_rows:
    content = row["content_text"] or ""
    sid     = row["shipment_id"]

    try:
        delivery_result   = extract_delivery_result(content)
        recipient         = extract_recipient(content)
        exception_reason  = extract_exception(content)
        damage_note       = extract_damage(content)
        confidence        = compute_confidence(delivery_result, recipient, content)
        requires_review   = confidence < CONFIDENCE_THRESHOLD

        extraction_records.append((
            str(uuid.uuid4()),   # extraction_id
            sid,
            row["document_path"],
            row["content_hash"],
            delivery_result,
            recipient,
            exception_reason,
            damage_note,
            confidence,
            requires_review,
            MODEL_VERSION,
            PROMPT_VERSION,
            STARTED_AT,
        ))
    except Exception as e:
        quarantine_docs.append((
            row["document_id"],
            sid,
            row["document_path"],
            row["content_hash"],
            str(e),
            STARTED_AT,
        ))

print(f"  Extracted: {len(extraction_records)} documents")
print(f"  Quarantined: {len(quarantine_docs)} documents (extraction failure)")
low_conf = sum(1 for r in extraction_records if r[8] < CONFIDENCE_THRESHOLD)
print(f"  Low confidence (< {CONFIDENCE_THRESHOLD}): {low_conf} documents")
```

---

```python
# --------------------------------------------------
# Step 3: Write silver_document_extraction
# --------------------------------------------------
print("\n=== Step 3: Write silver_document_extraction ===")

schema_ext = StructType([
    StructField("extraction_id",      StringType()),
    StructField("shipment_id",        StringType()),
    StructField("document_path",      StringType()),
    StructField("content_hash",       StringType()),
    StructField("delivery_result",    StringType()),
    StructField("recipient_indicator",StringType()),
    StructField("exception_reason",   StringType()),
    StructField("damage_note",        StringType()),
    StructField("confidence_score",   DoubleType()),
    StructField("requires_review",    BooleanType()),
    StructField("model_version",      StringType()),
    StructField("prompt_version",     StringType()),
    StructField("extracted_at",       TimestampType()),
])

df_extractions = spark.createDataFrame(extraction_records, schema_ext)

(df_extractions.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.silver_document_extraction"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.silver_document_extraction IS 'Silver — POD document extraction results with confidence scoring and review routing'")

ext_count = spark.table(f"{CATALOG}.{SCHEMA}.silver_document_extraction").count()
print(f"  silver_document_extraction : {ext_count} rows")

log_qc("silver", "confidence_score_range",
       "silver_document_extraction", "confidence_score >= 0.0 AND confidence_score <= 1.0")
log_qc("silver", "low_confidence_requires_review",
       "silver_document_extraction",
       f"NOT (confidence_score < {CONFIDENCE_THRESHOLD} AND requires_review = false)")
```

---

```python
# --------------------------------------------------
# Step 4: Write quarantine_documents
# --------------------------------------------------
print("\n=== Step 4: Write quarantine_documents ===")

schema_quar = StructType([
    StructField("document_id",      StringType()),
    StructField("shipment_id",      StringType()),
    StructField("document_path",    StringType()),
    StructField("content_hash",     StringType()),
    StructField("quarantine_reason",StringType()),
    StructField("quarantined_at",   TimestampType()),
])

df_quar = spark.createDataFrame(quarantine_docs, schema_quar)
(df_quar.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.quarantine_documents"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.quarantine_documents IS 'Quarantine — documents where extraction entirely failed'")
q_count = spark.table(f"{CATALOG}.{SCHEMA}.quarantine_documents").count()
print(f"  quarantine_documents : {q_count} rows")
```

---

```python
# --------------------------------------------------
# Step 5: Populate audit_document_processing
# --------------------------------------------------
print("\n=== Step 5: Audit — audit_document_processing ===")

for rec in extraction_records:
    dp_id    = str(uuid.uuid4())
    ext_json = json.dumps({
        "delivery_result": rec[4],
        "confidence":      rec[8],
        "requires_review": rec[9],
    }).replace("'", "''")
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_document_processing VALUES
    ('{dp_id}', '{EXECUTION_ID}', '{rec[1]}', '{rec[2]}', '{rec[3]}',
     '{ext_json}', {rec[8]}, {str(rec[9]).lower()}, '{MODEL_VERSION}',
     '{PROMPT_VERSION}', current_timestamp())
    """)

dp_count = spark.table(f"{CATALOG}.{SCHEMA}.audit_document_processing").count()
print(f"  audit_document_processing : {dp_count} rows logged")
```

---

```python
# --------------------------------------------------
# Step 6: Audit pipeline execution
# --------------------------------------------------
print("\n=== Step 6: Audit Logging ===")
COMPLETED_AT = datetime.now(timezone.utc)

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '05_Document_AI', 'silver',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', {ext_count}, NULL, current_timestamp())
""")

print(f"\n=== Document AI complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration             : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print(f"  Extractions          : {ext_count}")
print(f"  Low confidence       : {low_conf}")
print(f"  Quarantined docs     : {q_count}")
```
