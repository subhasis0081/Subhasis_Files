# 06 — Human Review Queue
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/SILVER_RULES.md`, `architecture/AGENT_GUARDRAILS.md`.

Builds a unified review queue from low-confidence extractions, fuzzy tracking matches, and damaged/partial deliveries. Simulates human decisions. Produces `silver_human_review_queue`, logs to `audit_human_decisions`.

---

```python
# ============================================================
# 06_Human_Review — Unified Review Queue + Simulated Decisions
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
import random
from datetime import datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.types import (StructType, StructField, StringType,
                                DoubleType, BooleanType, TimestampType)

CATALOG              = "dbx_cohort1_wave1"
SCHEMA               = "sch_pod13"
EXECUTION_ID         = str(uuid.uuid4())
STARTED_AT           = datetime.now(timezone.utc)
CONFIDENCE_THRESHOLD = 0.80

random.seed(42)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Execution ID         : {EXECUTION_ID}")
print(f"Confidence threshold : {CONFIDENCE_THRESHOLD}")
```

---

```python
# --------------------------------------------------
# Step 1: Build review queue items
# --------------------------------------------------
print("\n=== Step 1: Build Review Queue ===")

review_items = []

# --- Source A: Low-confidence document extractions ---
df_low_conf = spark.table(f"{CATALOG}.{SCHEMA}.silver_document_extraction") \
    .filter(F.col("requires_review") == True)

for row in df_low_conf.select("extraction_id", "shipment_id", "confidence_score",
                               "delivery_result", "extracted_at").collect():
    review_items.append({
        "review_id":        str(uuid.uuid4()),
        "shipment_id":      row["shipment_id"],
        "review_type":      "LOW_CONFIDENCE_EXTRACTION",
        "source_table":     "silver_document_extraction",
        "source_id":        row["extraction_id"],
        "priority":         "HIGH" if row["confidence_score"] < 0.5 else "MEDIUM",
        "review_context":   f"confidence={row['confidence_score']}, result={row['delivery_result']}",
        "requires_human":   True,
        "created_at":       STARTED_AT,
    })

print(f"  Low-confidence extractions   : {len(review_items)}")

# --- Source B: Fuzzy tracking matches ---
df_fuzzy = spark.table(f"{CATALOG}.{SCHEMA}.silver_tracking_map") \
    .filter(F.col("match_method") == "FUZZY")

base_len = len(review_items)
for row in df_fuzzy.select("map_id", "shipment_id", "match_confidence",
                             "canonical_tracking_number").collect():
    review_items.append({
        "review_id":      str(uuid.uuid4()),
        "shipment_id":    row["shipment_id"],
        "review_type":    "FUZZY_TRACKING_MATCH",
        "source_table":   "silver_tracking_map",
        "source_id":      row["map_id"],
        "priority":       "MEDIUM",
        "review_context": f"match_confidence={row['match_confidence']}, tracking={row['canonical_tracking_number']}",
        "requires_human": True,
        "created_at":     STARTED_AT,
    })

print(f"  Fuzzy tracking matches       : {len(review_items) - base_len}")

# --- Source C: Damaged/partial deliveries ---
df_damage = spark.table(f"{CATALOG}.{SCHEMA}.silver_document_extraction") \
    .filter(F.col("delivery_result").isin(["DAMAGED", "PARTIAL"]))

base_len = len(review_items)
for row in df_damage.select("extraction_id", "shipment_id", "delivery_result",
                              "damage_note").collect():
    review_items.append({
        "review_id":      str(uuid.uuid4()),
        "shipment_id":    row["shipment_id"],
        "review_type":    "DAMAGE_PARTIAL_DELIVERY",
        "source_table":   "silver_document_extraction",
        "source_id":      row["extraction_id"],
        "priority":       "HIGH",
        "review_context": f"delivery_result={row['delivery_result']}, note={row['damage_note']}",
        "requires_human": True,
        "created_at":     STARTED_AT,
    })

print(f"  Damaged/partial deliveries   : {len(review_items) - base_len}")
print(f"  Total review items           : {len(review_items)}")
```

---

```python
# --------------------------------------------------
# Step 2: Write silver_human_review_queue
# --------------------------------------------------
print("\n=== Step 2: Write silver_human_review_queue ===")

schema_review = StructType([
    StructField("review_id",      StringType()),
    StructField("shipment_id",    StringType()),
    StructField("review_type",    StringType()),
    StructField("source_table",   StringType()),
    StructField("source_id",      StringType()),
    StructField("priority",       StringType()),
    StructField("review_context", StringType()),
    StructField("requires_human", BooleanType()),
    StructField("created_at",     TimestampType()),
])

df_review = spark.createDataFrame(
    [(r["review_id"], r["shipment_id"], r["review_type"], r["source_table"],
      r["source_id"], r["priority"], r["review_context"], r["requires_human"],
      r["created_at"]) for r in review_items],
    schema_review
)

(df_review.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.silver_human_review_queue"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.silver_human_review_queue IS 'Silver — unified human review queue for low-confidence, fuzzy-match, and damage events'")

rq_count = spark.table(f"{CATALOG}.{SCHEMA}.silver_human_review_queue").count()
print(f"  silver_human_review_queue : {rq_count} rows")
```

---

```python
# --------------------------------------------------
# Step 3: Simulate human decisions
# --------------------------------------------------
print("\n=== Step 3: Simulate Human Decisions ===")

DECISION_MATRIX = {
    "LOW_CONFIDENCE_EXTRACTION": ["ACCEPT_LOW_CONF", "REJECT_EXTRACTION", "REQUEST_RESCAN"],
    "FUZZY_TRACKING_MATCH":      ["APPROVE_FUZZY_MAP", "REJECT_FUZZY_MAP"],
    "DAMAGE_PARTIAL_DELIVERY":   ["ACCEPT_DAMAGE_CLAIM", "ESCALATE_TO_CARRIER", "CLOSE_EXCEPTION"],
}

DECISION_WEIGHTS = {
    "LOW_CONFIDENCE_EXTRACTION": [0.60, 0.25, 0.15],
    "FUZZY_TRACKING_MATCH":      [0.70, 0.30],
    "DAMAGE_PARTIAL_DELIVERY":   [0.50, 0.30, 0.20],
}

decision_records = []
for item in review_items:
    rtype   = item["review_type"]
    options = DECISION_MATRIX.get(rtype, ["APPROVED"])
    weights = DECISION_WEIGHTS.get(rtype, [1.0])
    decision = random.choices(options, weights=weights, k=1)[0]
    rationale_map = {
        "ACCEPT_LOW_CONF":      "Reviewer confirmed delivery from contextual evidence",
        "REJECT_EXTRACTION":    "Extraction rejected — insufficient document quality",
        "REQUEST_RESCAN":       "Document sent for re-scan",
        "APPROVE_FUZZY_MAP":    "Reviewer confirmed tracking number match",
        "REJECT_FUZZY_MAP":     "Tracking number mismatch confirmed — rejected",
        "ACCEPT_DAMAGE_CLAIM":  "Damage claim accepted by reviewer",
        "ESCALATE_TO_CARRIER":  "Escalated to carrier for investigation",
        "CLOSE_EXCEPTION":      "Exception closed — no further action required",
    }
    decision_records.append({
        "decision_id":    str(uuid.uuid4()),
        "review_id":      item["review_id"],
        "shipment_id":    item["shipment_id"],
        "decision":       decision,
        "decided_by":     "SIMULATED_REVIEWER",
        "decision_notes": rationale_map.get(decision, "Decision recorded"),
        "decided_at":     STARTED_AT,
    })

approved = sum(1 for d in decision_records if "ACCEPT" in d["decision"] or "APPROVE" in d["decision"])
rejected = sum(1 for d in decision_records if "REJECT" in d["decision"])
escalated = sum(1 for d in decision_records if "ESCALATE" in d["decision"])
print(f"  Approved  : {approved}")
print(f"  Rejected  : {rejected}")
print(f"  Escalated : {escalated}")
print(f"  Total     : {len(decision_records)}")
```

---

```python
# --------------------------------------------------
# Step 4: Log to audit_human_decisions
# --------------------------------------------------
print("\n=== Step 4: Log audit_human_decisions ===")

for dec in decision_records:
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_human_decisions VALUES
    ('{dec["decision_id"]}', '{EXECUTION_ID}', '{dec["review_id"]}',
     '{dec["shipment_id"]}', '{dec["decision"]}', '{dec["decided_by"]}',
     '{dec["decision_notes"]}', current_timestamp())
    """)

hd_count = spark.table(f"{CATALOG}.{SCHEMA}.audit_human_decisions").count()
print(f"  audit_human_decisions : {hd_count} rows logged")
```

---

```python
# --------------------------------------------------
# Step 5: Audit pipeline execution
# --------------------------------------------------
print("\n=== Step 5: Audit Logging ===")
COMPLETED_AT = datetime.now(timezone.utc)

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '06_Human_Review', 'silver',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', {rq_count}, NULL, current_timestamp())
""")

print(f"\n=== Human Review complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration      : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print(f"  Review items  : {rq_count}")
print(f"  Decisions     : {len(decision_records)}")
```
