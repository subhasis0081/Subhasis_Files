# 07 — Gold: Shipment Tracking
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/GOLD_RULES.md`, `architecture/DATA_MODEL.md`.

Produces 4 Gold tables: `gold_shipment_tracking`, `gold_carrier_event_timeline`, `gold_document_intelligence`, `gold_exception_summary`. All use fully qualified names. Logs to `audit_pipeline_execution`.

---

```python
# ============================================================
# 07_Gold_Shipment_Tracking — Silver → Gold (4 tables)
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
from datetime import datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.window import Window

CATALOG      = "dbx_cohort1_wave1"
SCHEMA       = "sch_pod13"
EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Execution ID : {EXECUTION_ID}")
print(f"Started at   : {STARTED_AT.isoformat()}")

def log_qc(check_layer, check_name, table_name, check_expr):
    df     = spark.table(f"{CATALOG}.{SCHEMA}.{table_name}")
    total  = df.count()
    passed = df.filter(check_expr).count()
    failed = total - passed
    rate   = round((passed / total * 100), 2) if total > 0 else 0.0
    status = "PASS" if rate >= 99 else ("WARN" if rate >= 95 else "FAIL")
    qc_id  = str(uuid.uuid4())
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_data_quality VALUES
    ('{qc_id}', '{EXECUTION_ID}', '{check_layer}', '{check_name}',
     '{table_name}', "{check_expr}", {total}, {passed}, {failed},
     {rate}, '{status}', current_timestamp())
    """)
    print(f"  [{status}] {check_name}: {passed}/{total} ({rate}%)")
    return status
```

---

```python
# --------------------------------------------------
# Step 1: gold_shipment_tracking
# --------------------------------------------------
print("\n=== Step 1: gold_shipment_tracking ===")

df_ship     = spark.table(f"{CATALOG}.{SCHEMA}.silver_shipment")
df_events   = spark.table(f"{CATALOG}.{SCHEMA}.silver_carrier_events")
df_extracts = spark.table(f"{CATALOG}.{SCHEMA}.silver_document_extraction")

# Latest event per shipment
w_latest = Window.partitionBy("shipment_id").orderBy(F.col("event_timestamp_utc").desc())
df_latest_event = (df_events
    .filter(F.col("is_duplicate") == False)
    .withColumn("rn", F.row_number().over(w_latest))
    .filter(F.col("rn") == 1)
    .select("shipment_id",
            F.col("canonical_status").alias("current_status"),
            F.col("event_timestamp_utc").alias("last_event_ts"),
            F.col("is_late_arrival").alias("has_late_arrival"))
)

# Highest confidence extraction per shipment
w_conf = Window.partitionBy("shipment_id").orderBy(F.col("confidence_score").desc())
df_best_doc = (df_extracts
    .withColumn("rn", F.row_number().over(w_conf))
    .filter(F.col("rn") == 1)
    .select("shipment_id",
            F.col("delivery_result").alias("doc_delivery_result"),
            F.col("confidence_score").alias("doc_confidence"))
)

df_gold_tracking = (df_ship
    .join(df_latest_event, "shipment_id", "left")
    .join(df_best_doc,     "shipment_id", "left")
    .withColumn("is_delivered",
        F.col("current_status").isin(["delivered"]) |
        (F.col("doc_delivery_result") == "DELIVERED"))
    .withColumn("has_damage",
        F.col("doc_delivery_result").isin(["DAMAGED", "PARTIAL"]))
    .withColumn("gold_processed_at", F.lit(STARTED_AT.isoformat()).cast("timestamp"))
    .select(
        "shipment_id", "tracking_number_normalized", "carrier_normalized",
        "origin", "destination", "promised_delivery_date",
        "current_status", "last_event_ts", "has_late_arrival",
        "doc_delivery_result", "doc_confidence",
        "is_delivered", "has_damage", "is_valid",
        "gold_processed_at"
    )
)

(df_gold_tracking.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.gold_shipment_tracking"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.gold_shipment_tracking IS 'Gold — consolidated shipment tracking status with delivery confirmation'")

gt_count = spark.table(f"{CATALOG}.{SCHEMA}.gold_shipment_tracking").count()
print(f"  gold_shipment_tracking : {gt_count} rows")

log_qc("gold", "gold_tracking_no_null_id",   "gold_shipment_tracking", "shipment_id IS NOT NULL")
log_qc("gold", "gold_tracking_carrier_known", "gold_shipment_tracking", "carrier_normalized IS NOT NULL")
```

---

```python
# --------------------------------------------------
# Step 2: gold_carrier_event_timeline
# --------------------------------------------------
print("\n=== Step 2: gold_carrier_event_timeline ===")

df_gold_timeline = (df_events
    .filter(F.col("is_duplicate") == False)
    .join(df_ship.select("shipment_id", "carrier_normalized", "promised_delivery_date"),
          "shipment_id", "left")
    .select(
        "event_id", "event_hash", "shipment_id",
        "tracking_number", "carrier_normalized",
        "canonical_status", "event_timestamp_utc",
        "event_sequence", "is_late_arrival", "arrival_lag_sec",
        "promised_delivery_date",
        F.lit(STARTED_AT.isoformat()).cast("timestamp").alias("gold_processed_at")
    )
)

(df_gold_timeline.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.gold_carrier_event_timeline"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.gold_carrier_event_timeline IS 'Gold — full deduplicated carrier event timeline per shipment'")

timeline_count = spark.table(f"{CATALOG}.{SCHEMA}.gold_carrier_event_timeline").count()
print(f"  gold_carrier_event_timeline : {timeline_count} rows")

log_qc("gold", "gold_timeline_no_dups",   "gold_carrier_event_timeline", "1=1")  # all pre-filtered
log_qc("gold", "gold_timeline_no_null_id","gold_carrier_event_timeline", "event_id IS NOT NULL")
```

---

```python
# --------------------------------------------------
# Step 3: gold_document_intelligence
# --------------------------------------------------
print("\n=== Step 3: gold_document_intelligence ===")

df_decisions = spark.table(f"{CATALOG}.{SCHEMA}.audit_human_decisions") \
    .select("shipment_id",
            F.col("decision").alias("human_decision"),
            F.col("decided_at").alias("decision_ts"))

# Best extraction per shipment (already computed as df_best_doc)
df_gold_docs = (df_best_doc
    .join(df_decisions, "shipment_id", "left")
    .withColumn("final_delivery_result",
        F.when(F.col("human_decision").isin(["ACCEPT_LOW_CONF", "ACCEPT_DAMAGE_CLAIM"]),
               F.col("doc_delivery_result"))
        .when(F.col("human_decision") == "REJECT_EXTRACTION", F.lit("REJECTED"))
        .otherwise(F.col("doc_delivery_result")))
    .withColumn("gold_processed_at", F.lit(STARTED_AT.isoformat()).cast("timestamp"))
    .select(
        "shipment_id",
        "doc_delivery_result", "doc_confidence",
        "human_decision", "decision_ts",
        "final_delivery_result", "gold_processed_at"
    )
)

(df_gold_docs.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.gold_document_intelligence"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.gold_document_intelligence IS 'Gold — document extraction results merged with human review decisions'")

gdi_count = spark.table(f"{CATALOG}.{SCHEMA}.gold_document_intelligence").count()
print(f"  gold_document_intelligence : {gdi_count} rows")

log_qc("gold", "gold_doc_intel_no_null_id", "gold_document_intelligence", "shipment_id IS NOT NULL")
```

---

```python
# --------------------------------------------------
# Step 4: gold_exception_summary
# --------------------------------------------------
print("\n=== Step 4: gold_exception_summary ===")

EXCEPTION_TRIGGERS = {
    "DUPLICATE_EVENT":       "is_duplicate = true",
    "LATE_ARRIVAL":          "is_late_arrival = true",
    "LOW_CONFIDENCE_DOC":    "doc_confidence < 0.80",
    "DAMAGE_CLAIM":          "doc_delivery_result IN ('DAMAGED', 'PARTIAL')",
    "FUZZY_MATCH":           "match_method = 'FUZZY'",
}

exception_rows = []

# Duplicates from silver_carrier_events
for row in spark.table(f"{CATALOG}.{SCHEMA}.silver_carrier_events") \
        .filter("is_duplicate = true") \
        .select("shipment_id", "event_hash").collect():
    exception_rows.append((
        str(uuid.uuid4()), row["shipment_id"], "DUPLICATE_EVENT",
        f"event_hash={row['event_hash']}", "OPEN", STARTED_AT
    ))

# Late arrivals
for row in spark.table(f"{CATALOG}.{SCHEMA}.silver_carrier_events") \
        .filter("is_late_arrival = true") \
        .select("shipment_id", "arrival_lag_sec").collect():
    exception_rows.append((
        str(uuid.uuid4()), row["shipment_id"], "LATE_ARRIVAL",
        f"lag_sec={row['arrival_lag_sec']}", "OPEN", STARTED_AT
    ))

# Low confidence docs
for row in spark.table(f"{CATALOG}.{SCHEMA}.silver_document_extraction") \
        .filter("confidence_score < 0.80") \
        .select("shipment_id", "confidence_score").collect():
    exception_rows.append((
        str(uuid.uuid4()), row["shipment_id"], "LOW_CONFIDENCE_DOC",
        f"confidence={row['confidence_score']}", "OPEN", STARTED_AT
    ))

# Damage claims
for row in spark.table(f"{CATALOG}.{SCHEMA}.silver_document_extraction") \
        .filter("delivery_result IN ('DAMAGED', 'PARTIAL')") \
        .select("shipment_id", "delivery_result", "damage_note").collect():
    exception_rows.append((
        str(uuid.uuid4()), row["shipment_id"], "DAMAGE_CLAIM",
        f"result={row['delivery_result']}", "OPEN", STARTED_AT
    ))

# Fuzzy matches
for row in spark.table(f"{CATALOG}.{SCHEMA}.silver_tracking_map") \
        .filter("match_method = 'FUZZY'") \
        .select("shipment_id", "match_confidence").collect():
    exception_rows.append((
        str(uuid.uuid4()), row["shipment_id"], "FUZZY_MATCH",
        f"confidence={row['match_confidence']}", "OPEN", STARTED_AT
    ))

from pyspark.sql.types import StructType, StructField, StringType, TimestampType

schema_exc = StructType([
    StructField("exception_id",   StringType()),
    StructField("shipment_id",    StringType()),
    StructField("exception_type", StringType()),
    StructField("exception_detail", StringType()),
    StructField("status",         StringType()),
    StructField("created_at",     TimestampType()),
])

df_exceptions = spark.createDataFrame(exception_rows, schema_exc)

(df_exceptions.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.gold_exception_summary"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.gold_exception_summary IS 'Gold — all exception types consolidated: duplicates, late arrivals, damage, low confidence, fuzzy match'")

exc_count = spark.table(f"{CATALOG}.{SCHEMA}.gold_exception_summary").count()
print(f"  gold_exception_summary : {exc_count} rows")

for etype, cnt in spark.table(f"{CATALOG}.{SCHEMA}.gold_exception_summary") \
        .groupBy("exception_type").count().collect():
    print(f"    {etype}: {cnt}")

log_qc("gold", "gold_exception_no_null_id",   "gold_exception_summary", "exception_id IS NOT NULL")
log_qc("gold", "gold_exception_no_null_ship",  "gold_exception_summary", "shipment_id IS NOT NULL")
log_qc("gold", "gold_exception_valid_type",    "gold_exception_summary",
       "exception_type IN ('DUPLICATE_EVENT','LATE_ARRIVAL','LOW_CONFIDENCE_DOC','DAMAGE_CLAIM','FUZZY_MATCH')")
```

---

```python
# --------------------------------------------------
# Step 5: Audit pipeline execution
# --------------------------------------------------
print("\n=== Step 5: Audit Logging ===")

total_gold = gt_count + timeline_count + gdi_count + exc_count
COMPLETED_AT = datetime.now(timezone.utc)

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '07_Gold_Shipment_Tracking', 'gold',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', {total_gold}, NULL, current_timestamp())
""")

print(f"\n=== Gold Shipment Tracking complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration                    : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print(f"  gold_shipment_tracking      : {gt_count}")
print(f"  gold_carrier_event_timeline : {timeline_count}")
print(f"  gold_document_intelligence  : {gdi_count}")
print(f"  gold_exception_summary      : {exc_count}")
```
