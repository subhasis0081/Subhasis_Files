# 08 — Gold: SLA Calculation
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/GOLD_RULES.md`, `architecture/DATA_MODEL.md`.

Calculates SLA variance for every delivered shipment. Tags breaches as exceptions. Produces `gold_sla_performance`. Logs quality checks and pipeline execution.

---

```python
# ============================================================
# 08_Gold_SLA — SLA Variance Calculation & Breach Detection
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
from datetime import datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.window import Window

CATALOG      = "dbx_cohort1_wave1"
SCHEMA       = "sch_pod13"
EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)
SLA_RULE_VER = "sla-v1.0"

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Execution ID  : {EXECUTION_ID}")
print(f"SLA rule ver  : {SLA_RULE_VER}")

def log_qc(check_layer, check_name, table_name, check_expr):
    df     = spark.table(f"{CATALOG}.{SCHEMA}.{table_name}")
    total  = df.count()
    passed = df.filter(check_expr).count()
    failed = total - passed
    rate   = round((passed / total * 100), 2) if total > 0 else 0.0
    status = "PASS" if rate >= 99 else ("WARN" if rate >= 95 else "FAIL")
    qc_id  = str(uuid.uuid4())
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_data_quality VALUES
    ('{qc_id}', '{EXECUTION_ID}', '{check_layer}', '{check_name}',
     '{table_name}', "{check_expr}", {total}, {passed}, {failed},
     {rate}, '{status}', current_timestamp())
    """)
    print(f"  [{status}] {check_name}: {passed}/{total} ({rate}%)")
    return status
```

---

```python
# --------------------------------------------------
# Step 1: Identify actual delivery timestamps
# --------------------------------------------------
print("\n=== Step 1: Actual Delivery Timestamps ===")

# Latest "delivered" event per shipment
w_delivered = Window.partitionBy("shipment_id").orderBy(F.col("event_timestamp_utc").desc())

df_actual_delivery = (
    spark.table(f"{CATALOG}.{SCHEMA}.gold_carrier_event_timeline")
    .filter(F.col("canonical_status") == "delivered")
    .withColumn("rn", F.row_number().over(w_delivered))
    .filter(F.col("rn") == 1)
    .select(
        "shipment_id",
        F.col("event_timestamp_utc").alias("actual_delivery_ts")
    )
)

print(f"  Shipments with delivery event: {df_actual_delivery.count()}")
```

---

```python
# --------------------------------------------------
# Step 2: Join with shipment manifest for promised date
# --------------------------------------------------
print("\n=== Step 2: Join Promised vs Actual ===")

df_shipments = spark.table(f"{CATALOG}.{SCHEMA}.silver_shipment") \
    .select("shipment_id", "promised_delivery_date", "carrier_normalized", "origin", "destination")

df_sla_base = (df_shipments
    .join(df_actual_delivery, "shipment_id", "left")
    # Convert promised_delivery_date (DateType) to end-of-day timestamp for comparison
    .withColumn("promised_delivery_ts",
        F.to_timestamp(
            F.concat_ws(" ", F.col("promised_delivery_date").cast("string"), F.lit("23:59:59")),
            "yyyy-MM-dd HH:mm:ss"
        )
    )
)

print(f"  SLA base rows: {df_sla_base.count()}")
```

---

```python
# --------------------------------------------------
# Step 3: Compute SLA variance
# --------------------------------------------------
print("\n=== Step 3: SLA Variance Calculation ===")

# variance_hours = (actual_delivery - promised_delivery) / 3600
# Positive = late, Negative = early, NULL = not yet delivered

df_sla = (df_sla_base
    .withColumn("is_delivered", F.col("actual_delivery_ts").isNotNull())
    .withColumn("sla_variance_seconds",
        F.when(F.col("is_delivered"),
               F.unix_timestamp(F.col("actual_delivery_ts")) -
               F.unix_timestamp(F.col("promised_delivery_ts"))
        ).otherwise(F.lit(None).cast("long"))
    )
    .withColumn("variance_hours",
        F.when(F.col("sla_variance_seconds").isNotNull(),
               F.round(F.col("sla_variance_seconds") / 3600.0, 2)
        ).otherwise(F.lit(None).cast("double"))
    )
    .withColumn("sla_status",
        F.when(~F.col("is_delivered"),              F.lit("PENDING"))
        .when(F.col("variance_hours") <= 0,          F.lit("ON_TIME"))
        .when(F.col("variance_hours") <= 24,         F.lit("MINOR_BREACH"))
        .when(F.col("variance_hours") <= 72,         F.lit("MAJOR_BREACH"))
        .otherwise(                                  F.lit("CRITICAL_BREACH"))
    )
    .withColumn("is_sla_breach", F.col("sla_status") != "ON_TIME")
    .withColumn("sla_rule_version", F.lit(SLA_RULE_VER))
    .withColumn("gold_processed_at", F.lit(STARTED_AT.isoformat()).cast("timestamp"))
    .select(
        "shipment_id", "carrier_normalized", "origin", "destination",
        "promised_delivery_date", "promised_delivery_ts",
        "actual_delivery_ts", "is_delivered",
        "sla_variance_seconds", "variance_hours", "sla_status",
        "is_sla_breach", "sla_rule_version", "gold_processed_at"
    )
)

print("  SLA variance computed.")

# Stats
stats = df_sla.groupBy("sla_status").count().collect()
for row in stats:
    print(f"    {row['sla_status']}: {row['count']}")
```

---

```python
# --------------------------------------------------
# Step 4: Write gold_sla_performance
# --------------------------------------------------
print("\n=== Step 4: Write gold_sla_performance ===")

(df_sla.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.gold_sla_performance"))

spark.sql(f"COMMENT ON TABLE {CATALOG}.{SCHEMA}.gold_sla_performance IS 'Gold — SLA variance and breach classification per shipment (rule version: sla-v1.0)'")

sla_count = spark.table(f"{CATALOG}.{SCHEMA}.gold_sla_performance").count()
print(f"  gold_sla_performance : {sla_count} rows")

log_qc("gold", "gold_sla_no_null_id",     "gold_sla_performance", "shipment_id IS NOT NULL")
log_qc("gold", "gold_sla_valid_status",   "gold_sla_performance",
       "sla_status IN ('PENDING','ON_TIME','MINOR_BREACH','MAJOR_BREACH','CRITICAL_BREACH')")
log_qc("gold", "gold_sla_rule_version",   "gold_sla_performance", "sla_rule_version IS NOT NULL")
```

---

```python
# --------------------------------------------------
# Step 5: Tag SLA breaches as exceptions
# --------------------------------------------------
print("\n=== Step 5: Append SLA Breach Exceptions ===")

df_breaches = spark.table(f"{CATALOG}.{SCHEMA}.gold_sla_performance") \
    .filter("is_sla_breach = true AND is_delivered = true") \
    .select("shipment_id", "sla_status", "variance_hours")

breach_rows = df_breaches.collect()
print(f"  SLA breach exceptions to log: {len(breach_rows)}")

for row in breach_rows:
    exc_id = str(uuid.uuid4())
    detail = f"sla_status={row['sla_status']}, variance_hours={row['variance_hours']}"
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.gold_exception_summary VALUES
    ('{exc_id}', '{row['shipment_id']}', 'SLA_BREACH',
     '{detail}', 'OPEN', current_timestamp())
    """)

print(f"  SLA_BREACH exceptions appended to gold_exception_summary")
```

---

```python
# --------------------------------------------------
# Step 6: Audit logging
# --------------------------------------------------
print("\n=== Step 6: Audit Logging ===")
COMPLETED_AT = datetime.now(timezone.utc)

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '08_Gold_SLA', 'gold',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', {sla_count}, NULL, current_timestamp())
""")

total_breaches = df_breaches.count()
on_time        = sla_count - total_breaches - df_sla.filter("sla_status='PENDING'").count()

print(f"\n=== Gold SLA complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration         : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print(f"  Total shipments  : {sla_count}")
print(f"  SLA breaches     : {total_breaches}")
print(f"  On-time          : {on_time}")
```
