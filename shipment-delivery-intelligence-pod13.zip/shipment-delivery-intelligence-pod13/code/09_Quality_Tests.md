# 09 — Quality Tests
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/QUALITY_TESTS.md`.

Runs the full end-to-end test suite: Bronze BRZ-01–04, Silver SLV-01–10, Gold GLD-01–08, Audit AUD-01–03. Writes all results to `audit_data_quality`. Prints a final pass/fail summary.

---

```python
# ============================================================
# 09_Quality_Tests — Full Test Suite BRZ+SLV+GLD+AUD
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
from datetime import datetime, timezone
from pyspark.sql import functions as F

CATALOG      = "dbx_cohort1_wave1"
SCHEMA       = "sch_pod13"
EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Quality Test Execution ID : {EXECUTION_ID}")
print(f"Started at                : {STARTED_AT.isoformat()}")
print("=" * 60)

results = []

def run_test(layer, test_id, table_name, check_expr, description=""):
    try:
        df     = spark.table(f"{CATALOG}.{SCHEMA}.{table_name}")
        total  = df.count()
        passed = df.filter(check_expr).count()
        failed = total - passed
        rate   = round((passed / total * 100), 2) if total > 0 else 0.0
        status = "PASS" if rate >= 99 else ("WARN" if rate >= 95 else "FAIL")
    except Exception as e:
        total, passed, failed, rate, status = 0, 0, 0, 0.0, "ERROR"
        check_expr = str(e)[:200]

    qc_id = str(uuid.uuid4())
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_data_quality VALUES
    ('{qc_id}', '{EXECUTION_ID}', '{layer}', '{test_id}',
     '{table_name}', "{check_expr}", {total}, {passed}, {failed},
     {rate}, '{status}', current_timestamp())
    """)
    results.append({"id": test_id, "layer": layer, "status": status,
                    "table": table_name, "rate": rate})
    icon = "✓" if status == "PASS" else ("⚠" if status == "WARN" else "✗")
    print(f"  [{status}] {icon} {test_id} | {table_name} | {rate}%")
    return status
```

---

```python
# --------------------------------------------------
# BRONZE TESTS: BRZ-01 to BRZ-04
# --------------------------------------------------
print("\n─── BRONZE TESTS ─────────────────────────────────────")

run_test("bronze", "BRZ-01", "bronze_shipment_manifest",
         "shipment_id IS NOT NULL AND shipment_id != ''",
         "All rows have non-null shipment_id")

run_test("bronze", "BRZ-02", "bronze_carrier_events",
         "event_id IS NOT NULL AND tracking_number IS NOT NULL",
         "All carrier events have event_id and tracking_number")

run_test("bronze", "BRZ-03", "bronze_delivery_documents",
         "content_text IS NOT NULL AND content_hash IS NOT NULL",
         "All documents have content_text and content_hash")

run_test("bronze", "BRZ-04", "bronze_carrier_tracking_raw",
         "raw_payload IS NOT NULL",
         "All JSON payloads present in raw table")
```

---

```python
# --------------------------------------------------
# SILVER TESTS: SLV-01 to SLV-10
# --------------------------------------------------
print("\n─── SILVER TESTS ─────────────────────────────────────")

run_test("silver", "SLV-01", "silver_carrier_events",
         "event_hash IS NOT NULL AND length(event_hash) = 64",
         "All events have valid SHA-256 event_hash (64 chars)")

run_test("silver", "SLV-02", "silver_carrier_events",
         "is_duplicate = false",
         "No duplicate events in silver (duplicates flagged not removed)")

run_test("silver", "SLV-03", "silver_carrier_events",
         "event_sequence >= 1",
         "All events have positive event_sequence")

run_test("silver", "SLV-04", "silver_carrier_events",
         "canonical_status IN ('label_created','picked_up','in_transit','out_for_delivery','delivered','exception','returned','unknown')",
         "All canonical_status values are in approved list")

run_test("silver", "SLV-05", "silver_carrier_events",
         "arrival_lag_sec IS NOT NULL",
         "All events have arrival_lag_sec computed")

run_test("silver", "SLV-06", "silver_shipment",
         "is_valid = true",
         "All silver shipments passed validation")

run_test("silver", "SLV-07", "silver_shipment",
         "carrier_normalized IS NOT NULL AND tracking_number_normalized IS NOT NULL",
         "All silver shipments have normalised carrier and tracking number")

run_test("silver", "SLV-08", "silver_document_extraction",
         "confidence_score >= 0.0 AND confidence_score <= 1.0",
         "All confidence scores are between 0 and 1")

run_test("silver", "SLV-09", "silver_document_extraction",
         "NOT (confidence_score < 0.80 AND requires_review = false)",
         "All low-confidence extractions are flagged for review")

run_test("silver", "SLV-10", "silver_tracking_map",
         "match_method IN ('EXACT', 'FUZZY')",
         "All tracking map entries have valid match_method")
```

---

```python
# --------------------------------------------------
# GOLD TESTS: GLD-01 to GLD-08
# --------------------------------------------------
print("\n─── GOLD TESTS ────────────────────────────────────────")

run_test("gold", "GLD-01", "gold_shipment_tracking",
         "shipment_id IS NOT NULL",
         "All gold tracking rows have shipment_id")

run_test("gold", "GLD-02", "gold_shipment_tracking",
         "carrier_normalized IS NOT NULL",
         "All gold tracking rows have carrier_normalized")

run_test("gold", "GLD-03", "gold_carrier_event_timeline",
         "event_id IS NOT NULL AND event_hash IS NOT NULL",
         "All timeline rows have event_id and event_hash")

run_test("gold", "GLD-04", "gold_sla_performance",
         "sla_status IN ('PENDING','ON_TIME','MINOR_BREACH','MAJOR_BREACH','CRITICAL_BREACH')",
         "All SLA statuses are in approved enum")

run_test("gold", "GLD-05", "gold_sla_performance",
         "sla_rule_version IS NOT NULL AND sla_rule_version = 'sla-v1.0'",
         "SLA rule version is set correctly")

run_test("gold", "GLD-06", "gold_exception_summary",
         "exception_id IS NOT NULL",
         "All exceptions have exception_id")

run_test("gold", "GLD-07", "gold_exception_summary",
         "shipment_id IS NOT NULL",
         "All exceptions have shipment_id")

run_test("gold", "GLD-08", "gold_document_intelligence",
         "shipment_id IS NOT NULL",
         "All document intelligence rows have shipment_id")
```

---

```python
# --------------------------------------------------
# AUDIT TESTS: AUD-01 to AUD-03
# --------------------------------------------------
print("\n─── AUDIT TESTS ───────────────────────────────────────")

run_test("audit", "AUD-01", "audit_pipeline_execution",
         "execution_id IS NOT NULL AND notebook_name IS NOT NULL",
         "All pipeline execution audit rows are well-formed")

run_test("audit", "AUD-02", "audit_data_quality",
         "check_id IS NOT NULL AND table_name IS NOT NULL",
         "All data quality audit rows are well-formed")

run_test("audit", "AUD-03", "audit_human_decisions",
         "decision_id IS NOT NULL AND decision IS NOT NULL",
         "All human decision audit rows are well-formed")
```

---

```python
# --------------------------------------------------
# Summary
# --------------------------------------------------
COMPLETED_AT = datetime.now(timezone.utc)

total   = len(results)
passed  = sum(1 for r in results if r["status"] == "PASS")
warned  = sum(1 for r in results if r["status"] == "WARN")
failed  = sum(1 for r in results if r["status"] in ("FAIL","ERROR"))
pass_rt = round(passed / total * 100, 1) if total > 0 else 0.0

print("\n" + "=" * 60)
print(f"QUALITY TEST SUMMARY")
print("=" * 60)
print(f"  Total tests  : {total}")
print(f"  PASS         : {passed}")
print(f"  WARN         : {warned}")
print(f"  FAIL/ERROR   : {failed}")
print(f"  Pass rate    : {pass_rt}%")
print(f"  Duration     : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print("=" * 60)

if failed > 0:
    print("\nFailed / Warning tests:")
    for r in results:
        if r["status"] in ("FAIL", "WARN", "ERROR"):
            print(f"  [{r['status']}] {r['id']} — {r['table']} ({r['rate']}%)")

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '09_Quality_Tests', 'all',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', {total}, NULL, current_timestamp())
""")

print(f"\nQuality test run complete.")
```
