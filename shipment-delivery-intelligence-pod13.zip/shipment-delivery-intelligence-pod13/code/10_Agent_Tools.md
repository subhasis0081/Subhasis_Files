# 10 — Agent Tools (UC Table-Valued Functions)
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/AGENT_GUARDRAILS.md`, `architecture/DATA_MODEL.md`.

Creates 4 read-only Unity Catalog table-valued functions as agent tools. Agents call these functions — never raw tables — to enforce governance. All functions are view-only; no DML is permitted through them.

---

```python
# ============================================================
# 10_Agent_Tools — 4 UC Table-Valued Functions
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
from datetime import datetime, timezone

CATALOG      = "dbx_cohort1_wave1"
SCHEMA       = "sch_pod13"
EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Execution ID : {EXECUTION_ID}")
print(f"Started at   : {STARTED_AT.isoformat()}")
```

---

```sql
-- ===========================================================
-- Function 1: fn_get_shipment_status
-- Returns current status for a given shipment_id
-- ===========================================================
CREATE OR REPLACE FUNCTION dbx_cohort1_wave1.sch_pod13.fn_get_shipment_status(p_shipment_id STRING)
RETURNS TABLE (
  shipment_id            STRING,
  tracking_number        STRING,
  carrier                STRING,
  current_status         STRING,
  last_event_ts          TIMESTAMP,
  is_delivered           BOOLEAN,
  has_damage             BOOLEAN,
  has_late_arrival       BOOLEAN,
  promised_delivery_date DATE,
  doc_delivery_result    STRING,
  doc_confidence         DOUBLE
)
COMMENT 'Agent tool: returns current shipment status from gold_shipment_tracking. Read-only.'
RETURN
  SELECT
    g.shipment_id,
    g.tracking_number_normalized   AS tracking_number,
    g.carrier_normalized           AS carrier,
    g.current_status,
    g.last_event_ts,
    g.is_delivered,
    g.has_damage,
    g.has_late_arrival,
    g.promised_delivery_date,
    g.doc_delivery_result,
    g.doc_confidence
  FROM dbx_cohort1_wave1.sch_pod13.gold_shipment_tracking g
  WHERE g.shipment_id = p_shipment_id
```

---

```sql
-- ===========================================================
-- Function 2: fn_get_carrier_events
-- Returns all deduplicated events for a given shipment_id
-- ===========================================================
CREATE OR REPLACE FUNCTION dbx_cohort1_wave1.sch_pod13.fn_get_carrier_events(p_shipment_id STRING)
RETURNS TABLE (
  event_id             STRING,
  event_hash           STRING,
  shipment_id          STRING,
  tracking_number      STRING,
  carrier              STRING,
  canonical_status     STRING,
  event_timestamp_utc  TIMESTAMP,
  event_sequence       INT,
  is_duplicate         BOOLEAN,
  is_late_arrival      BOOLEAN,
  arrival_lag_sec      LONG
)
COMMENT 'Agent tool: returns full carrier event timeline from gold_carrier_event_timeline. Read-only.'
RETURN
  SELECT
    event_id,
    event_hash,
    shipment_id,
    tracking_number,
    carrier_normalized  AS carrier,
    canonical_status,
    event_timestamp_utc,
    event_sequence,
    false               AS is_duplicate,  -- gold only contains non-dupes
    is_late_arrival,
    arrival_lag_sec
  FROM dbx_cohort1_wave1.sch_pod13.gold_carrier_event_timeline
  WHERE shipment_id = p_shipment_id
  ORDER BY event_sequence
```

---

```sql
-- ===========================================================
-- Function 3: fn_get_document_extraction
-- Returns POD document extraction for a given shipment_id
-- ===========================================================
CREATE OR REPLACE FUNCTION dbx_cohort1_wave1.sch_pod13.fn_get_document_extraction(p_shipment_id STRING)
RETURNS TABLE (
  shipment_id           STRING,
  doc_delivery_result   STRING,
  doc_confidence        DOUBLE,
  human_decision        STRING,
  decision_ts           TIMESTAMP,
  final_delivery_result STRING
)
COMMENT 'Agent tool: returns document intelligence and human decision from gold_document_intelligence. Read-only.'
RETURN
  SELECT
    shipment_id,
    doc_delivery_result,
    doc_confidence,
    human_decision,
    decision_ts,
    final_delivery_result
  FROM dbx_cohort1_wave1.sch_pod13.gold_document_intelligence
  WHERE shipment_id = p_shipment_id
```

---

```sql
-- ===========================================================
-- Function 4: fn_get_exceptions
-- Returns open exceptions for a given shipment_id
-- ===========================================================
CREATE OR REPLACE FUNCTION dbx_cohort1_wave1.sch_pod13.fn_get_exceptions(p_shipment_id STRING)
RETURNS TABLE (
  exception_id     STRING,
  shipment_id      STRING,
  exception_type   STRING,
  exception_detail STRING,
  status           STRING,
  created_at       TIMESTAMP
)
COMMENT 'Agent tool: returns exceptions from gold_exception_summary. Read-only.'
RETURN
  SELECT
    exception_id,
    shipment_id,
    exception_type,
    exception_detail,
    status,
    created_at
  FROM dbx_cohort1_wave1.sch_pod13.gold_exception_summary
  WHERE shipment_id = p_shipment_id
  ORDER BY created_at DESC
```

---

```python
# --------------------------------------------------
# Step 5: Verify all 4 functions exist and are callable
# --------------------------------------------------
print("\n=== Verify UC Functions ===")

DEMO_SHIPMENT = "SHP-100011"
functions = [
    ("fn_get_shipment_status",    f"SELECT * FROM dbx_cohort1_wave1.sch_pod13.fn_get_shipment_status('{DEMO_SHIPMENT}')"),
    ("fn_get_carrier_events",     f"SELECT * FROM dbx_cohort1_wave1.sch_pod13.fn_get_carrier_events('{DEMO_SHIPMENT}')"),
    ("fn_get_document_extraction",f"SELECT * FROM dbx_cohort1_wave1.sch_pod13.fn_get_document_extraction('{DEMO_SHIPMENT}')"),
    ("fn_get_exceptions",         f"SELECT * FROM dbx_cohort1_wave1.sch_pod13.fn_get_exceptions('{DEMO_SHIPMENT}')"),
]

for fn_name, sql in functions:
    try:
        result = spark.sql(sql)
        cnt    = result.count()
        print(f"  [OK] {fn_name} — returned {cnt} rows for {DEMO_SHIPMENT}")
    except Exception as e:
        print(f"  [ERROR] {fn_name} — {str(e)[:100]}")
```

---

```python
# --------------------------------------------------
# Step 6: Audit logging
# --------------------------------------------------
print("\n=== Audit Logging ===")
COMPLETED_AT = datetime.now(timezone.utc)

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '10_Agent_Tools', 'gold',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', 4, NULL, current_timestamp())
""")

print(f"\n=== Agent Tools complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration          : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print(f"  UC Functions created: 4")
print(f"    - fn_get_shipment_status")
print(f"    - fn_get_carrier_events")
print(f"    - fn_get_document_extraction")
print(f"    - fn_get_exceptions")
```
