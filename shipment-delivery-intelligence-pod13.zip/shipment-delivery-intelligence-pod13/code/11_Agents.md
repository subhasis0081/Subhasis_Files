# 11 — Agents
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/AGENT_GUARDRAILS.md`.

Implements 4 Python agent classes. Every agent answer cites evidence from UC functions. Human approval is required before any status change, exception close, or low-confidence accept. Logs all agent actions to `audit_agent_activity`.

---

```python
# ============================================================
# 11_Agents — 4 Python Agent Classes
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
import json
from datetime import datetime, timezone
from pyspark.sql import functions as F

CATALOG      = "dbx_cohort1_wave1"
SCHEMA       = "sch_pod13"
EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Execution ID : {EXECUTION_ID}")
print(f"Started at   : {STARTED_AT.isoformat()}")

# ──────────────────────────────────────────────────────────
# Shared helpers
# ──────────────────────────────────────────────────────────

def require_human_approval(action_type: str, shipment_id: str, details: dict) -> bool:
    """
    Governance gate: always returns True (simulated approval).
    In production this would write to a human review queue and
    block until a human approves via the review UI.
    """
    approval_id = str(uuid.uuid4())
    details_str = json.dumps(details).replace("'", "''")
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_human_decisions VALUES
    ('{approval_id}', '{EXECUTION_ID}', 'AGENT_APPROVAL_REQUEST', '{shipment_id}',
     'PENDING_APPROVAL', 'AGENT_SYSTEM',
     '{action_type}: {details_str}', current_timestamp())
    """)
    # Simulate approval
    print(f"    [APPROVAL] {action_type} for {shipment_id} → APPROVED (simulated)")
    return True

def log_agent_action(agent_name: str, shipment_id: str,
                     action: str, evidence: dict, outcome: str):
    act_id      = str(uuid.uuid4())
    evidence_str = json.dumps(evidence).replace("'", "''")
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_agent_activity VALUES
    ('{act_id}', '{EXECUTION_ID}', '{agent_name}', '{shipment_id}',
     '{action}', '{evidence_str}', '{outcome}', current_timestamp())
    """)
```

---

```python
# ──────────────────────────────────────────────────────────
# Agent 1: ShipmentInvestigationAgent
# ──────────────────────────────────────────────────────────
print("\n=== Agent 1: ShipmentInvestigationAgent ===")

class ShipmentInvestigationAgent:
    """
    Investigates a shipment's current status and event timeline.
    Uses: fn_get_shipment_status, fn_get_carrier_events
    """
    NAME = "ShipmentInvestigationAgent"

    def investigate(self, shipment_id: str) -> dict:
        print(f"  Investigating: {shipment_id}")

        # Tool calls
        status_rows = spark.sql(
            f"SELECT * FROM {CATALOG}.{SCHEMA}.fn_get_shipment_status('{shipment_id}')"
        ).collect()

        event_rows = spark.sql(
            f"SELECT * FROM {CATALOG}.{SCHEMA}.fn_get_carrier_events('{shipment_id}')"
        ).collect()

        if not status_rows:
            result = {"finding": "SHIPMENT_NOT_FOUND", "shipment_id": shipment_id}
            log_agent_action(self.NAME, shipment_id, "INVESTIGATE", {}, "NOT_FOUND")
            return result

        status = status_rows[0]
        events = event_rows

        late_events = [e for e in events if e["is_late_arrival"]]
        last_status = events[-1]["canonical_status"] if events else "unknown"

        evidence = {
            "current_status":    status["current_status"],
            "is_delivered":      status["is_delivered"],
            "has_late_arrival":  status["has_late_arrival"],
            "event_count":       len(events),
            "late_event_count":  len(late_events),
            "last_event_status": last_status,
        }

        finding = "NORMAL"
        if status["has_late_arrival"]:
            finding = "LATE_ARRIVAL_DETECTED"
        if not status["is_delivered"] and last_status == "exception":
            finding = "EXCEPTION_IN_TRANSIT"

        log_agent_action(self.NAME, shipment_id, "INVESTIGATE", evidence, finding)

        return {
            "shipment_id":  shipment_id,
            "finding":      finding,
            "evidence":     evidence,
            "recommendation": "Escalate to ExceptionAgent" if finding != "NORMAL" else "No action required",
        }

agent_investigate = ShipmentInvestigationAgent()
```

---

```python
# ──────────────────────────────────────────────────────────
# Agent 2: DocumentIntelligenceAgent
# ──────────────────────────────────────────────────────────
print("\n=== Agent 2: DocumentIntelligenceAgent ===")

class DocumentIntelligenceAgent:
    """
    Reviews document extraction results. Requires human approval
    before accepting low-confidence extractions.
    Uses: fn_get_document_extraction, fn_get_shipment_status
    """
    NAME = "DocumentIntelligenceAgent"
    CONFIDENCE_THRESHOLD = 0.80

    def review(self, shipment_id: str) -> dict:
        print(f"  Reviewing doc for: {shipment_id}")

        doc_rows = spark.sql(
            f"SELECT * FROM {CATALOG}.{SCHEMA}.fn_get_document_extraction('{shipment_id}')"
        ).collect()

        if not doc_rows:
            log_agent_action(self.NAME, shipment_id, "REVIEW_DOC", {}, "NO_DOCUMENT")
            return {"finding": "NO_DOCUMENT", "shipment_id": shipment_id}

        doc = doc_rows[0]
        confidence = doc["doc_confidence"] or 0.0
        result_str = doc["doc_delivery_result"] or "UNKNOWN"

        evidence = {
            "delivery_result":    result_str,
            "confidence_score":   confidence,
            "human_decision":     doc["human_decision"],
            "final_result":       doc["final_delivery_result"],
        }

        if confidence < self.CONFIDENCE_THRESHOLD:
            approved = require_human_approval(
                "ACCEPT_LOW_CONFIDENCE_EXTRACTION", shipment_id,
                {"confidence": confidence, "result": result_str}
            )
            outcome = "ACCEPTED_WITH_APPROVAL" if approved else "REJECTED_LOW_CONFIDENCE"
        elif result_str in ("DAMAGED", "PARTIAL"):
            approved = require_human_approval(
                "ACCEPT_DAMAGE_CLAIM", shipment_id,
                {"delivery_result": result_str}
            )
            outcome = "DAMAGE_CLAIM_ACCEPTED" if approved else "DAMAGE_CLAIM_REJECTED"
        else:
            outcome = "AUTO_ACCEPTED"

        log_agent_action(self.NAME, shipment_id, "REVIEW_DOC", evidence, outcome)

        return {
            "shipment_id": shipment_id,
            "outcome":     outcome,
            "evidence":    evidence,
        }

agent_doc = DocumentIntelligenceAgent()
```

---

```python
# ──────────────────────────────────────────────────────────
# Agent 3: ExceptionAgent
# ──────────────────────────────────────────────────────────
print("\n=== Agent 3: ExceptionAgent ===")

class ExceptionAgent:
    """
    Manages open exceptions. Requires human approval before closing
    an exception or escalating to carrier.
    Uses: fn_get_exceptions, fn_get_shipment_status
    """
    NAME = "ExceptionAgent"

    def handle(self, shipment_id: str) -> dict:
        print(f"  Handling exceptions for: {shipment_id}")

        exc_rows = spark.sql(
            f"SELECT * FROM {CATALOG}.{SCHEMA}.fn_get_exceptions('{shipment_id}')"
        ).collect()

        if not exc_rows:
            log_agent_action(self.NAME, shipment_id, "HANDLE_EXCEPTION", {}, "NO_EXCEPTIONS")
            return {"finding": "NO_EXCEPTIONS", "shipment_id": shipment_id}

        actions = []
        for exc in exc_rows:
            exc_type = exc["exception_type"]
            evidence = {
                "exception_id":   exc["exception_id"],
                "exception_type": exc_type,
                "detail":         exc["exception_detail"],
            }

            if exc_type == "SLA_BREACH":
                approved = require_human_approval(
                    "CLOSE_SLA_EXCEPTION", shipment_id,
                    {"exception_id": exc["exception_id"]}
                )
                outcome = "SLA_EXCEPTION_CLOSED" if approved else "SLA_EXCEPTION_PENDING"
            elif exc_type == "DAMAGE_CLAIM":
                approved = require_human_approval(
                    "ESCALATE_TO_CARRIER", shipment_id,
                    {"exception_id": exc["exception_id"]}
                )
                outcome = "ESCALATED_TO_CARRIER" if approved else "DAMAGE_CLAIM_PENDING"
            elif exc_type in ("DUPLICATE_EVENT", "LATE_ARRIVAL"):
                outcome = "ACKNOWLEDGED_AUTO"
            else:
                outcome = "REVIEWED_NO_ACTION"

            log_agent_action(self.NAME, shipment_id, f"HANDLE_{exc_type}", evidence, outcome)
            actions.append({"exception_id": exc["exception_id"], "outcome": outcome})

        return {
            "shipment_id":    shipment_id,
            "actions_taken":  actions,
            "exception_count": len(exc_rows),
        }

agent_exception = ExceptionAgent()
```

---

```python
# ──────────────────────────────────────────────────────────
# Agent 4: SupervisorAgent
# ──────────────────────────────────────────────────────────
print("\n=== Agent 4: SupervisorAgent ===")

class SupervisorAgent:
    """
    Orchestrates all sub-agents. Runs investigation → doc review → exception handling
    in sequence. Aggregates findings. Requires human approval before status change.
    """
    NAME = "SupervisorAgent"

    def __init__(self):
        self.investigator = ShipmentInvestigationAgent()
        self.doc_agent    = DocumentIntelligenceAgent()
        self.exc_agent    = ExceptionAgent()

    def orchestrate(self, shipment_id: str) -> dict:
        print(f"\n  [Supervisor] Orchestrating: {shipment_id}")

        # Step 1: Investigate
        inv_result = self.investigator.investigate(shipment_id)

        # Step 2: Document review
        doc_result = self.doc_agent.review(shipment_id)

        # Step 3: Exception handling
        exc_result = self.exc_agent.handle(shipment_id)

        # Aggregate summary
        summary = {
            "shipment_id":        shipment_id,
            "investigation":      inv_result.get("finding", "UNKNOWN"),
            "doc_outcome":        doc_result.get("outcome", "NO_DOC"),
            "exception_count":    exc_result.get("exception_count", 0),
            "exception_outcomes": exc_result.get("actions_taken", []),
        }

        # Supervisor decision: status change?
        needs_status_change = (
            inv_result.get("finding") in ("EXCEPTION_IN_TRANSIT",) or
            doc_result.get("outcome")  in ("DAMAGE_CLAIM_ACCEPTED",)
        )

        if needs_status_change:
            approved = require_human_approval(
                "STATUS_CHANGE", shipment_id,
                {"reason": "Exception or damage found by supervisor"}
            )
            summary["status_change_approved"] = approved

        evidence = {
            "investigation_finding": inv_result.get("finding"),
            "doc_outcome":           doc_result.get("outcome"),
            "exceptions":            exc_result.get("exception_count", 0),
        }
        log_agent_action(
            self.NAME, shipment_id, "ORCHESTRATE",
            evidence,
            "COMPLETE_STATUS_CHANGE_APPROVED" if needs_status_change else "COMPLETE"
        )

        return summary

supervisor = SupervisorAgent()
```

---

```python
# ──────────────────────────────────────────────────────────
# Step 5: Run on demo shipments
# ──────────────────────────────────────────────────────────
print("\n=== Step 5: Run Demo Orchestration ===")

DEMO_SHIPMENTS = [
    "SHP-100011",  # normal
    "SHP-100012",  # damaged
    "SHP-100636",  # missing_pod
    "SHP-100141",  # low_confidence
    "SHP-100698",  # human_review
]

demo_results = []
for sid in DEMO_SHIPMENTS:
    try:
        result = supervisor.orchestrate(sid)
        demo_results.append(result)
        print(f"\n  [{sid}] Investigation={result['investigation']} | Doc={result['doc_outcome']} | Exceptions={result['exception_count']}")
    except Exception as e:
        print(f"  [{sid}] ERROR: {str(e)[:100]}")

print(f"\n  Orchestrated: {len(demo_results)} shipments")
```

---

```python
# ──────────────────────────────────────────────────────────
# Step 6: Audit logging
# ──────────────────────────────────────────────────────────
print("\n=== Step 6: Audit Logging ===")
COMPLETED_AT = datetime.now(timezone.utc)

agent_audit_count = spark.table(f"{CATALOG}.{SCHEMA}.audit_agent_activity") \
    .filter(f"execution_id = '{EXECUTION_ID}'").count()

spark.sql(f"""
INSERT INTO {CATALOG}.{SCHEMA}.audit_pipeline_execution VALUES
('{EXECUTION_ID}', '11_Agents', 'agents',
 '{STARTED_AT.isoformat()}', '{COMPLETED_AT.isoformat()}',
 'SUCCESS', {len(demo_results)}, NULL, current_timestamp())
""")

print(f"\n=== Agents complete at {COMPLETED_AT.isoformat()} ===")
print(f"  Duration            : {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print(f"  Shipments processed : {len(demo_results)}")
print(f"  Agent audit entries : {agent_audit_count}")
```
