# 12 — Final Demo
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Reads `architecture/DEMO_PLAN.md`.

Runs all 8 demo scenarios end-to-end. Each scenario traces a fixed shipment ID through the full pipeline: Bronze → Silver → Gold → Agent. Prints evidence and outcomes.

---

```python
# ============================================================
# 12_Final_Demo — 8 Demo Scenarios End-to-End
# Pod 13 | dbx_cohort1_wave1.sch_pod13
# ============================================================
import uuid
import json
from datetime import datetime, timezone
from pyspark.sql import functions as F

CATALOG      = "dbx_cohort1_wave1"
SCHEMA       = "sch_pod13"
EXECUTION_ID = str(uuid.uuid4())
STARTED_AT   = datetime.now(timezone.utc)

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Demo Execution ID : {EXECUTION_ID}")
print(f"Started at        : {STARTED_AT.isoformat()}")
print("=" * 70)

DEMO_SCENARIOS = [
    {"id": "SHP-100011", "label": "NORMAL DELIVERY",       "description": "Clean delivery, no exceptions expected"},
    {"id": "SHP-102253", "label": "DUPLICATE EVENT",        "description": "Event appears more than once in carrier feed"},
    {"id": "SHP-102706", "label": "LATE ARRIVAL",           "description": "Event timestamp outside arrival window (>3600s)"},
    {"id": "SHP-100002", "label": "SCHEMA DRIFT",           "description": "Payload missing mandatory fields → quarantine"},
    {"id": "SHP-100012", "label": "DAMAGED DELIVERY",       "description": "POD document notes damage at delivery"},
    {"id": "SHP-100636", "label": "MISSING POD",            "description": "No proof-of-delivery document found"},
    {"id": "SHP-100141", "label": "LOW CONFIDENCE DOC",     "description": "Extraction confidence below 0.80 threshold"},
    {"id": "SHP-100698", "label": "HUMAN REVIEW REQUIRED",  "description": "Multiple flags trigger mandatory human review"},
]

def section(title):
    print(f"\n{'─' * 70}")
    print(f"  {title}")
    print('─' * 70)

def query_one(sql):
    rows = spark.sql(sql).collect()
    return rows[0] if rows else None

def query_all(sql):
    return spark.sql(sql).collect()
```

---

```python
# --------------------------------------------------
# Demo helper: trace a shipment end-to-end
# --------------------------------------------------
def trace_shipment(scenario: dict):
    sid   = scenario["id"]
    label = scenario["label"]
    desc  = scenario["description"]

    section(f"[{label}]  Shipment: {sid}")
    print(f"  Scenario: {desc}")

    # ── Bronze ──────────────────────────────────────────────
    bronze = query_one(f"""
        SELECT shipment_id, carrier, tracking_number, origin, destination,
               promised_delivery_date
        FROM {CATALOG}.{SCHEMA}.bronze_shipment_manifest
        WHERE shipment_id = '{sid}'
    """)
    if bronze:
        print(f"\n  BRONZE:")
        print(f"    Carrier         : {bronze['carrier']}")
        print(f"    Tracking #      : {bronze['tracking_number']}")
        print(f"    Route           : {bronze['origin']} → {bronze['destination']}")
        print(f"    Promised Del.   : {bronze['promised_delivery_date']}")
    else:
        print(f"\n  BRONZE: ⚠ Not found in bronze_shipment_manifest")

    # ── Silver ──────────────────────────────────────────────
    silver_ship = query_one(f"""
        SELECT is_valid, validation_flags, carrier_normalized, tracking_number_normalized
        FROM {CATALOG}.{SCHEMA}.silver_shipment
        WHERE shipment_id = '{sid}'
    """)
    if silver_ship:
        print(f"\n  SILVER (shipment):")
        print(f"    is_valid        : {silver_ship['is_valid']}")
        print(f"    Carrier (norm.) : {silver_ship['carrier_normalized']}")
        print(f"    Tracking (norm.): {silver_ship['tracking_number_normalized']}")
    else:
        print(f"\n  SILVER (shipment): not found")

    # Check quarantine
    in_quar = query_one(f"""
        SELECT count(*) as cnt
        FROM {CATALOG}.{SCHEMA}.quarantine_carrier_events
        WHERE shipment_id = '{sid}'
    """)
    if in_quar and in_quar["cnt"] > 0:
        print(f"    ⚠ Quarantined events: {in_quar['cnt']}")

    # Events
    events = query_all(f"""
        SELECT canonical_status, event_timestamp_utc, event_sequence,
               is_duplicate, is_late_arrival
        FROM {CATALOG}.{SCHEMA}.silver_carrier_events
        WHERE shipment_id = '{sid}'
        ORDER BY event_sequence
    """)
    if events:
        print(f"\n  SILVER (events): {len(events)} events")
        dupes = [e for e in events if e["is_duplicate"]]
        late  = [e for e in events if e["is_late_arrival"]]
        for e in events[:5]:
            print(f"    [{e['event_sequence']}] {e['canonical_status']}"
                  f"{'  ← DUPLICATE' if e['is_duplicate'] else ''}"
                  f"{'  ← LATE' if e['is_late_arrival'] else ''}")
        if dupes:
            print(f"    Duplicate events flagged : {len(dupes)}")
        if late:
            print(f"    Late arrivals flagged    : {len(late)}")

    # Document
    doc_row = query_one(f"""
        SELECT delivery_result, confidence_score, requires_review,
               damage_note
        FROM {CATALOG}.{SCHEMA}.silver_document_extraction
        WHERE shipment_id = '{sid}'
    """)
    if doc_row:
        print(f"\n  SILVER (document):")
        print(f"    Delivery result   : {doc_row['delivery_result']}")
        print(f"    Confidence        : {doc_row['confidence_score']}")
        print(f"    Requires review   : {doc_row['requires_review']}")
        if doc_row["damage_note"]:
            print(f"    Damage note       : {doc_row['damage_note'][:80]}")
    else:
        print(f"\n  SILVER (document): ⚠ No POD document found")

    # ── Gold ────────────────────────────────────────────────
    gold_track = query_one(f"""
        SELECT * FROM {CATALOG}.{SCHEMA}.fn_get_shipment_status('{sid}')
    """)
    if gold_track:
        print(f"\n  GOLD (status):")
        print(f"    current_status    : {gold_track['current_status']}")
        print(f"    is_delivered      : {gold_track['is_delivered']}")
        print(f"    has_damage        : {gold_track['has_damage']}")
        print(f"    has_late_arrival  : {gold_track['has_late_arrival']}")

    gold_sla = query_one(f"""
        SELECT sla_status, variance_hours, is_sla_breach
        FROM {CATALOG}.{SCHEMA}.gold_sla_performance
        WHERE shipment_id = '{sid}'
    """)
    if gold_sla:
        print(f"\n  GOLD (SLA):")
        print(f"    sla_status        : {gold_sla['sla_status']}")
        print(f"    variance_hours    : {gold_sla['variance_hours']}")
        print(f"    is_sla_breach     : {gold_sla['is_sla_breach']}")

    exceptions = query_all(f"""
        SELECT * FROM {CATALOG}.{SCHEMA}.fn_get_exceptions('{sid}')
    """)
    if exceptions:
        print(f"\n  GOLD (exceptions): {len(exceptions)}")
        for exc in exceptions:
            print(f"    [{exc['exception_type']}] {exc['status']} — {exc['exception_detail'][:60]}")

    # ── Human Review ─────────────────────────────────────────
    hr_row = query_one(f"""
        SELECT review_type, priority, review_context
        FROM {CATALOG}.{SCHEMA}.silver_human_review_queue
        WHERE shipment_id = '{sid}'
        LIMIT 1
    """)
    if hr_row:
        print(f"\n  HUMAN REVIEW QUEUE:")
        print(f"    type     : {hr_row['review_type']}")
        print(f"    priority : {hr_row['priority']}")
        print(f"    context  : {hr_row['review_context'][:80]}")

    print(f"\n  {'✓ COMPLETE':>66}")
```

---

```python
# --------------------------------------------------
# Run all 8 demo scenarios
# --------------------------------------------------
print("\n" + "=" * 70)
print("   SHIPMENT TRACKING & DELIVERY INTELLIGENCE DEMO — POD 13")
print("=" * 70)

for scenario in DEMO_SCENARIOS:
    try:
        trace_shipment(scenario)
    except Exception as e:
        print(f"\n  ERROR in {scenario['id']}: {str(e)[:100]}")
```

---

```python
# --------------------------------------------------
# Pipeline summary stats
# --------------------------------------------------
print("\n" + "=" * 70)
print("   PIPELINE SUMMARY STATISTICS")
print("=" * 70)

stats = {
    "bronze_shipment_manifest":   f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.bronze_shipment_manifest",
    "bronze_carrier_events":      f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.bronze_carrier_events",
    "silver_shipment":            f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.silver_shipment",
    "silver_carrier_events":      f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.silver_carrier_events",
    "silver_document_extraction": f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.silver_document_extraction",
    "gold_shipment_tracking":     f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.gold_shipment_tracking",
    "gold_sla_performance":       f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.gold_sla_performance",
    "gold_exception_summary":     f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.gold_exception_summary",
    "audit_human_decisions":      f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.audit_human_decisions",
    "audit_agent_activity":       f"SELECT count(*) FROM {CATALOG}.{SCHEMA}.audit_agent_activity",
}

for table, sql in stats.items():
    try:
        cnt = spark.sql(sql).collect()[0][0]
        print(f"  {table:<40}: {cnt:>7,}")
    except Exception as e:
        print(f"  {table:<40}: ERROR — {str(e)[:50]}")

COMPLETED_AT = datetime.now(timezone.utc)
print("\n" + "=" * 70)
print(f"  Demo complete at {COMPLETED_AT.isoformat()}")
print(f"  Duration: {(COMPLETED_AT - STARTED_AT).total_seconds():.2f}s")
print("=" * 70)
```
