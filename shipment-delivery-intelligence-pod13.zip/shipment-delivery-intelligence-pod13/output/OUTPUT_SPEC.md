# OUTPUT_SPEC
## Pod 13 | Shipment Tracking & Delivery Intelligence

Describes all tables, functions, and audit records produced by the complete pipeline.

---

## Bronze Tables (6)

| Table | Source File | Expected Rows | Key Columns |
|-------|-------------|---------------|-------------|
| `bronze_shipment_manifest` | shipment_manifest.csv | 3,000 | shipment_id, carrier, tracking_number |
| `bronze_dispatch` | warehouse_dispatch.csv | 3,000 | dispatch_id, shipment_id, dispatch_timestamp |
| `bronze_tracking_map` | shipment_tracking_map.csv | 3,000 | shipment_id, raw_tracking_number |
| `bronze_carrier_events` | carrier_tracking_events.csv | ~4,500–5,000 | event_id, shipment_id, event_status |
| `bronze_carrier_tracking_raw` | carrier_tracking_raw/*.json | ~3,000 | shipment_id, payload_version, raw_payload |
| `bronze_delivery_documents` | pod_documents/*.txt | ~2,800 | document_id, shipment_id, content_text, content_hash |

All Bronze tables carry: `source_file`, `source_record_id`, `batch_id`, `ingested_ts_utc`, `_rescued_data`

---

## Silver Tables (7)

| Table | Source | Expected Rows | Key Derived Columns |
|-------|--------|---------------|---------------------|
| `silver_shipment` | bronze_shipment_manifest | 3,000 | carrier_normalized, tracking_number_normalized, is_valid, validation_flags |
| `silver_dispatch` | bronze_dispatch | 3,000 | dispatch_timestamp_utc, shipment_exists |
| `silver_tracking_map` | bronze_tracking_map | 3,000 | canonical_tracking_number, match_method, match_confidence |
| `silver_carrier_events` | bronze_carrier_events | ~4,500–5,000 | event_hash, canonical_status, event_sequence, is_duplicate, is_late_arrival |
| `silver_document_extraction` | bronze_delivery_documents | ~2,800 | delivery_result, confidence_score, requires_review, damage_note |
| `silver_human_review_queue` | silver_document_extraction + silver_tracking_map | ~600–800 | review_type, priority, review_context, requires_human |
| `quarantine_carrier_events` | bronze_carrier_tracking_raw | ~90 | shipment_id, quarantine_reason |
| `quarantine_documents` | bronze_delivery_documents | ~210 | shipment_id, quarantine_reason |

---

## Gold Tables (5)

| Table | Source | Expected Rows | Purpose |
|-------|--------|---------------|---------|
| `gold_shipment_tracking` | silver_shipment + silver_carrier_events + silver_document_extraction | 3,000 | Current status per shipment — primary agent read surface |
| `gold_carrier_event_timeline` | silver_carrier_events (is_duplicate=false) | ~4,000–4,300 | Full deduplicated event history |
| `gold_document_intelligence` | silver_document_extraction + silver_human_review_queue | ~2,800 | Final delivery result with human override |
| `gold_exception_summary` | silver_carrier_events + silver_document_extraction + silver_tracking_map + gold_sla_performance | ~1,200–1,500 | All open exceptions (5 types) |
| `gold_sla_performance` | gold_shipment_tracking + silver_shipment | 3,000 | SLA status and variance_hours per shipment |

---

## UC Table-Valued Functions (4)

All functions are read-only and reside in `dbx_cohort1_wave1.sch_pod13`.

| Function | Reads From | Returns |
|----------|-----------|---------|
| `fn_get_shipment_status(p_shipment_id STRING)` | gold_shipment_tracking | Current status, delivery flags, doc confidence |
| `fn_get_carrier_events(p_shipment_id STRING)` | gold_carrier_event_timeline | Full ordered event timeline |
| `fn_get_document_extraction(p_shipment_id STRING)` | gold_document_intelligence | Extraction result + human decision |
| `fn_get_exceptions(p_shipment_id STRING)` | gold_exception_summary | All open exceptions |

---

## Agent Outputs

| Agent | Output Location | Key Fields |
|-------|----------------|------------|
| ShipmentInvestigationAgent | audit_agent_activity | finding: NORMAL / LATE_ARRIVAL_DETECTED / EXCEPTION_IN_TRANSIT |
| DocumentIntelligenceAgent | audit_agent_activity, audit_human_decisions | outcome: AUTO_ACCEPTED / DAMAGE_CLAIM_ACCEPTED / REJECTED |
| ExceptionAgent | audit_agent_activity, audit_human_decisions | outcome: ACKNOWLEDGED / ESCALATED / CLOSED |
| SupervisorAgent | audit_agent_activity, audit_human_decisions | COMPLETE / COMPLETE_STATUS_CHANGE_APPROVED |

---

## Audit Tables (8)

| Table | Populated By | Purpose |
|-------|-------------|---------|
| `audit_pipeline_execution` | Every notebook | Run ID, notebook name, layer, start/end, status, row count |
| `audit_data_quality` | log_qc() helper | Check ID, layer, test name, total/passed/failed, pass rate, status |
| `audit_schema_drift` | 04_Silver_Carrier_Events | Drift records: actual vs expected version, drift type |
| `audit_document_processing` | 05_Document_AI | Per-document extraction record: model version, confidence, result |
| `audit_human_decisions` | 06_Human_Review, 11_Agents | Decision ID, decision type, decision, decided_by |
| `audit_agent_activity` | 11_Agents | Agent name, action, evidence JSON, outcome |
| `audit_sla_calculations` | 08_Gold_SLA | SLA rule version, variance_hours, status per shipment |
| `audit_exception_lifecycle` | 07_Gold_Shipment_Tracking | Exception creation and status transitions |

---

## Quality Test Results Summary (expected)

| Layer | Tests | Expected Pass |
|-------|-------|---------------|
| Bronze | BRZ-01 – BRZ-04 | 4 / 4 PASS |
| Silver | SLV-01 – SLV-10 | 10 / 10 PASS |
| Gold | GLD-01 – GLD-08 | 8 / 8 PASS |
| Audit | AUD-01 – AUD-03 | 3 / 3 PASS |
| **Total** | **25** | **25 / 25 PASS** |

---

## Version Constants

| Constant | Value |
|----------|-------|
| EXPECTED_VERSION (JSON payload) | v3.1 |
| MODEL_VERSION (Document AI) | regex-v1.0 |
| PROMPT_VERSION (Document AI) | pod-parser-v1.0 |
| SLA_RULE_VER | sla-v1.0 |
| CONFIDENCE_THRESHOLD | 0.80 |
| LATE_THRESHOLD_SEC | 3600 |
