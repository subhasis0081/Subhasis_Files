# Genie Prompt — 00_Setup
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt into a Databricks Genie cell or as the first cell in a new notebook before running `code/00_Setup.md`.

---

```
You are setting up the Pod 13 Shipment Tracking & Delivery Intelligence environment in Databricks Unity Catalog.

Follow the instructions in code/00_Setup.md exactly and in order:

1. Set USE CATALOG dbx_cohort1_wave1 and USE SCHEMA sch_pod13
2. Create schema sch_pod13 if it does not exist
3. Create volume vol_pod13 if it does not exist
4. Create the 5 landing subdirectories under /Volumes/dbx_cohort1_wave1/sch_pod13/vol_pod13/landing/
5. Create all 8 audit Delta tables with the exact DDL provided — do not change column names or types
6. Print a confirmation showing all created objects

Use only the catalog dbx_cohort1_wave1 and schema sch_pod13.
Do not create any objects in pod5 or any other schema.
All table names must be fully qualified: dbx_cohort1_wave1.sch_pod13.<table_name>
```
