# Genie Prompt — 01_Generate_Data
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt into a Databricks Genie cell before running `code/01_Generate_Data.md`.

---

```
You are generating 3000 synthetic shipment records for the Pod 13 pipeline.

Follow code/01_Generate_Data.md exactly:

1. Set random.seed(42) before any random call — this ensures reproducibility
2. Generate exactly 3000 shipment IDs in the range SHP-100001 to SHP-103000
3. Inject anomalies at these exact rates:
   - duplicate_event:  5% of shipments
   - late_arrival:     8% of shipments
   - schema_drift:     3% of shipments
   - damaged:          4% of shipments
   - missing_pod:      6% of shipments
   - low_confidence:   7% of shipments
   - human_review:     5% of shipments
4. Write 6 output files to /Volumes/dbx_cohort1_wave1/sch_pod13/vol_pod13/landing/
5. The DEMO_SHIPMENTS dict must contain exactly these 8 IDs with their anomaly types:
   SHP-100011, SHP-102253, SHP-102706, SHP-100002, SHP-100012, SHP-100636, SHP-100141, SHP-100698

Use only catalog dbx_cohort1_wave1, schema sch_pod13, volume vol_pod13.
Do not write any files to pod5 paths.
```
