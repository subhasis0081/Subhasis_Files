# Genie Prompt — 02_Bronze_Ingestion
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/02_Bronze_Ingestion.md`.

---

```
You are ingesting 6 source files from the Pod 13 landing zone into Bronze Delta tables.

Follow code/02_Bronze_Ingestion.md exactly:

1. Read each file from /Volumes/dbx_cohort1_wave1/sch_pod13/vol_pod13/landing/
2. Use rescuedDataColumn="_rescued_data" on every read
3. Call add_metadata() to attach source_file, source_record_id, batch_id, ingested_ts_utc
4. Write 6 Bronze Delta tables with mode="overwrite" and overwriteSchema=True:
   - bronze_shipment_manifest
   - bronze_dispatch
   - bronze_tracking_map
   - bronze_carrier_events
   - bronze_carrier_tracking_raw  (JSON)
   - bronze_delivery_documents    (POD text files)
5. Log the run to audit_pipeline_execution

All table names fully qualified: dbx_cohort1_wave1.sch_pod13.<table_name>
Do not read from or write to any pod5 path.
```
