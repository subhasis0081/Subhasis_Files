# Genie Prompt — 03_Silver_Shipments
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/03_Silver_Shipments.md`.

---

```
You are building the Silver shipment, dispatch, and tracking map tables for Pod 13.

Follow code/03_Silver_Shipments.md exactly:

1. Read bronze_shipment_manifest and normalise:
   - carrier_normalized = UPPER(TRIM(carrier))
   - tracking_number_normalized = UPPER(regexp_replace(TRIM(tracking_number), whitespace, ""))
   - Parse dates as yyyy-MM-dd
   - Set is_valid = shipment_id IS NOT NULL AND carrier IS NOT NULL
   - Build validation_flags JSON array for any missing mandatory fields
2. Write silver_shipment
3. Build silver_dispatch from bronze_dispatch — parse dispatch_timestamp as ISO-8601 UTC
4. Build silver_tracking_map from bronze_tracking_map — compute match_method (EXACT/FUZZY) and match_confidence
5. Call log_qc() for each silver table
6. Log to audit_pipeline_execution

All table names: dbx_cohort1_wave1.sch_pod13.<table_name>
```
