# Genie Prompt — 04_Silver_Carrier_Events
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/04_Silver_Carrier_Events.md`.

---

```
You are building the Silver carrier events table for Pod 13 with deduplication and late arrival detection.

Follow code/04_Silver_Carrier_Events.md exactly:

1. Compute event_hash = SHA-256(shipment_id || "||" || tracking_number || "||" || event_status || "||" || event_timestamp)
2. Deduplicate using Window.partitionBy("event_hash").orderBy("event_id") — is_duplicate = rank > 1
3. Assign event_sequence using Window.partitionBy("shipment_id").orderBy("event_timestamp_utc", "event_id")
4. Compute arrival_lag_sec; set is_late_arrival = arrival_lag_sec > 3600
5. Canonicalise event_status values to lowercase snake_case
6. Handle schema drift: read bronze_carrier_tracking_raw, compare payload_version to EXPECTED_VERSION "v3.1",
   log drift to audit_schema_drift, quarantine drift shipments missing mandatory fields
7. Write silver_carrier_events and quarantine_carrier_events
8. Call log_qc(); log to audit_pipeline_execution

Fully qualified names: dbx_cohort1_wave1.sch_pod13.<table_name>
```
