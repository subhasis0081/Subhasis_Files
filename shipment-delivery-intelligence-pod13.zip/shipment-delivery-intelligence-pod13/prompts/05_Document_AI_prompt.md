# Genie Prompt — 05_Document_AI
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/05_Document_AI.md`.

---

```
You are running Document AI extraction on POD documents for Pod 13.

Follow code/05_Document_AI.md exactly:

Constants to use:
  MODEL_VERSION      = "regex-v1.0"
  PROMPT_VERSION     = "pod-parser-v1.0"
  CONFIDENCE_THRESHOLD = 0.80

Extraction rules:
1. delivery_result: regex on content_text → DAMAGED / PARTIAL / DELIVERED / UNKNOWN
2. recipient: regex for patterns SIGNED BY / RECIPIENT / DELIVERED TO
3. Compute confidence_score:
   - delivery_result found:  +0.50
   - recipient found:        +0.25
   - SHP- ID present:        +0.15
   - tracking number found:  +0.10
4. requires_review = confidence_score < CONFIDENCE_THRESHOLD or delivery_result in (DAMAGED, PARTIAL)
5. Write silver_document_extraction for all docs with confidence >= threshold
6. Write quarantine_documents for docs below threshold or unresolvable
7. Write one row per document to audit_document_processing
8. Log to audit_pipeline_execution

Fully qualified names: dbx_cohort1_wave1.sch_pod13.<table_name>
```
