# Genie Prompt — 06_Human_Review
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/06_Human_Review.md`.

---

```
You are building the human review queue for Pod 13 shipments that require manual intervention.

Follow code/06_Human_Review.md exactly:

Sources for the review queue (three types):
1. LOW_CONFIDENCE_EXTRACTION — from silver_document_extraction where confidence_score < 0.80
2. FUZZY_TRACKING_MATCH      — from silver_tracking_map where match_method = 'FUZZY'
3. DAMAGE_PARTIAL_DELIVERY   — from silver_document_extraction where delivery_result IN ('DAMAGED','PARTIAL')

Schema required:
  review_id, shipment_id, review_type, source_table, source_id,
  priority, review_context, requires_human (=True), created_at

Simulate decisions using DECISION_MATRIX with random.seed(42).
Write results to silver_human_review_queue.
Log each decision to audit_human_decisions.

All names fully qualified: dbx_cohort1_wave1.sch_pod13.<table_name>
```
