# Genie Prompt — 07_Gold_Shipment_Tracking
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/07_Gold_Shipment_Tracking.md`.

---

```
You are building the Gold layer shipment tracking tables for Pod 13.

Follow code/07_Gold_Shipment_Tracking.md exactly. Produce all 4 Gold tables:

1. gold_shipment_tracking
   - Latest carrier event per shipment using Window.partitionBy("shipment_id").orderBy(event_timestamp_utc DESC)
   - Best document per shipment using Window.partitionBy("shipment_id").orderBy(confidence_score DESC)
   - Flags: is_delivered, has_damage, has_late_arrival, current_status

2. gold_carrier_event_timeline
   - Full deduplicated event timeline (is_duplicate = false only)

3. gold_document_intelligence
   - Merge silver_document_extraction with human decisions from silver_human_review_queue
   - final_delivery_result = human decision if exists, else doc extraction result

4. gold_exception_summary
   - 5 exception types: DUPLICATE_EVENT, LATE_ARRIVAL, LOW_CONFIDENCE_DOC, DAMAGE_CLAIM, FUZZY_MATCH
   - Each row: exception_id (uuid), shipment_id, exception_type, exception_detail, status, created_at

Call log_qc() after each table. Log to audit_pipeline_execution.
All names: dbx_cohort1_wave1.sch_pod13.<table_name>
```
