# Genie Prompt — 08_Gold_SLA
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/08_Gold_SLA.md`.

---

```
You are building the Gold SLA performance table for Pod 13.

Follow code/08_Gold_SLA.md exactly:

Constants:
  SLA_RULE_VER = "sla-v1.0"

Calculation:
  variance_hours = (actual_delivery_ts - promised_delivery_ts) / 3600

SLA status rules (applied in order):
  PENDING         — shipment not yet delivered
  ON_TIME         — variance_hours <= 0
  MINOR_BREACH    — variance_hours <= 24
  MAJOR_BREACH    — variance_hours <= 72
  CRITICAL_BREACH — variance_hours > 72

Steps:
1. Join gold_shipment_tracking with silver_shipment on shipment_id
2. Compute variance_hours and sla_status
3. Set is_sla_breach = sla_status NOT IN ('ON_TIME', 'PENDING')
4. Write gold_sla_performance
5. Append SLA_BREACH rows to gold_exception_summary for any is_sla_breach = true
6. Call log_qc(); log to audit_pipeline_execution

All names: dbx_cohort1_wave1.sch_pod13.<table_name>
```
