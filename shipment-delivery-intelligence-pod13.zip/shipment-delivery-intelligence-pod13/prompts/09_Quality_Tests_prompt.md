# Genie Prompt — 09_Quality_Tests
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/09_Quality_Tests.md`.

---

```
You are running the full quality test suite for the Pod 13 pipeline.

Follow code/09_Quality_Tests.md exactly. Run all 25 tests in order:

Bronze tests  (BRZ-01 to BRZ-04): validate non-null keys in bronze tables
Silver tests  (SLV-01 to SLV-10): validate event_hash, dedup flags, canonical_status, confidence scores
Gold tests    (GLD-01 to GLD-08): validate gold table completeness and sla_status enum
Audit tests   (AUD-01 to AUD-03): validate audit table row integrity

For each test call run_test(layer, test_id, table_name, check_expr):
  PASS  = pass_rate >= 99%
  WARN  = pass_rate >= 95%
  FAIL  = pass_rate < 95%

Write every result to audit_data_quality.
Print a final summary: total tests, PASS count, WARN count, FAIL count, pass rate %.

All tables: dbx_cohort1_wave1.sch_pod13.<table_name>
```
