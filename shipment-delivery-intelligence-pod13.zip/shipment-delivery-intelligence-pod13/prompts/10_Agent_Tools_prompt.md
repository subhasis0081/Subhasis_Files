# Genie Prompt — 10_Agent_Tools
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/10_Agent_Tools.md`.

---

```
You are creating 4 read-only Unity Catalog table-valued functions as agent tools for Pod 13.

Follow code/10_Agent_Tools.md exactly. Create these 4 SQL TVFs:

1. dbx_cohort1_wave1.sch_pod13.fn_get_shipment_status(p_shipment_id STRING)
   — reads gold_shipment_tracking; returns current status, is_delivered, has_damage, etc.

2. dbx_cohort1_wave1.sch_pod13.fn_get_carrier_events(p_shipment_id STRING)
   — reads gold_carrier_event_timeline; returns full event sequence

3. dbx_cohort1_wave1.sch_pod13.fn_get_document_extraction(p_shipment_id STRING)
   — reads gold_document_intelligence; returns extraction result and human decision

4. dbx_cohort1_wave1.sch_pod13.fn_get_exceptions(p_shipment_id STRING)
   — reads gold_exception_summary; returns all open exceptions

Use CREATE OR REPLACE FUNCTION ... RETURNS TABLE ... RETURN SELECT ... syntax.
All functions are read-only — no INSERT/UPDATE/DELETE inside any function.
After creation, verify all 4 functions by calling them for SHP-100011.
Log to audit_pipeline_execution.
```
