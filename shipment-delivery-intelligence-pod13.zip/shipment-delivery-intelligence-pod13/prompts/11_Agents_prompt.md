# Genie Prompt — 11_Agents
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/11_Agents.md`.

---

```
You are implementing the 4-agent multi-agent framework for Pod 13 shipment intelligence.

Follow code/11_Agents.md exactly. Implement these classes:

1. ShipmentInvestigationAgent
   - Calls fn_get_shipment_status and fn_get_carrier_events
   - Returns finding: NORMAL / LATE_ARRIVAL_DETECTED / EXCEPTION_IN_TRANSIT

2. DocumentIntelligenceAgent
   - Calls fn_get_document_extraction
   - Requires human approval (require_human_approval) for low confidence (<0.80) or damage claims

3. ExceptionAgent
   - Calls fn_get_exceptions
   - Requires human approval before closing SLA_BREACH or escalating DAMAGE_CLAIM

4. SupervisorAgent
   - Orchestrates agents 1→2→3 serially
   - Requires human approval before any status change
   - Logs summary to audit_agent_activity via log_agent_action()

Governance rules that must not be violated:
  - require_human_approval() must be called before: status change, exception close, low-conf accept, damage claim, SLA override
  - All agent actions logged to audit_agent_activity
  - All approval requests logged to audit_human_decisions

Run the demo on 5 shipments: SHP-100011, SHP-100012, SHP-100636, SHP-100141, SHP-100698
All tables: dbx_cohort1_wave1.sch_pod13.<table_name>
```
