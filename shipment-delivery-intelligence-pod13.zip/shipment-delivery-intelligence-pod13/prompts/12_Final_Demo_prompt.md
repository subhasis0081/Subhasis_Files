# Genie Prompt — 12_Final_Demo
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/12_Final_Demo.md`.

---

```
You are running the final end-to-end demo for the Pod 13 Shipment Tracking & Delivery Intelligence project.

Follow code/12_Final_Demo.md exactly. Trace all 8 demo scenarios:

| Shipment    | Scenario                  |
|-------------|---------------------------|
| SHP-100011  | NORMAL DELIVERY           |
| SHP-102253  | DUPLICATE EVENT           |
| SHP-102706  | LATE ARRIVAL              |
| SHP-100002  | SCHEMA DRIFT → QUARANTINE |
| SHP-100012  | DAMAGED DELIVERY          |
| SHP-100636  | MISSING POD               |
| SHP-100141  | LOW CONFIDENCE DOC        |
| SHP-100698  | HUMAN REVIEW REQUIRED     |

For each shipment print:
  BRONZE  — carrier, tracking number, route, promised delivery
  SILVER  — is_valid, canonical events, quarantine flag if applicable
  GOLD    — current_status, SLA status, open exceptions
  REVIEW  — human review queue entry if present

End with pipeline summary statistics (row counts for all key tables).
All tables: dbx_cohort1_wave1.sch_pod13.<table_name>
```
