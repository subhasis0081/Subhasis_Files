# Genie Prompt — Pipeline_Bronze_Silver_Gold
## Pod 13 | dbx_cohort1_wave1.sch_pod13

Paste this prompt before running `code/Pipeline_Bronze_Silver_Gold.md`.

---

```
You are running the consolidated Pod 13 ETL pipeline from Bronze through Silver in one notebook.

Follow code/Pipeline_Bronze_Silver_Gold.md exactly:

STAGE 1 — Bronze Ingestion
  Read 6 source files from /Volumes/dbx_cohort1_wave1/sch_pod13/vol_pod13/landing/
  Write 6 bronze Delta tables with rescuedDataColumn and metadata columns

STAGE 2 — Silver Shipments
  Build silver_shipment, silver_dispatch, silver_tracking_map
  Normalise carrier and tracking number; validate mandatory fields

STAGE 3 — Silver Carrier Events
  Compute event_hash (SHA-256), deduplicate, assign event_sequence
  Detect late arrivals (arrival_lag_sec > 3600)
  Write silver_carrier_events

STAGE 4 — Document AI + Human Review
  NOTE: Stages 4 is delegated to notebooks 05 and 06 for full logic.
  This stage verifies the silver tables exist before proceeding.

STAGE 5 — Gold Tables
  NOTE: Stages 5 is delegated to notebooks 07 and 08 for full Gold build.
  Verify Gold tables exist and print row counts.

STAGE 6 — Summary
  Log overall pipeline run to audit_pipeline_execution
  Print run ID, duration, completion timestamp

All tables: dbx_cohort1_wave1.sch_pod13.<table_name>
Do not read from or write to any pod5 paths.
```
