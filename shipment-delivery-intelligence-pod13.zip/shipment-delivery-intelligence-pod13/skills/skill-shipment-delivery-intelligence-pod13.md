---
name: skill-shipment-delivery-intelligence-pod13
description: >
  Shipment Delivery Intelligence project skill for dbx_cohort1_wave1.sch_pod13.
  Guides Genie to make code changes, prompt changes, architecture updates,
  data model modifications, agent tool edits, quality test additions, and any
  other work across the project's medallion pipeline, document AI, human review,
  agent framework, and demo notebooks. Load this skill whenever working on
  anything inside the shipment-delivery-intelligence-pod13 project.
---

# Shipment Delivery Intelligence — Project Skill (Pod 13)

## 1. Project Overview

A logistics medallion-pipeline project that tracks shipments from manifest through carrier events to proof-of-delivery, with AI document extraction, human review queues, governed agent tools, and a multi-agent framework.

**Flow:** `Landing → Bronze → Silver → Gold → Governed UC functions → Agents → Human decision`

## 2. Unity Catalog Location

| Item | Value |
|------|-------|
| Catalog | `dbx_cohort1_wave1` |
| Schema | `sch_pod13` |
| Volume | `vol_pod13` |
| Volume path | `/Volumes/dbx_cohort1_wave1/sch_pod13/vol_pod13` |
| Volume folders | `landing`, `logs`, `checkpoints`, `quarantine`, `archive` |

Every notebook starts with:
```python
CATALOG = "dbx_cohort1_wave1"
SCHEMA  = "sch_pod13"
VOLUME  = "vol_pod13"
VOLUME_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"
spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
```

## 3. Folder Layout

```
shipment-delivery-intelligence-pod13/
├── code/           # Numbered Genie-executable notebooks (00–12 + Pipeline)
├── architecture/   # Markdown rules: ARCHITECTURE, DATA_MODEL, *_RULES, QUALITY_TESTS, AGENT_GUARDRAILS, DEMO_PLAN
├── prompts/        # One prompt .md per notebook — the spec that guided code generation
├── data/           # Data generation spec and source file layout
├── skills/         # This skill file
├── instructions/   # Genie execution order and runbook
├── output/         # Output specification
└── artifacts/      # HTML implementation strategy document
```

## 4. Notebook Index

| # | Notebook | Layer | Purpose |
|---|----------|-------|---------|
| 00 | 00_Setup | infra | Create catalog, schema, volume folders, 8 audit tables |
| 01 | 01_Generate_Data | data-gen | 3000 synthetic shipments with anomalies |
| 02 | 02_Bronze_Ingestion | bronze | CSV + JSON + binary file ingestion → 6 Bronze tables |
| 03 | 03_Silver_Shipments | silver | Validate manifest, dispatch, tracking map |
| 04 | 04_Silver_Carrier_Events | silver | Event hash, dedup, status normalisation, late arrival, schema drift → quarantine |
| 05 | 05_Document_AI | silver | Regex extraction from POD text, confidence scoring, review routing |
| 06 | 06_Human_Review | silver | Unified review queue, simulated decisions |
| 07 | 07_Gold_Shipment_Tracking | gold | 4 Gold tables: tracking, events, documents, exceptions |
| 08 | 08_Gold_SLA | gold | SLA variance calculation, breach exceptions |
| 09 | 09_Quality_Tests | testing | End-to-end test suite across all layers |
| 10 | 10_Agent_Tools | tools | 4 UC table-valued functions |
| 11 | 11_Agents | agents | 4 Python agent classes + audit logging |
| 12 | 12_Final_Demo | demo | 8 scenarios traced source → Bronze → Silver → Gold → Agent |
| — | Pipeline_Bronze_Silver_Gold | pipeline | Consolidated single-notebook ETL (Bronze→Silver→Gold) |

## 5. Data Model Summary

See `architecture/DATA_MODEL.md` for full column-level detail.

**Bronze (6 tables):** `bronze_shipment_manifest`, `bronze_dispatch`, `bronze_tracking_map`, `bronze_carrier_events`, `bronze_carrier_tracking_raw`, `bronze_delivery_documents`

**Silver (8 tables):** `silver_shipment`, `silver_dispatch`, `silver_tracking_map`, `silver_carrier_events`, `silver_document_extraction`, `silver_human_review`, `quarantine_carrier_events`, `quarantine_documents`

**Gold (5 tables):** `gold_shipment_tracking`, `gold_shipment_event`, `gold_delivery_document`, `gold_delivery_exception`, `gold_shipment_sla`

**Audit (8 tables):** `audit_pipeline_execution`, `audit_reconciliation`, `audit_api_failures`, `audit_schema_drift`, `audit_document_processing`, `audit_data_quality`, `audit_human_reviews`, `audit_agent_activity`

## 6. UC Functions

| Function | Source |
|----------|--------|
| `get_shipment_status(p_shipment_id)` | `gold_shipment_tracking` |
| `get_shipment_sla(p_shipment_id)` | `gold_shipment_sla` |
| `get_document_details(p_shipment_id)` | `gold_delivery_document` |
| `get_open_exceptions(p_shipment_id)` | `gold_delivery_exception` |

All functions are **read-only** in `dbx_cohort1_wave1.sch_pod13`.

## 7. Architecture Rules

See `architecture/BRONZE_RULES.md`, `architecture/SILVER_RULES.md`, `architecture/GOLD_RULES.md` for full rules.

### Bronze
1. Keep values as received — never correct business values
2. Preserve malformed records
3. Required metadata: `source_file`, `source_record_id`, `batch_id`, `ingested_ts_utc`
4. `raw_payload` for JSON; `content_hash` for documents
5. `_rescued_data` for unexpected columns
6. Idempotent and restartable

### Silver
1. Normalise AND keep originals
2. `event_hash` = SHA-256(shipment_id ∥ tracking_number ∥ event_status ∥ event_timestamp)
3. Window dedup on event_hash
4. `event_sequence` from timestamp + stable ID
5. Late arrival: `arrival_lag_sec > 3600`
6. UTC conversion; retain original timezone
7. Schema drift → quarantine
8. Document extraction: structured JSON + model/prompt version + content_hash
9. Confidence < 0.80 → human review

### Gold
1. `gold_shipment_tracking`: 1 row per shipment
2. `gold_shipment_event`: 1 row per deduplicated canonical event
3. `gold_delivery_document`: approved or high-confidence only
4. `gold_delivery_exception`: all anomaly types
5. `gold_shipment_sla`: variance_hours = actual − promised; no override without approval

## 8. Agent Guardrails

See `architecture/AGENT_GUARDRAILS.md` for full rules.

Human approval required before: modifying shipment status, closing exceptions, accepting low-confidence extraction, approving fuzzy mapping, overriding SLA.

Agents are **read-only**. No direct table writes.

## 9. Code Patterns

### Standard Notebook Structure
1. Markdown header cell — title and description
2. Configuration cell — imports, CATALOG/SCHEMA/VOLUME constants, EXECUTION_ID, STARTED_AT
3. Processing cells — one per logical step
4. Audit/quality cell — log to audit table, run quality checks
5. Verification cell — summary print or DataFrame display

### Quality Check Helper
```python
def log_qc(check_layer, check_name, table_name, check_expr, df=None):
    if df is None:
        df = spark.table(f"{CATALOG}.{SCHEMA}.{table_name}")
    total   = df.count()
    passed  = df.filter(check_expr).count()
    failed  = total - passed
    rate    = round((passed / total * 100), 2) if total > 0 else 0.0
    status  = "PASS" if rate >= 99 else ("WARN" if rate >= 95 else "FAIL")
    qc_id   = str(uuid.uuid4())
    spark.sql(f"""
    INSERT INTO {CATALOG}.{SCHEMA}.audit_data_quality VALUES
    ('{qc_id}', '{EXECUTION_ID}', '{check_layer}', '{check_name}',
     '{table_name}', "{check_expr}", {total}, {passed}, {failed},
     {rate}, '{status}', current_timestamp())
    """)
    print(f"  [{status}] {check_name}: {passed}/{total} ({rate}%)")
```

### Delta Write Pattern
```python
(df.write.format("delta")
 .mode("overwrite").option("overwriteSchema", "true")
 .saveAsTable(f"{CATALOG}.{SCHEMA}.{table_name}"))
```

### Always Use Fully Qualified Names
```python
spark.table("dbx_cohort1_wave1.sch_pod13.table_name")
```

## 10. Key Thresholds

| Threshold | Value |
|-----------|-------|
| Late arrival | 3600 seconds |
| Confidence review | 0.80 |
| Expected payload version | v3.1 |
| SLA rule version | sla-v1.0 |
| Model version | regex-v1.0 |
| Prompt version | pod-parser-v1.0 |

## 11. Data Generation Parameters

- 3000 shipments
- ~14,838 carrier events
- ~2,880 POD documents (120 missing)
- ~5% duplicates, ~4% late arrivals, ~3% schema drift, ~3% damaged, ~2% partial, ~4% low-confidence, ~4% missing POD
- Carriers: UPS, FEDEX, DHL, USPS, ONTRAC, LASERSHIP
- Status lifecycle: `label_created → picked_up → in_transit → out_for_delivery → delivered`

## 12. When Editing

1. Check architecture rules before any table change
2. Enforce agent guardrails — no agent writes to Gold
3. Maintain audit logging — every notebook logs to at least one audit table
4. Add quality checks for new columns, tables, or transformations
5. Add table/column comments via SQL COMMENT
6. Keep prompt files in sync with notebook logic
7. Preserve existing patterns (import style, config block, quality helper, Delta write)
8. Use fully qualified table names in all cross-notebook references
